-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 08, 2025 at 08:13 AM
-- Server version: 8.0.30
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `waju`
--

-- --------------------------------------------------------

--
-- Table structure for table `achul`
--

CREATE TABLE `achul` (
  `id` int NOT NULL,
  `nama_baju` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `harga_baju` int DEFAULT NULL,
  `foto_baju` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `pemilik_baju` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `kategori_baju` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `ukuran_baju` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `ukuran_s` tinyint(1) DEFAULT NULL,
  `ukuran_m` tinyint(1) DEFAULT NULL,
  `ukuran_l` tinyint(1) DEFAULT NULL,
  `tanggal_sewa` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `bulan_sewa` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `tahun_sewa` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `tanggal_pengembalian` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `bulan_pengembalian` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `tahun_pengembalian` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `alamat_pengambilan` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `nama_penyewa` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `alamat_penyewa` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `nik_penyewa` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `kontak_penyewa` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `status_baju` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `blokir_akun` tinyint(1) DEFAULT NULL,
  `id_databaju` int DEFAULT NULL,
  `id_toko` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `achul`
--

INSERT INTO `achul` (`id`, `nama_baju`, `harga_baju`, `foto_baju`, `pemilik_baju`, `kategori_baju`, `ukuran_baju`, `ukuran_s`, `ukuran_m`, `ukuran_l`, `tanggal_sewa`, `bulan_sewa`, `tahun_sewa`, `tanggal_pengembalian`, `bulan_pengembalian`, `tahun_pengembalian`, `alamat_pengambilan`, `nama_penyewa`, `alamat_penyewa`, `nik_penyewa`, `kontak_penyewa`, `status_baju`, `blokir_akun`, `id_databaju`, `id_toko`) VALUES
(11, 'Kaedehara Kazuha - Genshin Impact', 100000, '..\\img\\data_kostum\\kazuha.jpg', 'achul', 'Cosplay', 'L', 0, 1, 0, '16', 'January', '2025', NULL, NULL, NULL, 'Jalan Kemerdekaan 3, Batu Hijau, Seguling-guling, Ajo City', 'achul', NULL, NULL, NULL, NULL, NULL, 1, 3),
(12, 'Kaedehara Kazuha - Genshin Impact', 100000, '..\\img\\data_kostum\\kazuha.jpg', 'achul', 'Cosplay', 'L', 0, 1, 0, '15', 'January', '2025', NULL, NULL, NULL, 'Jalan Kemerdekaan 3, Batu Hijau, Seguling-guling, Ajo City', 'achul', NULL, NULL, NULL, NULL, NULL, 1, 3),
(13, 'Kaedehara Kazuha - Genshin Impact', 100000, '..\\img\\data_kostum\\kazuha.jpg', 'achul', 'Cosplay', 'S', 1, 0, 0, '5', 'January', '2025', NULL, NULL, NULL, 'Jalan Kemerdekaan 3, Batu Hijau, Seguling-guling, Ajo City', 'achul', NULL, NULL, NULL, NULL, NULL, 1, 3),
(14, 'Kaedehara Kazuha - Genshin Impact', 100000, '..\\img\\data_kostum\\kazuha.jpg', 'achul', 'Cosplay', 'M', 0, 1, 0, '7', 'January', '2025', NULL, NULL, NULL, 'Jalan Kemerdekaan 3, Batu Hijau, Seguling-guling, Ajo City', 'achul', NULL, NULL, NULL, NULL, NULL, 1, 3),
(15, 'Kaedehara Kazuha - Genshin Impact', 100000, '..\\img\\data_kostum\\kazuha.jpg', 'achul', 'Cosplay', 'S', 1, 0, 0, '8', 'January', '2025', NULL, NULL, NULL, 'Jalan Kemerdekaan 3, Batu Hijau, Seguling-guling, Ajo City', 'achul', NULL, NULL, NULL, NULL, NULL, 1, 3),
(16, 'Almet Polibatam', 50000, '../img/data_kostum/Gedung.jpg', 'achul', 'Polibatam', 'M', 0, 1, 0, '16', 'January', '2025', NULL, NULL, NULL, 'Griya', 'achul', NULL, NULL, NULL, NULL, NULL, 3, 3);

-- --------------------------------------------------------

--
-- Table structure for table `bunga`
--

CREATE TABLE `bunga` (
  `id` int NOT NULL,
  `nama_baju` varchar(255) DEFAULT NULL,
  `harga_baju` int DEFAULT NULL,
  `foto_baju` varchar(300) DEFAULT NULL,
  `pemilik_baju` varchar(300) DEFAULT NULL,
  `kategori_baju` varchar(300) DEFAULT NULL,
  `ukuran_baju` varchar(300) DEFAULT NULL,
  `ukuran_s` tinyint(1) DEFAULT NULL,
  `ukuran_m` tinyint(1) DEFAULT NULL,
  `ukuran_l` tinyint(1) DEFAULT NULL,
  `tanggal_sewa` varchar(300) DEFAULT NULL,
  `bulan_sewa` varchar(300) DEFAULT NULL,
  `tahun_sewa` varchar(300) DEFAULT NULL,
  `tanggal_pengembalian` varchar(300) DEFAULT NULL,
  `bulan_pengembalian` varchar(300) DEFAULT NULL,
  `tahun_pengembalian` varchar(300) DEFAULT NULL,
  `alamat_pengambilan` varchar(300) DEFAULT NULL,
  `nama_penyewa` varchar(300) DEFAULT NULL,
  `alamat_penyewa` varchar(300) DEFAULT NULL,
  `nik_penyewa` varchar(300) DEFAULT NULL,
  `kontak_penyewa` varchar(300) DEFAULT NULL,
  `status_baju` varchar(300) DEFAULT NULL,
  `blokir_akun` tinyint(1) DEFAULT NULL,
  `id_databaju` int DEFAULT NULL,
  `id_toko` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `bunga`
--

INSERT INTO `bunga` (`id`, `nama_baju`, `harga_baju`, `foto_baju`, `pemilik_baju`, `kategori_baju`, `ukuran_baju`, `ukuran_s`, `ukuran_m`, `ukuran_l`, `tanggal_sewa`, `bulan_sewa`, `tahun_sewa`, `tanggal_pengembalian`, `bulan_pengembalian`, `tahun_pengembalian`, `alamat_pengambilan`, `nama_penyewa`, `alamat_penyewa`, `nik_penyewa`, `kontak_penyewa`, `status_baju`, `blokir_akun`, `id_databaju`, `id_toko`) VALUES
(1, 'Kaedehara Kazuha - Genshin Impact', 100000, '..\\img\\data_kostum\\kazuha.jpg', 'achul', 'Cosplay', 'S', 1, 0, 0, '9', 'January', '2025', NULL, NULL, NULL, 'Jalan Kemerdekaan 3, Batu Hijau, Seguling-guling, Ajo City', 'bunga', NULL, NULL, NULL, NULL, NULL, 1, 3);

-- --------------------------------------------------------

--
-- Table structure for table `dataakun`
--

CREATE TABLE `dataakun` (
  `id` int NOT NULL,
  `nama_pengguna` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `kata_sandi` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `nomor_telepon` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `nik_pengguna` varchar(300) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `alamat_pengguna` varchar(300) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `foto_pengguna` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '..\\img\\icon\\profile.jpg',
  `status_admin` tinyint(1) DEFAULT NULL,
  `status_update` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dataakun`
--

INSERT INTO `dataakun` (`id`, `nama_pengguna`, `kata_sandi`, `email`, `nomor_telepon`, `nik_pengguna`, `alamat_pengguna`, `foto_pengguna`, `status_admin`, `status_update`) VALUES
(1, 'achul', '202cb962ac59075b964b07152d234b70', 'arulnasrullah2468@gmail.com', '+6289668914466', '1231231231231231', 'Bumi', '../img/data_pengguna/kacungha.gif', 1, 0),
(8, 'putra', '202cb962ac59075b964b07152d234b70', 'arulnasrullah2468@gmail.com', NULL, NULL, NULL, '..\\img\\icon\\profile.jpg', NULL, NULL),
(9, 'elisabet', '202cb962ac59075b964b07152d234b70', 'putri123@gmail.com', '+62896689155', '2179899019823899', 'Polikteknik Negeri Batam', '../img/data_pengguna/Gedung.jpg', NULL, 0),
(10, 'eren', 'e10adc3949ba59abbe56e057f20f883e', 'arulnasrullah2468@gmail.com', NULL, NULL, NULL, '..\\img\\icon\\profile.jpg', NULL, NULL),
(11, 'bunga', 'e10adc3949ba59abbe56e057f20f883e', 'arulnasrullah2468@gmail.com', '+628966891449', '1234667788899002', 'Polikteknik Negeri Batam', '../img/data_pengguna/Bendera Polibatam.png', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `databaju`
--

CREATE TABLE `databaju` (
  `id` int NOT NULL,
  `nama_baju` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `kategori_baju` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `tersewa_baju` int DEFAULT '0',
  `rating_baju` int DEFAULT '1',
  `harga_baju` int DEFAULT NULL,
  `foto_baju` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `deskripsi_baju` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `ukuran_s` int DEFAULT NULL,
  `ukuran_m` int DEFAULT NULL,
  `ukuran_l` int DEFAULT NULL,
  `pilih_ukuran_s` tinyint(1) NOT NULL DEFAULT '1',
  `pilih_ukuran_m` tinyint(1) NOT NULL DEFAULT '1',
  `pilih_ukuran_l` tinyint(1) NOT NULL DEFAULT '1',
  `id_toko` int DEFAULT NULL,
  `pemilik_baju` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `foto_pemilik` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `deskripsi_toko` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `alamat_toko` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `kontak_pemilik` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `status_tersedia` tinyint(1) DEFAULT '1',
  `tanggal_1_s` int NOT NULL DEFAULT '0',
  `tanggal_1_m` int NOT NULL DEFAULT '0',
  `tanggal_1_l` int NOT NULL DEFAULT '0',
  `tanggal_1` int GENERATED ALWAYS AS (((`tanggal_1_s` + `tanggal_1_m`) + `tanggal_1_l`)) STORED,
  `tanggal_2_s` int NOT NULL DEFAULT '0',
  `tanggal_2_m` int NOT NULL DEFAULT '0',
  `tanggal_2_l` int NOT NULL DEFAULT '0',
  `tanggal_2` int GENERATED ALWAYS AS (((`tanggal_2_s` + `tanggal_2_m`) + `tanggal_2_l`)) STORED,
  `tanggal_3_s` int NOT NULL DEFAULT '0',
  `tanggal_3_m` int NOT NULL DEFAULT '0',
  `tanggal_3_l` int NOT NULL DEFAULT '0',
  `tanggal_3` int GENERATED ALWAYS AS (((`tanggal_3_s` + `tanggal_3_m`) + `tanggal_3_l`)) STORED,
  `tanggal_4_s` int NOT NULL DEFAULT '0',
  `tanggal_4_m` int NOT NULL DEFAULT '0',
  `tanggal_4_l` int NOT NULL DEFAULT '0',
  `tanggal_4` int GENERATED ALWAYS AS (((`tanggal_4_s` + `tanggal_4_m`) + `tanggal_4_l`)) STORED,
  `tanggal_5_s` int NOT NULL DEFAULT '0',
  `tanggal_5_m` int NOT NULL DEFAULT '0',
  `tanggal_5_l` int NOT NULL DEFAULT '0',
  `tanggal_5` int GENERATED ALWAYS AS (((`tanggal_5_s` + `tanggal_5_m`) + `tanggal_5_l`)) STORED,
  `tanggal_6_s` int NOT NULL DEFAULT '0',
  `tanggal_6_m` int NOT NULL DEFAULT '0',
  `tanggal_6_l` int NOT NULL DEFAULT '0',
  `tanggal_6` int GENERATED ALWAYS AS (((`tanggal_6_s` + `tanggal_6_m`) + `tanggal_6_l`)) STORED,
  `tanggal_7_s` int NOT NULL DEFAULT '0',
  `tanggal_7_m` int NOT NULL DEFAULT '0',
  `tanggal_7_l` int NOT NULL DEFAULT '0',
  `tanggal_7` int GENERATED ALWAYS AS (((`tanggal_7_s` + `tanggal_7_m`) + `tanggal_7_l`)) STORED,
  `tanggal_8_s` int NOT NULL DEFAULT '0',
  `tanggal_8_m` int NOT NULL DEFAULT '0',
  `tanggal_8_l` int NOT NULL DEFAULT '0',
  `tanggal_8` int GENERATED ALWAYS AS (((`tanggal_8_s` + `tanggal_8_m`) + `tanggal_8_l`)) STORED,
  `tanggal_9_s` int NOT NULL DEFAULT '0',
  `tanggal_9_m` int NOT NULL DEFAULT '0',
  `tanggal_9_l` int NOT NULL DEFAULT '0',
  `tanggal_9` int GENERATED ALWAYS AS (((`tanggal_9_s` + `tanggal_9_m`) + `tanggal_9_l`)) STORED,
  `tanggal_10_s` int NOT NULL DEFAULT '0',
  `tanggal_10_m` int NOT NULL DEFAULT '0',
  `tanggal_10_l` int NOT NULL DEFAULT '0',
  `tanggal_10` int GENERATED ALWAYS AS (((`tanggal_10_s` + `tanggal_10_m`) + `tanggal_10_l`)) STORED,
  `tanggal_11_s` int NOT NULL DEFAULT '0',
  `tanggal_11_m` int NOT NULL DEFAULT '0',
  `tanggal_11_l` int NOT NULL DEFAULT '0',
  `tanggal_11` int GENERATED ALWAYS AS (((`tanggal_11_s` + `tanggal_11_m`) + `tanggal_11_l`)) STORED,
  `tanggal_12_s` int NOT NULL DEFAULT '0',
  `tanggal_12_m` int NOT NULL DEFAULT '0',
  `tanggal_12_l` int NOT NULL DEFAULT '0',
  `tanggal_12` int GENERATED ALWAYS AS (((`tanggal_12_s` + `tanggal_12_m`) + `tanggal_12_l`)) STORED,
  `tanggal_13_s` int NOT NULL DEFAULT '0',
  `tanggal_13_m` int NOT NULL DEFAULT '0',
  `tanggal_13_l` int NOT NULL DEFAULT '0',
  `tanggal_13` int GENERATED ALWAYS AS (((`tanggal_13_s` + `tanggal_13_m`) + `tanggal_13_l`)) STORED,
  `tanggal_14_s` int NOT NULL DEFAULT '0',
  `tanggal_14_m` int NOT NULL DEFAULT '0',
  `tanggal_14_l` int NOT NULL DEFAULT '0',
  `tanggal_14` int GENERATED ALWAYS AS (((`tanggal_14_s` + `tanggal_14_m`) + `tanggal_14_l`)) STORED,
  `tanggal_15_s` int NOT NULL DEFAULT '0',
  `tanggal_15_m` int NOT NULL DEFAULT '0',
  `tanggal_15_l` int NOT NULL DEFAULT '0',
  `tanggal_15` int GENERATED ALWAYS AS (((`tanggal_15_s` + `tanggal_15_m`) + `tanggal_15_l`)) STORED,
  `tanggal_16_s` int NOT NULL DEFAULT '0',
  `tanggal_16_m` int NOT NULL DEFAULT '0',
  `tanggal_16_l` int NOT NULL DEFAULT '0',
  `tanggal_16` int GENERATED ALWAYS AS (((`tanggal_16_s` + `tanggal_16_m`) + `tanggal_16_l`)) STORED,
  `tanggal_17_s` int NOT NULL DEFAULT '0',
  `tanggal_17_m` int NOT NULL DEFAULT '0',
  `tanggal_17_l` int NOT NULL DEFAULT '0',
  `tanggal_17` int GENERATED ALWAYS AS (((`tanggal_17_s` + `tanggal_17_m`) + `tanggal_17_l`)) STORED,
  `tanggal_18_s` int NOT NULL DEFAULT '0',
  `tanggal_18_m` int NOT NULL DEFAULT '0',
  `tanggal_18_l` int NOT NULL DEFAULT '0',
  `tanggal_18` int GENERATED ALWAYS AS (((`tanggal_18_s` + `tanggal_18_m`) + `tanggal_18_l`)) STORED,
  `tanggal_19_s` int NOT NULL DEFAULT '0',
  `tanggal_19_m` int NOT NULL DEFAULT '0',
  `tanggal_19_l` int NOT NULL DEFAULT '0',
  `tanggal_19` int GENERATED ALWAYS AS (((`tanggal_19_s` + `tanggal_19_m`) + `tanggal_19_l`)) STORED,
  `tanggal_20_s` int NOT NULL DEFAULT '0',
  `tanggal_20_m` int NOT NULL DEFAULT '0',
  `tanggal_20_l` int NOT NULL DEFAULT '0',
  `tanggal_20` int GENERATED ALWAYS AS (((`tanggal_20_s` + `tanggal_20_m`) + `tanggal_20_l`)) STORED,
  `tanggal_21_s` int NOT NULL DEFAULT '0',
  `tanggal_21_m` int NOT NULL DEFAULT '0',
  `tanggal_21_l` int NOT NULL DEFAULT '0',
  `tanggal_21` int GENERATED ALWAYS AS (((`tanggal_21_s` + `tanggal_21_m`) + `tanggal_21_l`)) STORED,
  `tanggal_22_s` int NOT NULL DEFAULT '0',
  `tanggal_22_m` int NOT NULL DEFAULT '0',
  `tanggal_22_l` int NOT NULL DEFAULT '0',
  `tanggal_22` int GENERATED ALWAYS AS (((`tanggal_22_s` + `tanggal_22_m`) + `tanggal_22_l`)) STORED,
  `tanggal_23_s` int NOT NULL DEFAULT '0',
  `tanggal_23_m` int NOT NULL DEFAULT '0',
  `tanggal_23_l` int NOT NULL DEFAULT '0',
  `tanggal_23` int GENERATED ALWAYS AS (((`tanggal_23_s` + `tanggal_23_m`) + `tanggal_23_l`)) STORED,
  `tanggal_24_s` int NOT NULL DEFAULT '0',
  `tanggal_24_m` int NOT NULL DEFAULT '0',
  `tanggal_24_l` int NOT NULL DEFAULT '0',
  `tanggal_24` int GENERATED ALWAYS AS (((`tanggal_24_s` + `tanggal_24_m`) + `tanggal_24_l`)) STORED,
  `tanggal_25_s` int NOT NULL DEFAULT '0',
  `tanggal_25_m` int NOT NULL DEFAULT '0',
  `tanggal_25_l` int NOT NULL DEFAULT '0',
  `tanggal_25` int GENERATED ALWAYS AS (((`tanggal_25_s` + `tanggal_25_m`) + `tanggal_25_l`)) STORED,
  `tanggal_26_s` int NOT NULL DEFAULT '0',
  `tanggal_26_m` int NOT NULL DEFAULT '0',
  `tanggal_26_l` int NOT NULL DEFAULT '0',
  `tanggal_26` int GENERATED ALWAYS AS (((`tanggal_26_s` + `tanggal_26_m`) + `tanggal_26_l`)) STORED,
  `tanggal_27_s` int NOT NULL DEFAULT '0',
  `tanggal_27_m` int NOT NULL DEFAULT '0',
  `tanggal_27_l` int NOT NULL DEFAULT '0',
  `tanggal_27` int GENERATED ALWAYS AS (((`tanggal_27_s` + `tanggal_27_m`) + `tanggal_27_l`)) STORED,
  `tanggal_28_s` int NOT NULL DEFAULT '0',
  `tanggal_28_m` int NOT NULL DEFAULT '0',
  `tanggal_28_l` int NOT NULL DEFAULT '0',
  `tanggal_28` int GENERATED ALWAYS AS (((`tanggal_28_s` + `tanggal_28_m`) + `tanggal_28_l`)) STORED,
  `tanggal_29_s` int NOT NULL DEFAULT '0',
  `tanggal_29_m` int NOT NULL DEFAULT '0',
  `tanggal_29_l` int NOT NULL DEFAULT '0',
  `tanggal_29` int GENERATED ALWAYS AS (((`tanggal_29_s` + `tanggal_29_m`) + `tanggal_29_l`)) STORED,
  `tanggal_30_s` int NOT NULL DEFAULT '0',
  `tanggal_30_m` int NOT NULL DEFAULT '0',
  `tanggal_30_l` int NOT NULL DEFAULT '0',
  `tanggal_30` int GENERATED ALWAYS AS (((`tanggal_30_s` + `tanggal_30_m`) + `tanggal_30_l`)) STORED,
  `tanggal_31_s` int NOT NULL DEFAULT '0',
  `tanggal_31_m` int NOT NULL DEFAULT '0',
  `tanggal_31_l` int NOT NULL DEFAULT '0',
  `tanggal_31` int GENERATED ALWAYS AS (((`tanggal_31_s` + `tanggal_31_m`) + `tanggal_31_l`)) STORED
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `databaju`
--

INSERT INTO `databaju` (`id`, `nama_baju`, `kategori_baju`, `tersewa_baju`, `rating_baju`, `harga_baju`, `foto_baju`, `deskripsi_baju`, `ukuran_s`, `ukuran_m`, `ukuran_l`, `pilih_ukuran_s`, `pilih_ukuran_m`, `pilih_ukuran_l`, `id_toko`, `pemilik_baju`, `foto_pemilik`, `deskripsi_toko`, `alamat_toko`, `kontak_pemilik`, `status_tersedia`, `tanggal_1_s`, `tanggal_1_m`, `tanggal_1_l`, `tanggal_2_s`, `tanggal_2_m`, `tanggal_2_l`, `tanggal_3_s`, `tanggal_3_m`, `tanggal_3_l`, `tanggal_4_s`, `tanggal_4_m`, `tanggal_4_l`, `tanggal_5_s`, `tanggal_5_m`, `tanggal_5_l`, `tanggal_6_s`, `tanggal_6_m`, `tanggal_6_l`, `tanggal_7_s`, `tanggal_7_m`, `tanggal_7_l`, `tanggal_8_s`, `tanggal_8_m`, `tanggal_8_l`, `tanggal_9_s`, `tanggal_9_m`, `tanggal_9_l`, `tanggal_10_s`, `tanggal_10_m`, `tanggal_10_l`, `tanggal_11_s`, `tanggal_11_m`, `tanggal_11_l`, `tanggal_12_s`, `tanggal_12_m`, `tanggal_12_l`, `tanggal_13_s`, `tanggal_13_m`, `tanggal_13_l`, `tanggal_14_s`, `tanggal_14_m`, `tanggal_14_l`, `tanggal_15_s`, `tanggal_15_m`, `tanggal_15_l`, `tanggal_16_s`, `tanggal_16_m`, `tanggal_16_l`, `tanggal_17_s`, `tanggal_17_m`, `tanggal_17_l`, `tanggal_18_s`, `tanggal_18_m`, `tanggal_18_l`, `tanggal_19_s`, `tanggal_19_m`, `tanggal_19_l`, `tanggal_20_s`, `tanggal_20_m`, `tanggal_20_l`, `tanggal_21_s`, `tanggal_21_m`, `tanggal_21_l`, `tanggal_22_s`, `tanggal_22_m`, `tanggal_22_l`, `tanggal_23_s`, `tanggal_23_m`, `tanggal_23_l`, `tanggal_24_s`, `tanggal_24_m`, `tanggal_24_l`, `tanggal_25_s`, `tanggal_25_m`, `tanggal_25_l`, `tanggal_26_s`, `tanggal_26_m`, `tanggal_26_l`, `tanggal_27_s`, `tanggal_27_m`, `tanggal_27_l`, `tanggal_28_s`, `tanggal_28_m`, `tanggal_28_l`, `tanggal_29_s`, `tanggal_29_m`, `tanggal_29_l`, `tanggal_30_s`, `tanggal_30_m`, `tanggal_30_l`, `tanggal_31_s`, `tanggal_31_m`, `tanggal_31_l`) VALUES
(1, 'Kaedehara Kazuha - Genshin Impact', 'Cosplay', 5, 5, 100000, '..\\img\\data_kostum\\kazuha.jpg', 'Transformasikan penampilan Anda menjadi karakter Kaedehara Kazuha, seorang ronin elegan dari Genshin Impact! Kostum ini dirancang dengan detail tinggi dan material berkualitas premium untuk memberikan tampilan yang autentik dan nyaman dipakai.\r\n\r\nSpesifikasi Produk:\r\nDetail Kostum: Atasan, celana pendek, pelindung lengan, sarung tangan, dan aksesoris khas Kazuha.\r\nMaterial: Kombinasi kain polyester dan katun berkualitas tinggi, ringan, dan nyaman dipakai seharian.\r\nUkuran Tersedia: S, M, L (dilengkapi panduan ukuran untuk memastikan kesesuaian).\r\nWarna & Desain: Mengikuti desain asli dari Kaedehara Kazuha dengan warna-warna mencolok seperti merah, hitam, dan sentuhan emas.\r\nHarga Sewa:\r\nRp100.000 per hari.\r\n\r\nDapatkan pengalaman cosplay terbaik dengan kostum ini, cocok untuk acara cosplay, photoshoot, atau sekadar memenuhi hobi Anda sebagai Traveler di dunia Teyvat! Segera pesan sekarang sebelum kehabisan!', 2, 3, 4, 1, 1, 1, 3, 'achul', '..\\img\\data_toko\\pp_toko\\Achul.jpg', 'Belilahhhhhhhhhhhhhhhhhhhhh......', 'Jalan Kemerdekaan 3, Batu Hijau, Seguling-guling, Ajo City', '6289668914466', 1, 2, 3, 0, 1, 0, 0, 3, 0, 0, 2, 0, 2, 2, 1, 0, 0, 0, 0, 1, 0, 0, 3, 0, 0, 1, 0, 0, 0, 2, 0, 0, 0, 3, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 3, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 2, 0, 0, 0, 0, 1, 0, 3, 0, 1, 0, 4),
(2, 'Admin KECE (kurangin KECEpatan)', 'Admin', 1000, 5, 1000, '..\\img\\data_kostum\\admin bgt.jpg', 'MAS GITA.... MASS GITA..... HMPPSSSS SYEDDIHHHH SANGAT LANSOISNAONSAOINSOASN\r\n\r\nDI SAKITIN AMA MAS N ASYEDIHHHH\r\n\r\nSYEDIGGHH MENANGIS LAHH KAU KAN JUGA MANUSIA.', 1, 2, 3, 1, 1, 1, NULL, 'Bungek Mucikari Store', '..\\img\\data_toko\\pp_toko\\bunga mucikari.png', 'SENGGOL DIKIT TUSUK REWEL DIKIT SUSUK', 'Kos kosan Bunga', '1234567', 1, 5, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(3, 'Almet Polibatam', 'Polibatam', 0, 1, 50000, '../img/data_kostum/Gedung.jpg', 'Baju Almet Polibatam', 2, 2, 2, 1, 1, 1, 3, 'achul', '../img/data_toko/pp_toko/Achul.JPG', 'Ini adalah toko achul', 'Griya', '+6288888888888888', 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2),
(4, 'Polibatam Original', 'Polibatam', 0, 1, 50000, '../img/data_kostum/Gedung.jpg', 'Polibatam Original', 2, 2, 2, 1, 1, 1, 3, 'achul', '../img/data_toko/pp_toko/Achul.JPG', 'Ini adalah toko achul', 'Griya', '+6288888888888888', 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2),
(5, 'Polibatam Original', 'Polibatam', 0, 1, 50000, '../img/data_kostum/Gedung.jpg', 'Polibatam Original', 2, 2, 2, 1, 1, 1, 3, 'achul', '../img/data_toko/pp_toko/Achul.JPG', 'Ini adalah toko achul', 'Griya', '+6288888888888888', 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2),
(6, 'Polibatam Original', 'Polibatam', 0, 1, 50000, '../img/data_kostum/Gedung.jpg', 'Polibatam Original', 2, 2, 2, 1, 1, 1, 3, 'achul', '../img/data_toko/pp_toko/Achul.JPG', 'Ini adalah toko achul', 'Griya', '+6288888888888888', 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2),
(7, 'Polibatam Original', 'Polibatam', 0, 1, 50000, '../img/data_kostum/Gedung.jpg', 'Polibatam Original', 2, 2, 2, 1, 1, 1, 3, 'achul', '../img/data_toko/pp_toko/Achul.JPG', 'Ini adalah toko achul', 'Griya', '+6288888888888888', 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `datasewa`
--

CREATE TABLE `datasewa` (
  `id` int NOT NULL,
  `id_dataakun` int DEFAULT NULL,
  `id_datatoko` int DEFAULT NULL,
  `id_databaju` int DEFAULT NULL,
  `id_pemesanan` int DEFAULT NULL,
  `nama_penyewa` varchar(300) DEFAULT NULL,
  `nik_penyewa` varchar(300) DEFAULT NULL,
  `kontak_penyewa` varchar(300) DEFAULT NULL,
  `alamat_penyewa` varchar(300) DEFAULT NULL,
  `tanggal_pemesanan` varchar(300) DEFAULT NULL,
  `tanggal_sewa` varchar(300) DEFAULT NULL,
  `bulan_sewa` varchar(300) DEFAULT NULL,
  `tahun_sewa` varchar(300) DEFAULT NULL,
  `tanggal_pengembalian` varchar(300) DEFAULT NULL,
  `biaya_baju` int DEFAULT NULL,
  `biaya_layanan` int DEFAULT NULL,
  `biaya_pajak` int DEFAULT NULL,
  `biaya_total` int DEFAULT NULL,
  `nama_baju` varchar(300) DEFAULT NULL,
  `harga_baju` int DEFAULT NULL,
  `foto_baju` varchar(300) DEFAULT NULL,
  `ukuran_baju` varchar(300) DEFAULT NULL,
  `nama_pemilik` varchar(300) DEFAULT NULL,
  `alamat_pemilik` varchar(300) DEFAULT NULL,
  `kontak_pemilik` varchar(300) DEFAULT NULL,
  `hari` varchar(300) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `datasewa`
--

INSERT INTO `datasewa` (`id`, `id_dataakun`, `id_datatoko`, `id_databaju`, `id_pemesanan`, `nama_penyewa`, `nik_penyewa`, `kontak_penyewa`, `alamat_penyewa`, `tanggal_pemesanan`, `tanggal_sewa`, `bulan_sewa`, `tahun_sewa`, `tanggal_pengembalian`, `biaya_baju`, `biaya_layanan`, `biaya_pajak`, `biaya_total`, `nama_baju`, `harga_baju`, `foto_baju`, `ukuran_baju`, `nama_pemilik`, `alamat_pemilik`, `kontak_pemilik`, `hari`) VALUES
(1, 1, 3, 1, 4062588, 'achul', '123xxxxxxxxx1231', '+6289668914466', 'Bumi', 'Sabtu, 04-01-2025', '4', 'January', '2025', '06 January 2025', 200000, 10000, 22000, 232000, 'Kaedehara Kazuha - Genshin Impact', 100000, '..imgdata_kostumkazuha.jpg', 'S', 'achul', 'Jalan Kemerdekaan 3, Batu Hijau, Seguling-guling, Ajo City', '6289668914466', NULL),
(2, 1, 3, 1, 4062588, 'achul', '123xxxxxxxxx1231', '+6289668914466', 'Bumi', 'Sabtu, 04-01-2025', '4', 'January', '2025', '06 January 2025', 200000, 10000, 22000, 232000, 'Kaedehara Kazuha - Genshin Impact', 100000, '..imgdata_kostumkazuha.jpg', 'S', 'achul', 'Jalan Kemerdekaan 3, Batu Hijau, Seguling-guling, Ajo City', '6289668914466', '2'),
(3, 1, 3, 1, 4062588, 'achul', '123xxxxxxxxx1231', '+6289668914466', 'Bumi', 'Sabtu, 04-01-2025', '4', 'January', '2025', '06 January 2025', 200000, 10000, 22000, 232000, 'Kaedehara Kazuha - Genshin Impact', 100000, '..imgdata_kostumkazuha.jpg', 'S', 'achul', 'Jalan Kemerdekaan 3, Batu Hijau, Seguling-guling, Ajo City', '6289668914466', '2'),
(4, 1, 3, 1, 40625242, 'achul', '123xxxxxxxxx1231', '+6289668914466', 'Bumi', 'Sabtu, 04-01-2025', '4', 'January', '2025', '06 January 2025', 200000, 10000, 22000, 232000, 'Kaedehara Kazuha - Genshin Impact', 100000, '..imgdata_kostumkazuha.jpg', 'S', 'achul', 'Jalan Kemerdekaan 3, Batu Hijau, Seguling-guling, Ajo City', '6289668914466', '2'),
(5, 1, 3, 1, 40625242, 'achul', '123xxxxxxxxx1231', '+6289668914466', 'Bumi', 'Sabtu, 04-01-2025', '4', 'January', '2025', '06 January 2025', 200000, 10000, 22000, 232000, 'Kaedehara Kazuha - Genshin Impact', 100000, '..imgdata_kostumkazuha.jpg', 'S', 'achul', 'Jalan Kemerdekaan 3, Batu Hijau, Seguling-guling, Ajo City', '6289668914466', '2'),
(6, 1, 3, 1, 40625242, 'achul', '123xxxxxxxxx1231', '+6289668914466', 'Bumi', 'Sabtu, 04-01-2025', '4', 'January', '2025', '06 January 2025', 200000, 10000, 22000, 232000, 'Kaedehara Kazuha - Genshin Impact', 100000, '..imgdata_kostumkazuha.jpg', 'S', 'achul', 'Jalan Kemerdekaan 3, Batu Hijau, Seguling-guling, Ajo City', '6289668914466', '2'),
(7, 1, 3, 1, 40625242, 'achul', '123xxxxxxxxx1231', '+6289668914466', 'Bumi', 'Sabtu, 04-01-2025', '4', 'January', '2025', '06 January 2025', 200000, 10000, 22000, 232000, 'Kaedehara Kazuha - Genshin Impact', 100000, '..imgdata_kostumkazuha.jpg', 'S', 'achul', 'Jalan Kemerdekaan 3, Batu Hijau, Seguling-guling, Ajo City', '6289668914466', '2'),
(8, 1, 3, 1, 40625242, 'achul', '123xxxxxxxxx1231', '+6289668914466', 'Bumi', 'Sabtu, 04-01-2025', '4', 'January', '2025', '06 January 2025', 200000, 10000, 22000, 232000, 'Kaedehara Kazuha - Genshin Impact', 100000, '..imgdata_kostumkazuha.jpg', 'S', 'achul', 'Jalan Kemerdekaan 3, Batu Hijau, Seguling-guling, Ajo City', '6289668914466', '2'),
(9, 1, 3, 1, 40125323, 'achul', '123xxxxxxxxx1231', '+6289668914466', 'Bumi', 'Sabtu, 04-01-2025', '4', 'January', '2025', '06 January 2025', 200000, 10000, 22000, 232000, 'Kaedehara Kazuha - Genshin Impact', 100000, '..imgdata_kostumkazuha.jpg', 'S', 'achul', 'Jalan Kemerdekaan 3, Batu Hijau, Seguling-guling, Ajo City', '6289668914466', '2'),
(10, 1, 3, 1, 40125868, 'achul', '123xxxxxxxxx1231', '+6289668914466', 'Bumi', 'Sabtu, 04-01-2025', '4', 'January', '2025', '06 January 2025', 200000, 10000, 22000, 232000, 'Kaedehara Kazuha - Genshin Impact', 100000, '..imgdata_kostumkazuha.jpg', 'S', 'achul', 'Jalan Kemerdekaan 3, Batu Hijau, Seguling-guling, Ajo City', '6289668914466', '2'),
(11, 1, 3, 1, 40125868, 'achul', '123xxxxxxxxx1231', '+6289668914466', 'Bumi', 'Sabtu, 04-01-2025', '4', 'January', '2025', '06 January 2025', 200000, 10000, 22000, 232000, 'Kaedehara Kazuha - Genshin Impact', 100000, '..imgdata_kostumkazuha.jpg', 'S', 'achul', 'Jalan Kemerdekaan 3, Batu Hijau, Seguling-guling, Ajo City', '6289668914466', '2'),
(12, 1, 3, 1, 40125868, 'achul', '123xxxxxxxxx1231', '+6289668914466', 'Bumi', 'Sabtu, 04-01-2025', '4', 'January', '2025', '06 January 2025', 200000, 10000, 22000, 232000, 'Kaedehara Kazuha - Genshin Impact', 100000, '..imgdata_kostumkazuha.jpg', 'S', 'achul', 'Jalan Kemerdekaan 3, Batu Hijau, Seguling-guling, Ajo City', '6289668914466', '2'),
(13, 1, 3, 1, 40125868, 'achul', '123xxxxxxxxx1231', '+6289668914466', 'Bumi', 'Sabtu, 04-01-2025', '4', 'January', '2025', '06 January 2025', 200000, 10000, 22000, 232000, 'Kaedehara Kazuha - Genshin Impact', 100000, '..imgdata_kostumkazuha.jpg', 'S', 'achul', 'Jalan Kemerdekaan 3, Batu Hijau, Seguling-guling, Ajo City', '6289668914466', '2');

-- --------------------------------------------------------

--
-- Table structure for table `datatoko`
--

CREATE TABLE `datatoko` (
  `id` int NOT NULL,
  `nama_toko` varchar(300) NOT NULL,
  `deskripsi_toko` text,
  `rating_toko` int DEFAULT NULL,
  `jumlah_produk` int DEFAULT NULL,
  `jam_buka` int DEFAULT NULL,
  `jam_tutup` int DEFAULT NULL,
  `jam_buka_display` varchar(300) DEFAULT NULL,
  `jam_tutup_display` varchar(300) DEFAULT NULL,
  `tanggal_daftar` int DEFAULT NULL,
  `kontak_toko` varchar(300) DEFAULT NULL,
  `alamat_toko` varchar(300) DEFAULT NULL,
  `foto_toko` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '..\\img\\icon\\profile.jpg',
  `email_toko` varchar(300) NOT NULL,
  `kata_sandi` varchar(300) NOT NULL,
  `bulan_daftar` varchar(300) DEFAULT NULL,
  `tahun_daftar` varchar(300) DEFAULT NULL,
  `status_update` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `datatoko`
--

INSERT INTO `datatoko` (`id`, `nama_toko`, `deskripsi_toko`, `rating_toko`, `jumlah_produk`, `jam_buka`, `jam_tutup`, `jam_buka_display`, `jam_tutup_display`, `tanggal_daftar`, `kontak_toko`, `alamat_toko`, `foto_toko`, `email_toko`, `kata_sandi`, `bulan_daftar`, `tahun_daftar`, `status_update`) VALUES
(3, 'achul', 'Ini adalah toko achul', NULL, NULL, 10, 20, '10:00 WIB', '20:00 WIB', 28, '+6288888888888888', 'Griya', '../img/data_toko/pp_toko/Achul.JPG', 'arulnasrullah2468@gmail.com', '202cb962ac59075b964b07152d234b70', 'December', '2024', 0),
(5, 'polistore', 'Polibatam 2024', NULL, NULL, 10, 20, '10:00 WIB', '20:00 WIB', 31, '+6288888888888888', 'Polikteknik Negeri Batam', '../img/data_toko/pp_toko/Gedung.jpg', 'polibatam@gmail.com', '202cb962ac59075b964b07152d234b70', 'December', '2024', 0),
(6, 'politeknikstore', 'Polibatam Official store at politeknik negeri batam', NULL, NULL, 10, 21, '10:00 WIB', '21:00 WIB', 4, '+6288888888888888', 'Politeknik Negeri Batam, Teluk Tering', '../img/data_toko/pp_toko/Bendera Polibatam.png', 'polibatam@gmail.com', '202cb962ac59075b964b07152d234b70', 'January', '2025', 0);

-- --------------------------------------------------------

--
-- Table structure for table `elisabet`
--

CREATE TABLE `elisabet` (
  `id` int NOT NULL,
  `nama_baju` varchar(255) DEFAULT NULL,
  `harga_baju` int DEFAULT NULL,
  `foto_baju` varchar(300) DEFAULT NULL,
  `pemilik_baju` varchar(300) DEFAULT NULL,
  `kategori_baju` varchar(300) DEFAULT NULL,
  `ukuran_baju` varchar(300) DEFAULT NULL,
  `ukuran_s` tinyint(1) DEFAULT NULL,
  `ukuran_m` tinyint(1) DEFAULT NULL,
  `ukuran_l` tinyint(1) DEFAULT NULL,
  `tanggal_sewa` varchar(300) DEFAULT NULL,
  `bulan_sewa` varchar(300) DEFAULT NULL,
  `tahun_sewa` varchar(300) DEFAULT NULL,
  `tanggal_pengembalian` varchar(300) DEFAULT NULL,
  `bulan_pengembalian` varchar(300) DEFAULT NULL,
  `tahun_pengembalian` varchar(300) DEFAULT NULL,
  `alamat_pengambilan` varchar(300) DEFAULT NULL,
  `nama_penyewa` varchar(300) DEFAULT NULL,
  `alamat_penyewa` varchar(300) DEFAULT NULL,
  `nik_penyewa` varchar(300) DEFAULT NULL,
  `kontak_penyewa` varchar(300) DEFAULT NULL,
  `status_baju` varchar(300) DEFAULT NULL,
  `blokir_akun` tinyint(1) DEFAULT NULL,
  `id_databaju` int DEFAULT NULL,
  `id_toko` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `elisabet`
--

INSERT INTO `elisabet` (`id`, `nama_baju`, `harga_baju`, `foto_baju`, `pemilik_baju`, `kategori_baju`, `ukuran_baju`, `ukuran_s`, `ukuran_m`, `ukuran_l`, `tanggal_sewa`, `bulan_sewa`, `tahun_sewa`, `tanggal_pengembalian`, `bulan_pengembalian`, `tahun_pengembalian`, `alamat_pengambilan`, `nama_penyewa`, `alamat_penyewa`, `nik_penyewa`, `kontak_penyewa`, `status_baju`, `blokir_akun`, `id_databaju`, `id_toko`) VALUES
(3, 'Kaedehara Kazuha - Genshin Impact', 100000, '..\\img\\data_kostum\\kazuha.jpg', 'achul', 'Cosplay', 'M', 0, 1, 0, '5', 'January', '2025', NULL, NULL, NULL, 'Jalan Kemerdekaan 3, Batu Hijau, Seguling-guling, Ajo City', 'elisabet', NULL, NULL, NULL, NULL, NULL, 1, 3);

-- --------------------------------------------------------

--
-- Table structure for table `eren`
--

CREATE TABLE `eren` (
  `id` int NOT NULL,
  `nama_baju` varchar(255) DEFAULT NULL,
  `harga_baju` int DEFAULT NULL,
  `foto_baju` varchar(300) DEFAULT NULL,
  `pemilik_baju` varchar(300) DEFAULT NULL,
  `kategori_baju` varchar(300) DEFAULT NULL,
  `ukuran_baju` varchar(300) DEFAULT NULL,
  `ukuran_s` tinyint(1) DEFAULT NULL,
  `ukuran_m` tinyint(1) DEFAULT NULL,
  `ukuran_l` tinyint(1) DEFAULT NULL,
  `tanggal_sewa` varchar(300) DEFAULT NULL,
  `bulan_sewa` varchar(300) DEFAULT NULL,
  `tahun_sewa` varchar(300) DEFAULT NULL,
  `tanggal_pengembalian` varchar(300) DEFAULT NULL,
  `bulan_pengembalian` varchar(300) DEFAULT NULL,
  `tahun_pengembalian` varchar(300) DEFAULT NULL,
  `alamat_pengambilan` varchar(300) DEFAULT NULL,
  `nama_penyewa` varchar(300) DEFAULT NULL,
  `alamat_penyewa` varchar(300) DEFAULT NULL,
  `nik_penyewa` varchar(300) DEFAULT NULL,
  `kontak_penyewa` varchar(300) DEFAULT NULL,
  `status_baju` varchar(300) DEFAULT NULL,
  `blokir_akun` tinyint(1) DEFAULT NULL,
  `id_databaju` int DEFAULT NULL,
  `id_toko` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `footer`
--

CREATE TABLE `footer` (
  `footer` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `footer`
--

INSERT INTO `footer` (`footer`) VALUES
('<footer> <div class=\"waves\"> <div class=\"wave\" id=\"wave1\"></div> <div class=\"wave\" id=\"wave2\"></div> <div class=\"wave\" id=\"wave3\"></div> <div class=\"wave\" id=\"wave4\"></div> </div> <div class=\"d-flex align-items-center mb-3\"> <img src=\"../img/icon/logo2.png\" alt=\"logo\"> </div> <div class=\"row d-flex container-fluid\"> <div class=\"col-2 gap-3 d-flex mx-auto align-items-end justify-content-center py-2\"> <a class=\"fs-3 text-white hover-overlay\" href=\"https://www.youtube.com/@waju-sekopsekop\"><ion-icon name=\"logo-youtube\"></ion-icon></a> <a class=\"fs-3 text-white hover-overlay\" href=\"https://www.instagram.com/_waajuu?igsh=NHdpbmplaGc3c3l0\"><ion-icon name=\"logo-instagram\"></ion-icon></a> </div> <div class=\"col-8 row d-flex align-items-center justify-content-center\"> <div class=\"m-auto d-flex align-items-center justify-content-center text-center lh-base text-break flex-wrap\"> <p class=\"text_style text-center mx-2 p-0\">MANPRO: HAMMIM TOHARI </p> <p class=\"text_style text-center mx-2 p-0\">KETUA: NASRULLAH </p> <p class=\"text_style text-center mx-2 p-0\">BACK END: BUNGA CITRA LESTARI </p> <p class=\"text_style text-center mx-2 p-0\">BACK END: BIRGITA ANASTASYA </p> <p class=\"text_style text-center mx-2 p-0\">FRONT END: ELISABETH MARGARETA </p> <p class=\"text_style text-center mx-2 p-0\">BACK END: ELSA VERONICA </p> <p class=\"text_style text-center mx-2 p-0\">UI/UX: SALSABILA</p> </div> </div> <div class=\"col-2 gap-3 d-flex mx-auto align-items-end justify-content-center py-3\"> <a class=\"fs-3 text-white hover-overlay\" href=\"../halaman_keranjang/halaman_keranjang.php\"><ion-icon name=\"cart-outline\"></ion-icon></a> <a class=\"fs-3 text-white hover-overlay\" href=\"../WAJU/halaman_list/list_sewa.php \"><ion-icon name=\"person-sharp\"></ion-icon></a> </div> </div> <hr class=\"mb-0\" style=\"width: 100%; opacity: 80%; color: white;\"> <p class=\"copyright p-3 m-0\">© PBL Tim WAJU Sekupang - Politeknik Negeri Batam 2024</p> </footer> <script type=\"module\" src=\"https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js\"></script> <script nomodule src=\"https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js\"></script>');

-- --------------------------------------------------------

--
-- Table structure for table `putra`
--

CREATE TABLE `putra` (
  `id` int NOT NULL,
  `nama_baju` varchar(255) DEFAULT NULL,
  `harga_baju` int DEFAULT NULL,
  `foto_baju` varchar(300) DEFAULT NULL,
  `pemilik_baju` varchar(300) DEFAULT NULL,
  `kategori_baju` varchar(300) DEFAULT NULL,
  `ukuran_baju` varchar(300) DEFAULT NULL,
  `ukuran_s` tinyint(1) DEFAULT NULL,
  `ukuran_m` tinyint(1) DEFAULT NULL,
  `ukuran_l` tinyint(1) DEFAULT NULL,
  `tanggal_sewa` varchar(300) DEFAULT NULL,
  `bulan_sewa` varchar(300) DEFAULT NULL,
  `tahun_sewa` varchar(300) DEFAULT NULL,
  `tanggal_pengembalian` varchar(300) DEFAULT NULL,
  `bulan_pengembalian` varchar(300) DEFAULT NULL,
  `tahun_pengembalian` varchar(300) DEFAULT NULL,
  `alamat_pengambilan` varchar(300) DEFAULT NULL,
  `nama_penyewa` varchar(300) DEFAULT NULL,
  `alamat_penyewa` varchar(300) DEFAULT NULL,
  `nik_penyewa` varchar(300) DEFAULT NULL,
  `kontak_penyewa` varchar(300) DEFAULT NULL,
  `status_baju` varchar(300) DEFAULT NULL,
  `blokir_akun` tinyint(1) DEFAULT NULL,
  `id_databaju` int DEFAULT NULL,
  `id_toko` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `toko`
--

CREATE TABLE `toko` (
  `id_baju` int NOT NULL,
  `nama_baju` varchar(300) DEFAULT NULL,
  `kategori_baju` varchar(300) DEFAULT NULL,
  `harga_baju` int DEFAULT NULL,
  `rating_baju` int DEFAULT NULL,
  `foto_baju` varchar(300) DEFAULT NULL,
  `deskripsi_baju` text,
  `status_tersedia` tinyint(1) DEFAULT '1',
  `nama_pemilik` varchar(300) DEFAULT NULL,
  `kontak_pemilik` varchar(300) DEFAULT NULL,
  `alamat_pemilik` varchar(300) DEFAULT NULL,
  `id_pemilik` int DEFAULT NULL,
  `ukuran_s` int DEFAULT NULL,
  `ukuran_m` int DEFAULT NULL,
  `ukuran_l` int DEFAULT NULL,
  `jumlah_baju` int GENERATED ALWAYS AS (((`ukuran_s` + `ukuran_m`) + `ukuran_l`)) STORED,
  `tersewa_baju_s` int DEFAULT NULL,
  `tersewa_baju_m` int DEFAULT NULL,
  `tersewa_baju_l` int DEFAULT NULL,
  `jumlah_tersewa` int GENERATED ALWAYS AS (((`tersewa_baju_s` + `tersewa_baju_m`) + `tersewa_baju_l`)) STORED,
  `tanggal_1_s` int DEFAULT NULL,
  `tanggal_1_m` int DEFAULT NULL,
  `tanggal_1_l` int DEFAULT NULL,
  `tanggal_1` int GENERATED ALWAYS AS (((`tanggal_1_s` + `tanggal_1_m`) + `tanggal_1_l`)) STORED,
  `tanggal_2_s` int DEFAULT NULL,
  `tanggal_2_m` int DEFAULT NULL,
  `tanggal_2_l` int DEFAULT NULL,
  `tanggal_2` int GENERATED ALWAYS AS (((`tanggal_2_s` + `tanggal_2_m`) + `tanggal_2_l`)) STORED,
  `tanggal_3_s` int DEFAULT NULL,
  `tanggal_3_m` int DEFAULT NULL,
  `tanggal_3_l` int DEFAULT NULL,
  `tanggal_3` int GENERATED ALWAYS AS (((`tanggal_3_s` + `tanggal_3_m`) + `tanggal_3_l`)) STORED,
  `tanggal_4_s` int DEFAULT NULL,
  `tanggal_4_m` int DEFAULT NULL,
  `tanggal_4_l` int DEFAULT NULL,
  `tanggal_4` int GENERATED ALWAYS AS (((`tanggal_4_s` + `tanggal_4_m`) + `tanggal_4_l`)) STORED,
  `tanggal_5_s` int DEFAULT NULL,
  `tanggal_5_m` int DEFAULT NULL,
  `tanggal_5_l` int DEFAULT NULL,
  `tanggal_5` int GENERATED ALWAYS AS (((`tanggal_5_s` + `tanggal_5_m`) + `tanggal_5_l`)) STORED,
  `tanggal_6_s` int DEFAULT NULL,
  `tanggal_6_m` int DEFAULT NULL,
  `tanggal_6_l` int DEFAULT NULL,
  `tanggal_6` int GENERATED ALWAYS AS (((`tanggal_6_s` + `tanggal_6_m`) + `tanggal_6_l`)) STORED,
  `tanggal_7_s` int DEFAULT NULL,
  `tanggal_7_m` int DEFAULT NULL,
  `tanggal_7_l` int DEFAULT NULL,
  `tanggal_7` int GENERATED ALWAYS AS (((`tanggal_7_s` + `tanggal_7_m`) + `tanggal_7_l`)) STORED,
  `tanggal_8_s` int DEFAULT NULL,
  `tanggal_8_m` int DEFAULT NULL,
  `tanggal_8_l` int DEFAULT NULL,
  `tanggal_8` int GENERATED ALWAYS AS (((`tanggal_8_s` + `tanggal_8_m`) + `tanggal_8_l`)) STORED,
  `tanggal_9_s` int DEFAULT NULL,
  `tanggal_9_m` int DEFAULT NULL,
  `tanggal_9_l` int DEFAULT NULL,
  `tanggal_9` int GENERATED ALWAYS AS (((`tanggal_9_s` + `tanggal_9_m`) + `tanggal_9_l`)) STORED,
  `tanggal_10_s` int DEFAULT NULL,
  `tanggal_10_m` int DEFAULT NULL,
  `tanggal_10_l` int DEFAULT NULL,
  `tanggal_10` int GENERATED ALWAYS AS (((`tanggal_10_s` + `tanggal_10_m`) + `tanggal_10_l`)) STORED,
  `tanggal_11_s` int DEFAULT NULL,
  `tanggal_11_m` int DEFAULT NULL,
  `tanggal_11_l` int DEFAULT NULL,
  `tanggal_11` int GENERATED ALWAYS AS (((`tanggal_11_s` + `tanggal_11_m`) + `tanggal_11_l`)) STORED,
  `tanggal_12_s` int DEFAULT NULL,
  `tanggal_12_m` int DEFAULT NULL,
  `tanggal_12_l` int DEFAULT NULL,
  `tanggal_12` int GENERATED ALWAYS AS (((`tanggal_12_s` + `tanggal_12_m`) + `tanggal_12_l`)) STORED,
  `tanggal_13_s` int DEFAULT NULL,
  `tanggal_13_m` int DEFAULT NULL,
  `tanggal_13_l` int DEFAULT NULL,
  `tanggal_13` int GENERATED ALWAYS AS (((`tanggal_13_s` + `tanggal_13_m`) + `tanggal_13_l`)) STORED,
  `tanggal_14_s` int DEFAULT NULL,
  `tanggal_14_m` int DEFAULT NULL,
  `tanggal_14_l` int DEFAULT NULL,
  `tanggal_14` int GENERATED ALWAYS AS (((`tanggal_14_s` + `tanggal_14_m`) + `tanggal_14_l`)) STORED,
  `tanggal_15_s` int DEFAULT NULL,
  `tanggal_15_m` int DEFAULT NULL,
  `tanggal_15_l` int DEFAULT NULL,
  `tanggal_15` int GENERATED ALWAYS AS (((`tanggal_15_s` + `tanggal_15_m`) + `tanggal_15_l`)) STORED,
  `tanggal_16_s` int DEFAULT NULL,
  `tanggal_16_m` int DEFAULT NULL,
  `tanggal_16_l` int DEFAULT NULL,
  `tanggal_16` int GENERATED ALWAYS AS (((`tanggal_16_s` + `tanggal_16_m`) + `tanggal_16_l`)) STORED,
  `tanggal_17_s` int DEFAULT NULL,
  `tanggal_17_m` int DEFAULT NULL,
  `tanggal_17_l` int DEFAULT NULL,
  `tanggal_17` int GENERATED ALWAYS AS (((`tanggal_17_s` + `tanggal_17_m`) + `tanggal_17_l`)) STORED,
  `tanggal_18_s` int DEFAULT NULL,
  `tanggal_18_m` int DEFAULT NULL,
  `tanggal_18_l` int DEFAULT NULL,
  `tanggal_18` int GENERATED ALWAYS AS (((`tanggal_18_s` + `tanggal_18_m`) + `tanggal_18_l`)) STORED,
  `tanggal_19_s` int DEFAULT NULL,
  `tanggal_19_m` int DEFAULT NULL,
  `tanggal_19_l` int DEFAULT NULL,
  `tanggal_19` int GENERATED ALWAYS AS (((`tanggal_19_s` + `tanggal_19_m`) + `tanggal_19_l`)) STORED,
  `tanggal_20_s` int DEFAULT NULL,
  `tanggal_20_m` int DEFAULT NULL,
  `tanggal_20_l` int DEFAULT NULL,
  `tanggal_20` int GENERATED ALWAYS AS (((`tanggal_20_s` + `tanggal_20_m`) + `tanggal_20_l`)) STORED,
  `tanggal_21_s` int DEFAULT NULL,
  `tanggal_21_m` int DEFAULT NULL,
  `tanggal_21_l` int DEFAULT NULL,
  `tanggal_21` int GENERATED ALWAYS AS (((`tanggal_21_s` + `tanggal_21_m`) + `tanggal_21_l`)) STORED,
  `tanggal_22_s` int DEFAULT NULL,
  `tanggal_22_m` int DEFAULT NULL,
  `tanggal_22_l` int DEFAULT NULL,
  `tanggal_22` int GENERATED ALWAYS AS (((`tanggal_22_s` + `tanggal_22_m`) + `tanggal_22_l`)) STORED,
  `tanggal_23_s` int DEFAULT NULL,
  `tanggal_23_m` int DEFAULT NULL,
  `tanggal_23_l` int DEFAULT NULL,
  `tanggal_23` int GENERATED ALWAYS AS (((`tanggal_23_s` + `tanggal_23_m`) + `tanggal_23_l`)) STORED,
  `tanggal_24_s` int DEFAULT NULL,
  `tanggal_24_m` int DEFAULT NULL,
  `tanggal_24_l` int DEFAULT NULL,
  `tanggal_24` int GENERATED ALWAYS AS (((`tanggal_24_s` + `tanggal_24_m`) + `tanggal_24_l`)) STORED,
  `tanggal_25_s` int DEFAULT NULL,
  `tanggal_25_m` int DEFAULT NULL,
  `tanggal_25_l` int DEFAULT NULL,
  `tanggal_25` int GENERATED ALWAYS AS (((`tanggal_25_s` + `tanggal_25_m`) + `tanggal_25_l`)) STORED,
  `tanggal_26_s` int DEFAULT NULL,
  `tanggal_26_m` int DEFAULT NULL,
  `tanggal_26_l` int DEFAULT NULL,
  `tanggal_26` int GENERATED ALWAYS AS (((`tanggal_26_s` + `tanggal_26_m`) + `tanggal_26_l`)) STORED,
  `tanggal_27_s` int DEFAULT NULL,
  `tanggal_27_m` int DEFAULT NULL,
  `tanggal_27_l` int DEFAULT NULL,
  `tanggal_27` int GENERATED ALWAYS AS (((`tanggal_27_s` + `tanggal_27_m`) + `tanggal_27_l`)) STORED,
  `tanggal_28_s` int DEFAULT NULL,
  `tanggal_28_m` int DEFAULT NULL,
  `tanggal_28_l` int DEFAULT NULL,
  `tanggal_28` int GENERATED ALWAYS AS (((`tanggal_28_s` + `tanggal_28_m`) + `tanggal_28_l`)) STORED,
  `tanggal_29_s` int DEFAULT NULL,
  `tanggal_29_m` int DEFAULT NULL,
  `tanggal_29_l` int DEFAULT NULL,
  `tanggal_29` int GENERATED ALWAYS AS (((`tanggal_29_s` + `tanggal_29_m`) + `tanggal_29_l`)) STORED,
  `tanggal_30_s` int DEFAULT NULL,
  `tanggal_30_m` int DEFAULT NULL,
  `tanggal_30_l` int DEFAULT NULL,
  `tanggal_30` int GENERATED ALWAYS AS (((`tanggal_30_s` + `tanggal_30_m`) + `tanggal_30_l`)) STORED,
  `tanggal_31_s` int DEFAULT NULL,
  `tanggal_31_m` int DEFAULT NULL,
  `tanggal_31_l` int DEFAULT NULL,
  `tanggal_31` int GENERATED ALWAYS AS (((`tanggal_31_s` + `tanggal_31_m`) + `tanggal_31_l`)) STORED
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `toko_achul`
--

CREATE TABLE `toko_achul` (
  `id_baju` int NOT NULL,
  `nama_baju` varchar(300) DEFAULT NULL,
  `kategori_baju` varchar(300) DEFAULT NULL,
  `harga_baju` int DEFAULT NULL,
  `rating_baju` int DEFAULT NULL,
  `foto_baju` varchar(300) DEFAULT NULL,
  `deskripsi_baju` text,
  `status_tersedia` tinyint(1) DEFAULT '1',
  `nama_pemilik` varchar(300) DEFAULT NULL,
  `kontak_pemilik` varchar(300) DEFAULT NULL,
  `alamat_pemilik` varchar(300) DEFAULT NULL,
  `id_pemilik` int DEFAULT NULL,
  `ukuran_s` int DEFAULT NULL,
  `ukuran_m` int DEFAULT NULL,
  `ukuran_l` int DEFAULT NULL,
  `jumlah_baju` int GENERATED ALWAYS AS (((`ukuran_s` + `ukuran_m`) + `ukuran_l`)) STORED,
  `tersewa_baju_s` int DEFAULT NULL,
  `tersewa_baju_m` int DEFAULT NULL,
  `tersewa_baju_l` int DEFAULT NULL,
  `jumlah_tersewa` int GENERATED ALWAYS AS (((`tersewa_baju_s` + `tersewa_baju_m`) + `tersewa_baju_l`)) STORED,
  `tanggal_1_s` int DEFAULT NULL,
  `tanggal_1_m` int DEFAULT NULL,
  `tanggal_1_l` int DEFAULT NULL,
  `tanggal_1` int GENERATED ALWAYS AS (((`tanggal_1_s` + `tanggal_1_m`) + `tanggal_1_l`)) STORED,
  `tanggal_2_s` int DEFAULT NULL,
  `tanggal_2_m` int DEFAULT NULL,
  `tanggal_2_l` int DEFAULT NULL,
  `tanggal_2` int GENERATED ALWAYS AS (((`tanggal_2_s` + `tanggal_2_m`) + `tanggal_2_l`)) STORED,
  `tanggal_3_s` int DEFAULT NULL,
  `tanggal_3_m` int DEFAULT NULL,
  `tanggal_3_l` int DEFAULT NULL,
  `tanggal_3` int GENERATED ALWAYS AS (((`tanggal_3_s` + `tanggal_3_m`) + `tanggal_3_l`)) STORED,
  `tanggal_4_s` int DEFAULT NULL,
  `tanggal_4_m` int DEFAULT NULL,
  `tanggal_4_l` int DEFAULT NULL,
  `tanggal_4` int GENERATED ALWAYS AS (((`tanggal_4_s` + `tanggal_4_m`) + `tanggal_4_l`)) STORED,
  `tanggal_5_s` int DEFAULT NULL,
  `tanggal_5_m` int DEFAULT NULL,
  `tanggal_5_l` int DEFAULT NULL,
  `tanggal_5` int GENERATED ALWAYS AS (((`tanggal_5_s` + `tanggal_5_m`) + `tanggal_5_l`)) STORED,
  `tanggal_6_s` int DEFAULT NULL,
  `tanggal_6_m` int DEFAULT NULL,
  `tanggal_6_l` int DEFAULT NULL,
  `tanggal_6` int GENERATED ALWAYS AS (((`tanggal_6_s` + `tanggal_6_m`) + `tanggal_6_l`)) STORED,
  `tanggal_7_s` int DEFAULT NULL,
  `tanggal_7_m` int DEFAULT NULL,
  `tanggal_7_l` int DEFAULT NULL,
  `tanggal_7` int GENERATED ALWAYS AS (((`tanggal_7_s` + `tanggal_7_m`) + `tanggal_7_l`)) STORED,
  `tanggal_8_s` int DEFAULT NULL,
  `tanggal_8_m` int DEFAULT NULL,
  `tanggal_8_l` int DEFAULT NULL,
  `tanggal_8` int GENERATED ALWAYS AS (((`tanggal_8_s` + `tanggal_8_m`) + `tanggal_8_l`)) STORED,
  `tanggal_9_s` int DEFAULT NULL,
  `tanggal_9_m` int DEFAULT NULL,
  `tanggal_9_l` int DEFAULT NULL,
  `tanggal_9` int GENERATED ALWAYS AS (((`tanggal_9_s` + `tanggal_9_m`) + `tanggal_9_l`)) STORED,
  `tanggal_10_s` int DEFAULT NULL,
  `tanggal_10_m` int DEFAULT NULL,
  `tanggal_10_l` int DEFAULT NULL,
  `tanggal_10` int GENERATED ALWAYS AS (((`tanggal_10_s` + `tanggal_10_m`) + `tanggal_10_l`)) STORED,
  `tanggal_11_s` int DEFAULT NULL,
  `tanggal_11_m` int DEFAULT NULL,
  `tanggal_11_l` int DEFAULT NULL,
  `tanggal_11` int GENERATED ALWAYS AS (((`tanggal_11_s` + `tanggal_11_m`) + `tanggal_11_l`)) STORED,
  `tanggal_12_s` int DEFAULT NULL,
  `tanggal_12_m` int DEFAULT NULL,
  `tanggal_12_l` int DEFAULT NULL,
  `tanggal_12` int GENERATED ALWAYS AS (((`tanggal_12_s` + `tanggal_12_m`) + `tanggal_12_l`)) STORED,
  `tanggal_13_s` int DEFAULT NULL,
  `tanggal_13_m` int DEFAULT NULL,
  `tanggal_13_l` int DEFAULT NULL,
  `tanggal_13` int GENERATED ALWAYS AS (((`tanggal_13_s` + `tanggal_13_m`) + `tanggal_13_l`)) STORED,
  `tanggal_14_s` int DEFAULT NULL,
  `tanggal_14_m` int DEFAULT NULL,
  `tanggal_14_l` int DEFAULT NULL,
  `tanggal_14` int GENERATED ALWAYS AS (((`tanggal_14_s` + `tanggal_14_m`) + `tanggal_14_l`)) STORED,
  `tanggal_15_s` int DEFAULT NULL,
  `tanggal_15_m` int DEFAULT NULL,
  `tanggal_15_l` int DEFAULT NULL,
  `tanggal_15` int GENERATED ALWAYS AS (((`tanggal_15_s` + `tanggal_15_m`) + `tanggal_15_l`)) STORED,
  `tanggal_16_s` int DEFAULT NULL,
  `tanggal_16_m` int DEFAULT NULL,
  `tanggal_16_l` int DEFAULT NULL,
  `tanggal_16` int GENERATED ALWAYS AS (((`tanggal_16_s` + `tanggal_16_m`) + `tanggal_16_l`)) STORED,
  `tanggal_17_s` int DEFAULT NULL,
  `tanggal_17_m` int DEFAULT NULL,
  `tanggal_17_l` int DEFAULT NULL,
  `tanggal_17` int GENERATED ALWAYS AS (((`tanggal_17_s` + `tanggal_17_m`) + `tanggal_17_l`)) STORED,
  `tanggal_18_s` int DEFAULT NULL,
  `tanggal_18_m` int DEFAULT NULL,
  `tanggal_18_l` int DEFAULT NULL,
  `tanggal_18` int GENERATED ALWAYS AS (((`tanggal_18_s` + `tanggal_18_m`) + `tanggal_18_l`)) STORED,
  `tanggal_19_s` int DEFAULT NULL,
  `tanggal_19_m` int DEFAULT NULL,
  `tanggal_19_l` int DEFAULT NULL,
  `tanggal_19` int GENERATED ALWAYS AS (((`tanggal_19_s` + `tanggal_19_m`) + `tanggal_19_l`)) STORED,
  `tanggal_20_s` int DEFAULT NULL,
  `tanggal_20_m` int DEFAULT NULL,
  `tanggal_20_l` int DEFAULT NULL,
  `tanggal_20` int GENERATED ALWAYS AS (((`tanggal_20_s` + `tanggal_20_m`) + `tanggal_20_l`)) STORED,
  `tanggal_21_s` int DEFAULT NULL,
  `tanggal_21_m` int DEFAULT NULL,
  `tanggal_21_l` int DEFAULT NULL,
  `tanggal_21` int GENERATED ALWAYS AS (((`tanggal_21_s` + `tanggal_21_m`) + `tanggal_21_l`)) STORED,
  `tanggal_22_s` int DEFAULT NULL,
  `tanggal_22_m` int DEFAULT NULL,
  `tanggal_22_l` int DEFAULT NULL,
  `tanggal_22` int GENERATED ALWAYS AS (((`tanggal_22_s` + `tanggal_22_m`) + `tanggal_22_l`)) STORED,
  `tanggal_23_s` int DEFAULT NULL,
  `tanggal_23_m` int DEFAULT NULL,
  `tanggal_23_l` int DEFAULT NULL,
  `tanggal_23` int GENERATED ALWAYS AS (((`tanggal_23_s` + `tanggal_23_m`) + `tanggal_23_l`)) STORED,
  `tanggal_24_s` int DEFAULT NULL,
  `tanggal_24_m` int DEFAULT NULL,
  `tanggal_24_l` int DEFAULT NULL,
  `tanggal_24` int GENERATED ALWAYS AS (((`tanggal_24_s` + `tanggal_24_m`) + `tanggal_24_l`)) STORED,
  `tanggal_25_s` int DEFAULT NULL,
  `tanggal_25_m` int DEFAULT NULL,
  `tanggal_25_l` int DEFAULT NULL,
  `tanggal_25` int GENERATED ALWAYS AS (((`tanggal_25_s` + `tanggal_25_m`) + `tanggal_25_l`)) STORED,
  `tanggal_26_s` int DEFAULT NULL,
  `tanggal_26_m` int DEFAULT NULL,
  `tanggal_26_l` int DEFAULT NULL,
  `tanggal_26` int GENERATED ALWAYS AS (((`tanggal_26_s` + `tanggal_26_m`) + `tanggal_26_l`)) STORED,
  `tanggal_27_s` int DEFAULT NULL,
  `tanggal_27_m` int DEFAULT NULL,
  `tanggal_27_l` int DEFAULT NULL,
  `tanggal_27` int GENERATED ALWAYS AS (((`tanggal_27_s` + `tanggal_27_m`) + `tanggal_27_l`)) STORED,
  `tanggal_28_s` int DEFAULT NULL,
  `tanggal_28_m` int DEFAULT NULL,
  `tanggal_28_l` int DEFAULT NULL,
  `tanggal_28` int GENERATED ALWAYS AS (((`tanggal_28_s` + `tanggal_28_m`) + `tanggal_28_l`)) STORED,
  `tanggal_29_s` int DEFAULT NULL,
  `tanggal_29_m` int DEFAULT NULL,
  `tanggal_29_l` int DEFAULT NULL,
  `tanggal_29` int GENERATED ALWAYS AS (((`tanggal_29_s` + `tanggal_29_m`) + `tanggal_29_l`)) STORED,
  `tanggal_30_s` int DEFAULT NULL,
  `tanggal_30_m` int DEFAULT NULL,
  `tanggal_30_l` int DEFAULT NULL,
  `tanggal_30` int GENERATED ALWAYS AS (((`tanggal_30_s` + `tanggal_30_m`) + `tanggal_30_l`)) STORED,
  `tanggal_31_s` int DEFAULT NULL,
  `tanggal_31_m` int DEFAULT NULL,
  `tanggal_31_l` int DEFAULT NULL,
  `tanggal_31` int GENERATED ALWAYS AS (((`tanggal_31_s` + `tanggal_31_m`) + `tanggal_31_l`)) STORED
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `toko_achul`
--

INSERT INTO `toko_achul` (`id_baju`, `nama_baju`, `kategori_baju`, `harga_baju`, `rating_baju`, `foto_baju`, `deskripsi_baju`, `status_tersedia`, `nama_pemilik`, `kontak_pemilik`, `alamat_pemilik`, `id_pemilik`, `ukuran_s`, `ukuran_m`, `ukuran_l`, `tersewa_baju_s`, `tersewa_baju_m`, `tersewa_baju_l`, `tanggal_1_s`, `tanggal_1_m`, `tanggal_1_l`, `tanggal_2_s`, `tanggal_2_m`, `tanggal_2_l`, `tanggal_3_s`, `tanggal_3_m`, `tanggal_3_l`, `tanggal_4_s`, `tanggal_4_m`, `tanggal_4_l`, `tanggal_5_s`, `tanggal_5_m`, `tanggal_5_l`, `tanggal_6_s`, `tanggal_6_m`, `tanggal_6_l`, `tanggal_7_s`, `tanggal_7_m`, `tanggal_7_l`, `tanggal_8_s`, `tanggal_8_m`, `tanggal_8_l`, `tanggal_9_s`, `tanggal_9_m`, `tanggal_9_l`, `tanggal_10_s`, `tanggal_10_m`, `tanggal_10_l`, `tanggal_11_s`, `tanggal_11_m`, `tanggal_11_l`, `tanggal_12_s`, `tanggal_12_m`, `tanggal_12_l`, `tanggal_13_s`, `tanggal_13_m`, `tanggal_13_l`, `tanggal_14_s`, `tanggal_14_m`, `tanggal_14_l`, `tanggal_15_s`, `tanggal_15_m`, `tanggal_15_l`, `tanggal_16_s`, `tanggal_16_m`, `tanggal_16_l`, `tanggal_17_s`, `tanggal_17_m`, `tanggal_17_l`, `tanggal_18_s`, `tanggal_18_m`, `tanggal_18_l`, `tanggal_19_s`, `tanggal_19_m`, `tanggal_19_l`, `tanggal_20_s`, `tanggal_20_m`, `tanggal_20_l`, `tanggal_21_s`, `tanggal_21_m`, `tanggal_21_l`, `tanggal_22_s`, `tanggal_22_m`, `tanggal_22_l`, `tanggal_23_s`, `tanggal_23_m`, `tanggal_23_l`, `tanggal_24_s`, `tanggal_24_m`, `tanggal_24_l`, `tanggal_25_s`, `tanggal_25_m`, `tanggal_25_l`, `tanggal_26_s`, `tanggal_26_m`, `tanggal_26_l`, `tanggal_27_s`, `tanggal_27_m`, `tanggal_27_l`, `tanggal_28_s`, `tanggal_28_m`, `tanggal_28_l`, `tanggal_29_s`, `tanggal_29_m`, `tanggal_29_l`, `tanggal_30_s`, `tanggal_30_m`, `tanggal_30_l`, `tanggal_31_s`, `tanggal_31_m`, `tanggal_31_l`) VALUES
(1, 'Polibatam Original', 'Polibatam', 50000, NULL, '../img/data_kostum/Gedung.jpg', 'Polibatam Original', 1, 'achul', '+6288888888888888', 'Griya', 3, 2, 2, 2, NULL, NULL, NULL, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2),
(2, 'Polibatam Original', 'Polibatam', 50000, NULL, '../img/data_kostum/Gedung.jpg', 'Polibatam Original', 1, 'achul', '+6288888888888888', 'Griya', 3, 2, 2, 2, NULL, NULL, NULL, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `toko_polistore`
--

CREATE TABLE `toko_polistore` (
  `id_baju` int NOT NULL,
  `nama_baju` varchar(300) DEFAULT NULL,
  `kategori_baju` varchar(300) DEFAULT NULL,
  `harga_baju` int DEFAULT NULL,
  `rating_baju` int DEFAULT NULL,
  `foto_baju` varchar(300) DEFAULT NULL,
  `deskripsi_baju` text,
  `status_tersedia` tinyint(1) DEFAULT '1',
  `nama_pemilik` varchar(300) DEFAULT NULL,
  `kontak_pemilik` varchar(300) DEFAULT NULL,
  `alamat_pemilik` varchar(300) DEFAULT NULL,
  `id_pemilik` int DEFAULT NULL,
  `ukuran_s` int DEFAULT NULL,
  `ukuran_m` int DEFAULT NULL,
  `ukuran_l` int DEFAULT NULL,
  `jumlah_baju` int GENERATED ALWAYS AS (((`ukuran_s` + `ukuran_m`) + `ukuran_l`)) STORED,
  `tersewa_baju_s` int DEFAULT NULL,
  `tersewa_baju_m` int DEFAULT NULL,
  `tersewa_baju_l` int DEFAULT NULL,
  `jumlah_tersewa` int GENERATED ALWAYS AS (((`tersewa_baju_s` + `tersewa_baju_m`) + `tersewa_baju_l`)) STORED,
  `tanggal_1_s` int DEFAULT NULL,
  `tanggal_1_m` int DEFAULT NULL,
  `tanggal_1_l` int DEFAULT NULL,
  `tanggal_1` int GENERATED ALWAYS AS (((`tanggal_1_s` + `tanggal_1_m`) + `tanggal_1_l`)) STORED,
  `tanggal_2_s` int DEFAULT NULL,
  `tanggal_2_m` int DEFAULT NULL,
  `tanggal_2_l` int DEFAULT NULL,
  `tanggal_2` int GENERATED ALWAYS AS (((`tanggal_2_s` + `tanggal_2_m`) + `tanggal_2_l`)) STORED,
  `tanggal_3_s` int DEFAULT NULL,
  `tanggal_3_m` int DEFAULT NULL,
  `tanggal_3_l` int DEFAULT NULL,
  `tanggal_3` int GENERATED ALWAYS AS (((`tanggal_3_s` + `tanggal_3_m`) + `tanggal_3_l`)) STORED,
  `tanggal_4_s` int DEFAULT NULL,
  `tanggal_4_m` int DEFAULT NULL,
  `tanggal_4_l` int DEFAULT NULL,
  `tanggal_4` int GENERATED ALWAYS AS (((`tanggal_4_s` + `tanggal_4_m`) + `tanggal_4_l`)) STORED,
  `tanggal_5_s` int DEFAULT NULL,
  `tanggal_5_m` int DEFAULT NULL,
  `tanggal_5_l` int DEFAULT NULL,
  `tanggal_5` int GENERATED ALWAYS AS (((`tanggal_5_s` + `tanggal_5_m`) + `tanggal_5_l`)) STORED,
  `tanggal_6_s` int DEFAULT NULL,
  `tanggal_6_m` int DEFAULT NULL,
  `tanggal_6_l` int DEFAULT NULL,
  `tanggal_6` int GENERATED ALWAYS AS (((`tanggal_6_s` + `tanggal_6_m`) + `tanggal_6_l`)) STORED,
  `tanggal_7_s` int DEFAULT NULL,
  `tanggal_7_m` int DEFAULT NULL,
  `tanggal_7_l` int DEFAULT NULL,
  `tanggal_7` int GENERATED ALWAYS AS (((`tanggal_7_s` + `tanggal_7_m`) + `tanggal_7_l`)) STORED,
  `tanggal_8_s` int DEFAULT NULL,
  `tanggal_8_m` int DEFAULT NULL,
  `tanggal_8_l` int DEFAULT NULL,
  `tanggal_8` int GENERATED ALWAYS AS (((`tanggal_8_s` + `tanggal_8_m`) + `tanggal_8_l`)) STORED,
  `tanggal_9_s` int DEFAULT NULL,
  `tanggal_9_m` int DEFAULT NULL,
  `tanggal_9_l` int DEFAULT NULL,
  `tanggal_9` int GENERATED ALWAYS AS (((`tanggal_9_s` + `tanggal_9_m`) + `tanggal_9_l`)) STORED,
  `tanggal_10_s` int DEFAULT NULL,
  `tanggal_10_m` int DEFAULT NULL,
  `tanggal_10_l` int DEFAULT NULL,
  `tanggal_10` int GENERATED ALWAYS AS (((`tanggal_10_s` + `tanggal_10_m`) + `tanggal_10_l`)) STORED,
  `tanggal_11_s` int DEFAULT NULL,
  `tanggal_11_m` int DEFAULT NULL,
  `tanggal_11_l` int DEFAULT NULL,
  `tanggal_11` int GENERATED ALWAYS AS (((`tanggal_11_s` + `tanggal_11_m`) + `tanggal_11_l`)) STORED,
  `tanggal_12_s` int DEFAULT NULL,
  `tanggal_12_m` int DEFAULT NULL,
  `tanggal_12_l` int DEFAULT NULL,
  `tanggal_12` int GENERATED ALWAYS AS (((`tanggal_12_s` + `tanggal_12_m`) + `tanggal_12_l`)) STORED,
  `tanggal_13_s` int DEFAULT NULL,
  `tanggal_13_m` int DEFAULT NULL,
  `tanggal_13_l` int DEFAULT NULL,
  `tanggal_13` int GENERATED ALWAYS AS (((`tanggal_13_s` + `tanggal_13_m`) + `tanggal_13_l`)) STORED,
  `tanggal_14_s` int DEFAULT NULL,
  `tanggal_14_m` int DEFAULT NULL,
  `tanggal_14_l` int DEFAULT NULL,
  `tanggal_14` int GENERATED ALWAYS AS (((`tanggal_14_s` + `tanggal_14_m`) + `tanggal_14_l`)) STORED,
  `tanggal_15_s` int DEFAULT NULL,
  `tanggal_15_m` int DEFAULT NULL,
  `tanggal_15_l` int DEFAULT NULL,
  `tanggal_15` int GENERATED ALWAYS AS (((`tanggal_15_s` + `tanggal_15_m`) + `tanggal_15_l`)) STORED,
  `tanggal_16_s` int DEFAULT NULL,
  `tanggal_16_m` int DEFAULT NULL,
  `tanggal_16_l` int DEFAULT NULL,
  `tanggal_16` int GENERATED ALWAYS AS (((`tanggal_16_s` + `tanggal_16_m`) + `tanggal_16_l`)) STORED,
  `tanggal_17_s` int DEFAULT NULL,
  `tanggal_17_m` int DEFAULT NULL,
  `tanggal_17_l` int DEFAULT NULL,
  `tanggal_17` int GENERATED ALWAYS AS (((`tanggal_17_s` + `tanggal_17_m`) + `tanggal_17_l`)) STORED,
  `tanggal_18_s` int DEFAULT NULL,
  `tanggal_18_m` int DEFAULT NULL,
  `tanggal_18_l` int DEFAULT NULL,
  `tanggal_18` int GENERATED ALWAYS AS (((`tanggal_18_s` + `tanggal_18_m`) + `tanggal_18_l`)) STORED,
  `tanggal_19_s` int DEFAULT NULL,
  `tanggal_19_m` int DEFAULT NULL,
  `tanggal_19_l` int DEFAULT NULL,
  `tanggal_19` int GENERATED ALWAYS AS (((`tanggal_19_s` + `tanggal_19_m`) + `tanggal_19_l`)) STORED,
  `tanggal_20_s` int DEFAULT NULL,
  `tanggal_20_m` int DEFAULT NULL,
  `tanggal_20_l` int DEFAULT NULL,
  `tanggal_20` int GENERATED ALWAYS AS (((`tanggal_20_s` + `tanggal_20_m`) + `tanggal_20_l`)) STORED,
  `tanggal_21_s` int DEFAULT NULL,
  `tanggal_21_m` int DEFAULT NULL,
  `tanggal_21_l` int DEFAULT NULL,
  `tanggal_21` int GENERATED ALWAYS AS (((`tanggal_21_s` + `tanggal_21_m`) + `tanggal_21_l`)) STORED,
  `tanggal_22_s` int DEFAULT NULL,
  `tanggal_22_m` int DEFAULT NULL,
  `tanggal_22_l` int DEFAULT NULL,
  `tanggal_22` int GENERATED ALWAYS AS (((`tanggal_22_s` + `tanggal_22_m`) + `tanggal_22_l`)) STORED,
  `tanggal_23_s` int DEFAULT NULL,
  `tanggal_23_m` int DEFAULT NULL,
  `tanggal_23_l` int DEFAULT NULL,
  `tanggal_23` int GENERATED ALWAYS AS (((`tanggal_23_s` + `tanggal_23_m`) + `tanggal_23_l`)) STORED,
  `tanggal_24_s` int DEFAULT NULL,
  `tanggal_24_m` int DEFAULT NULL,
  `tanggal_24_l` int DEFAULT NULL,
  `tanggal_24` int GENERATED ALWAYS AS (((`tanggal_24_s` + `tanggal_24_m`) + `tanggal_24_l`)) STORED,
  `tanggal_25_s` int DEFAULT NULL,
  `tanggal_25_m` int DEFAULT NULL,
  `tanggal_25_l` int DEFAULT NULL,
  `tanggal_25` int GENERATED ALWAYS AS (((`tanggal_25_s` + `tanggal_25_m`) + `tanggal_25_l`)) STORED,
  `tanggal_26_s` int DEFAULT NULL,
  `tanggal_26_m` int DEFAULT NULL,
  `tanggal_26_l` int DEFAULT NULL,
  `tanggal_26` int GENERATED ALWAYS AS (((`tanggal_26_s` + `tanggal_26_m`) + `tanggal_26_l`)) STORED,
  `tanggal_27_s` int DEFAULT NULL,
  `tanggal_27_m` int DEFAULT NULL,
  `tanggal_27_l` int DEFAULT NULL,
  `tanggal_27` int GENERATED ALWAYS AS (((`tanggal_27_s` + `tanggal_27_m`) + `tanggal_27_l`)) STORED,
  `tanggal_28_s` int DEFAULT NULL,
  `tanggal_28_m` int DEFAULT NULL,
  `tanggal_28_l` int DEFAULT NULL,
  `tanggal_28` int GENERATED ALWAYS AS (((`tanggal_28_s` + `tanggal_28_m`) + `tanggal_28_l`)) STORED,
  `tanggal_29_s` int DEFAULT NULL,
  `tanggal_29_m` int DEFAULT NULL,
  `tanggal_29_l` int DEFAULT NULL,
  `tanggal_29` int GENERATED ALWAYS AS (((`tanggal_29_s` + `tanggal_29_m`) + `tanggal_29_l`)) STORED,
  `tanggal_30_s` int DEFAULT NULL,
  `tanggal_30_m` int DEFAULT NULL,
  `tanggal_30_l` int DEFAULT NULL,
  `tanggal_30` int GENERATED ALWAYS AS (((`tanggal_30_s` + `tanggal_30_m`) + `tanggal_30_l`)) STORED,
  `tanggal_31_s` int DEFAULT NULL,
  `tanggal_31_m` int DEFAULT NULL,
  `tanggal_31_l` int DEFAULT NULL,
  `tanggal_31` int GENERATED ALWAYS AS (((`tanggal_31_s` + `tanggal_31_m`) + `tanggal_31_l`)) STORED
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `toko_politeknikstore`
--

CREATE TABLE `toko_politeknikstore` (
  `id_baju` int NOT NULL,
  `nama_baju` varchar(300) DEFAULT NULL,
  `kategori_baju` varchar(300) DEFAULT NULL,
  `harga_baju` int DEFAULT NULL,
  `rating_baju` int DEFAULT NULL,
  `foto_baju` varchar(300) DEFAULT NULL,
  `deskripsi_baju` text,
  `status_tersedia` tinyint(1) DEFAULT '1',
  `nama_pemilik` varchar(300) DEFAULT NULL,
  `kontak_pemilik` varchar(300) DEFAULT NULL,
  `alamat_pemilik` varchar(300) DEFAULT NULL,
  `id_pemilik` int DEFAULT NULL,
  `ukuran_s` int DEFAULT NULL,
  `ukuran_m` int DEFAULT NULL,
  `ukuran_l` int DEFAULT NULL,
  `jumlah_baju` int GENERATED ALWAYS AS (((`ukuran_s` + `ukuran_m`) + `ukuran_l`)) STORED,
  `tersewa_baju_s` int DEFAULT NULL,
  `tersewa_baju_m` int DEFAULT NULL,
  `tersewa_baju_l` int DEFAULT NULL,
  `jumlah_tersewa` int GENERATED ALWAYS AS (((`tersewa_baju_s` + `tersewa_baju_m`) + `tersewa_baju_l`)) STORED,
  `tanggal_1_s` int DEFAULT NULL,
  `tanggal_1_m` int DEFAULT NULL,
  `tanggal_1_l` int DEFAULT NULL,
  `tanggal_1` int GENERATED ALWAYS AS (((`tanggal_1_s` + `tanggal_1_m`) + `tanggal_1_l`)) STORED,
  `tanggal_2_s` int DEFAULT NULL,
  `tanggal_2_m` int DEFAULT NULL,
  `tanggal_2_l` int DEFAULT NULL,
  `tanggal_2` int GENERATED ALWAYS AS (((`tanggal_2_s` + `tanggal_2_m`) + `tanggal_2_l`)) STORED,
  `tanggal_3_s` int DEFAULT NULL,
  `tanggal_3_m` int DEFAULT NULL,
  `tanggal_3_l` int DEFAULT NULL,
  `tanggal_3` int GENERATED ALWAYS AS (((`tanggal_3_s` + `tanggal_3_m`) + `tanggal_3_l`)) STORED,
  `tanggal_4_s` int DEFAULT NULL,
  `tanggal_4_m` int DEFAULT NULL,
  `tanggal_4_l` int DEFAULT NULL,
  `tanggal_4` int GENERATED ALWAYS AS (((`tanggal_4_s` + `tanggal_4_m`) + `tanggal_4_l`)) STORED,
  `tanggal_5_s` int DEFAULT NULL,
  `tanggal_5_m` int DEFAULT NULL,
  `tanggal_5_l` int DEFAULT NULL,
  `tanggal_5` int GENERATED ALWAYS AS (((`tanggal_5_s` + `tanggal_5_m`) + `tanggal_5_l`)) STORED,
  `tanggal_6_s` int DEFAULT NULL,
  `tanggal_6_m` int DEFAULT NULL,
  `tanggal_6_l` int DEFAULT NULL,
  `tanggal_6` int GENERATED ALWAYS AS (((`tanggal_6_s` + `tanggal_6_m`) + `tanggal_6_l`)) STORED,
  `tanggal_7_s` int DEFAULT NULL,
  `tanggal_7_m` int DEFAULT NULL,
  `tanggal_7_l` int DEFAULT NULL,
  `tanggal_7` int GENERATED ALWAYS AS (((`tanggal_7_s` + `tanggal_7_m`) + `tanggal_7_l`)) STORED,
  `tanggal_8_s` int DEFAULT NULL,
  `tanggal_8_m` int DEFAULT NULL,
  `tanggal_8_l` int DEFAULT NULL,
  `tanggal_8` int GENERATED ALWAYS AS (((`tanggal_8_s` + `tanggal_8_m`) + `tanggal_8_l`)) STORED,
  `tanggal_9_s` int DEFAULT NULL,
  `tanggal_9_m` int DEFAULT NULL,
  `tanggal_9_l` int DEFAULT NULL,
  `tanggal_9` int GENERATED ALWAYS AS (((`tanggal_9_s` + `tanggal_9_m`) + `tanggal_9_l`)) STORED,
  `tanggal_10_s` int DEFAULT NULL,
  `tanggal_10_m` int DEFAULT NULL,
  `tanggal_10_l` int DEFAULT NULL,
  `tanggal_10` int GENERATED ALWAYS AS (((`tanggal_10_s` + `tanggal_10_m`) + `tanggal_10_l`)) STORED,
  `tanggal_11_s` int DEFAULT NULL,
  `tanggal_11_m` int DEFAULT NULL,
  `tanggal_11_l` int DEFAULT NULL,
  `tanggal_11` int GENERATED ALWAYS AS (((`tanggal_11_s` + `tanggal_11_m`) + `tanggal_11_l`)) STORED,
  `tanggal_12_s` int DEFAULT NULL,
  `tanggal_12_m` int DEFAULT NULL,
  `tanggal_12_l` int DEFAULT NULL,
  `tanggal_12` int GENERATED ALWAYS AS (((`tanggal_12_s` + `tanggal_12_m`) + `tanggal_12_l`)) STORED,
  `tanggal_13_s` int DEFAULT NULL,
  `tanggal_13_m` int DEFAULT NULL,
  `tanggal_13_l` int DEFAULT NULL,
  `tanggal_13` int GENERATED ALWAYS AS (((`tanggal_13_s` + `tanggal_13_m`) + `tanggal_13_l`)) STORED,
  `tanggal_14_s` int DEFAULT NULL,
  `tanggal_14_m` int DEFAULT NULL,
  `tanggal_14_l` int DEFAULT NULL,
  `tanggal_14` int GENERATED ALWAYS AS (((`tanggal_14_s` + `tanggal_14_m`) + `tanggal_14_l`)) STORED,
  `tanggal_15_s` int DEFAULT NULL,
  `tanggal_15_m` int DEFAULT NULL,
  `tanggal_15_l` int DEFAULT NULL,
  `tanggal_15` int GENERATED ALWAYS AS (((`tanggal_15_s` + `tanggal_15_m`) + `tanggal_15_l`)) STORED,
  `tanggal_16_s` int DEFAULT NULL,
  `tanggal_16_m` int DEFAULT NULL,
  `tanggal_16_l` int DEFAULT NULL,
  `tanggal_16` int GENERATED ALWAYS AS (((`tanggal_16_s` + `tanggal_16_m`) + `tanggal_16_l`)) STORED,
  `tanggal_17_s` int DEFAULT NULL,
  `tanggal_17_m` int DEFAULT NULL,
  `tanggal_17_l` int DEFAULT NULL,
  `tanggal_17` int GENERATED ALWAYS AS (((`tanggal_17_s` + `tanggal_17_m`) + `tanggal_17_l`)) STORED,
  `tanggal_18_s` int DEFAULT NULL,
  `tanggal_18_m` int DEFAULT NULL,
  `tanggal_18_l` int DEFAULT NULL,
  `tanggal_18` int GENERATED ALWAYS AS (((`tanggal_18_s` + `tanggal_18_m`) + `tanggal_18_l`)) STORED,
  `tanggal_19_s` int DEFAULT NULL,
  `tanggal_19_m` int DEFAULT NULL,
  `tanggal_19_l` int DEFAULT NULL,
  `tanggal_19` int GENERATED ALWAYS AS (((`tanggal_19_s` + `tanggal_19_m`) + `tanggal_19_l`)) STORED,
  `tanggal_20_s` int DEFAULT NULL,
  `tanggal_20_m` int DEFAULT NULL,
  `tanggal_20_l` int DEFAULT NULL,
  `tanggal_20` int GENERATED ALWAYS AS (((`tanggal_20_s` + `tanggal_20_m`) + `tanggal_20_l`)) STORED,
  `tanggal_21_s` int DEFAULT NULL,
  `tanggal_21_m` int DEFAULT NULL,
  `tanggal_21_l` int DEFAULT NULL,
  `tanggal_21` int GENERATED ALWAYS AS (((`tanggal_21_s` + `tanggal_21_m`) + `tanggal_21_l`)) STORED,
  `tanggal_22_s` int DEFAULT NULL,
  `tanggal_22_m` int DEFAULT NULL,
  `tanggal_22_l` int DEFAULT NULL,
  `tanggal_22` int GENERATED ALWAYS AS (((`tanggal_22_s` + `tanggal_22_m`) + `tanggal_22_l`)) STORED,
  `tanggal_23_s` int DEFAULT NULL,
  `tanggal_23_m` int DEFAULT NULL,
  `tanggal_23_l` int DEFAULT NULL,
  `tanggal_23` int GENERATED ALWAYS AS (((`tanggal_23_s` + `tanggal_23_m`) + `tanggal_23_l`)) STORED,
  `tanggal_24_s` int DEFAULT NULL,
  `tanggal_24_m` int DEFAULT NULL,
  `tanggal_24_l` int DEFAULT NULL,
  `tanggal_24` int GENERATED ALWAYS AS (((`tanggal_24_s` + `tanggal_24_m`) + `tanggal_24_l`)) STORED,
  `tanggal_25_s` int DEFAULT NULL,
  `tanggal_25_m` int DEFAULT NULL,
  `tanggal_25_l` int DEFAULT NULL,
  `tanggal_25` int GENERATED ALWAYS AS (((`tanggal_25_s` + `tanggal_25_m`) + `tanggal_25_l`)) STORED,
  `tanggal_26_s` int DEFAULT NULL,
  `tanggal_26_m` int DEFAULT NULL,
  `tanggal_26_l` int DEFAULT NULL,
  `tanggal_26` int GENERATED ALWAYS AS (((`tanggal_26_s` + `tanggal_26_m`) + `tanggal_26_l`)) STORED,
  `tanggal_27_s` int DEFAULT NULL,
  `tanggal_27_m` int DEFAULT NULL,
  `tanggal_27_l` int DEFAULT NULL,
  `tanggal_27` int GENERATED ALWAYS AS (((`tanggal_27_s` + `tanggal_27_m`) + `tanggal_27_l`)) STORED,
  `tanggal_28_s` int DEFAULT NULL,
  `tanggal_28_m` int DEFAULT NULL,
  `tanggal_28_l` int DEFAULT NULL,
  `tanggal_28` int GENERATED ALWAYS AS (((`tanggal_28_s` + `tanggal_28_m`) + `tanggal_28_l`)) STORED,
  `tanggal_29_s` int DEFAULT NULL,
  `tanggal_29_m` int DEFAULT NULL,
  `tanggal_29_l` int DEFAULT NULL,
  `tanggal_29` int GENERATED ALWAYS AS (((`tanggal_29_s` + `tanggal_29_m`) + `tanggal_29_l`)) STORED,
  `tanggal_30_s` int DEFAULT NULL,
  `tanggal_30_m` int DEFAULT NULL,
  `tanggal_30_l` int DEFAULT NULL,
  `tanggal_30` int GENERATED ALWAYS AS (((`tanggal_30_s` + `tanggal_30_m`) + `tanggal_30_l`)) STORED,
  `tanggal_31_s` int DEFAULT NULL,
  `tanggal_31_m` int DEFAULT NULL,
  `tanggal_31_l` int DEFAULT NULL,
  `tanggal_31` int GENERATED ALWAYS AS (((`tanggal_31_s` + `tanggal_31_m`) + `tanggal_31_l`)) STORED
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `toko_test`
--

CREATE TABLE `toko_test` (
  `id_baju` int NOT NULL,
  `nama_baju` varchar(300) DEFAULT NULL,
  `kategori_baju` varchar(300) DEFAULT NULL,
  `harga_baju` int DEFAULT NULL,
  `rating_baju` int DEFAULT NULL,
  `foto_baju` varchar(300) DEFAULT NULL,
  `deskripsi_baju` text,
  `status_tersedia` tinyint(1) DEFAULT '1',
  `nama_pemilik` varchar(300) DEFAULT NULL,
  `kontak_pemilik` varchar(300) DEFAULT NULL,
  `alamat_pemilik` varchar(300) DEFAULT NULL,
  `id_pemilik` int DEFAULT NULL,
  `ukuran_s` int DEFAULT NULL,
  `ukuran_m` int DEFAULT NULL,
  `ukuran_l` int DEFAULT NULL,
  `jumlah_baju` int GENERATED ALWAYS AS (((`ukuran_s` + `ukuran_m`) + `ukuran_l`)) STORED,
  `tersewa_baju_s` int DEFAULT NULL,
  `tersewa_baju_m` int DEFAULT NULL,
  `tersewa_baju_l` int DEFAULT NULL,
  `jumlah_tersewa` int GENERATED ALWAYS AS (((`tersewa_baju_s` + `tersewa_baju_m`) + `tersewa_baju_l`)) STORED,
  `tanggal_1_s` int DEFAULT NULL,
  `tanggal_1_m` int DEFAULT NULL,
  `tanggal_1_l` int DEFAULT NULL,
  `tanggal_1` int GENERATED ALWAYS AS (((`tanggal_1_s` + `tanggal_1_m`) + `tanggal_1_l`)) STORED,
  `tanggal_2_s` int DEFAULT NULL,
  `tanggal_2_m` int DEFAULT NULL,
  `tanggal_2_l` int DEFAULT NULL,
  `tanggal_2` int GENERATED ALWAYS AS (((`tanggal_2_s` + `tanggal_2_m`) + `tanggal_2_l`)) STORED,
  `tanggal_3_s` int DEFAULT NULL,
  `tanggal_3_m` int DEFAULT NULL,
  `tanggal_3_l` int DEFAULT NULL,
  `tanggal_3` int GENERATED ALWAYS AS (((`tanggal_3_s` + `tanggal_3_m`) + `tanggal_3_l`)) STORED,
  `tanggal_4_s` int DEFAULT NULL,
  `tanggal_4_m` int DEFAULT NULL,
  `tanggal_4_l` int DEFAULT NULL,
  `tanggal_4` int GENERATED ALWAYS AS (((`tanggal_4_s` + `tanggal_4_m`) + `tanggal_4_l`)) STORED,
  `tanggal_5_s` int DEFAULT NULL,
  `tanggal_5_m` int DEFAULT NULL,
  `tanggal_5_l` int DEFAULT NULL,
  `tanggal_5` int GENERATED ALWAYS AS (((`tanggal_5_s` + `tanggal_5_m`) + `tanggal_5_l`)) STORED,
  `tanggal_6_s` int DEFAULT NULL,
  `tanggal_6_m` int DEFAULT NULL,
  `tanggal_6_l` int DEFAULT NULL,
  `tanggal_6` int GENERATED ALWAYS AS (((`tanggal_6_s` + `tanggal_6_m`) + `tanggal_6_l`)) STORED,
  `tanggal_7_s` int DEFAULT NULL,
  `tanggal_7_m` int DEFAULT NULL,
  `tanggal_7_l` int DEFAULT NULL,
  `tanggal_7` int GENERATED ALWAYS AS (((`tanggal_7_s` + `tanggal_7_m`) + `tanggal_7_l`)) STORED,
  `tanggal_8_s` int DEFAULT NULL,
  `tanggal_8_m` int DEFAULT NULL,
  `tanggal_8_l` int DEFAULT NULL,
  `tanggal_8` int GENERATED ALWAYS AS (((`tanggal_8_s` + `tanggal_8_m`) + `tanggal_8_l`)) STORED,
  `tanggal_9_s` int DEFAULT NULL,
  `tanggal_9_m` int DEFAULT NULL,
  `tanggal_9_l` int DEFAULT NULL,
  `tanggal_9` int GENERATED ALWAYS AS (((`tanggal_9_s` + `tanggal_9_m`) + `tanggal_9_l`)) STORED,
  `tanggal_10_s` int DEFAULT NULL,
  `tanggal_10_m` int DEFAULT NULL,
  `tanggal_10_l` int DEFAULT NULL,
  `tanggal_10` int GENERATED ALWAYS AS (((`tanggal_10_s` + `tanggal_10_m`) + `tanggal_10_l`)) STORED,
  `tanggal_11_s` int DEFAULT NULL,
  `tanggal_11_m` int DEFAULT NULL,
  `tanggal_11_l` int DEFAULT NULL,
  `tanggal_11` int GENERATED ALWAYS AS (((`tanggal_11_s` + `tanggal_11_m`) + `tanggal_11_l`)) STORED,
  `tanggal_12_s` int DEFAULT NULL,
  `tanggal_12_m` int DEFAULT NULL,
  `tanggal_12_l` int DEFAULT NULL,
  `tanggal_12` int GENERATED ALWAYS AS (((`tanggal_12_s` + `tanggal_12_m`) + `tanggal_12_l`)) STORED,
  `tanggal_13_s` int DEFAULT NULL,
  `tanggal_13_m` int DEFAULT NULL,
  `tanggal_13_l` int DEFAULT NULL,
  `tanggal_13` int GENERATED ALWAYS AS (((`tanggal_13_s` + `tanggal_13_m`) + `tanggal_13_l`)) STORED,
  `tanggal_14_s` int DEFAULT NULL,
  `tanggal_14_m` int DEFAULT NULL,
  `tanggal_14_l` int DEFAULT NULL,
  `tanggal_14` int GENERATED ALWAYS AS (((`tanggal_14_s` + `tanggal_14_m`) + `tanggal_14_l`)) STORED,
  `tanggal_15_s` int DEFAULT NULL,
  `tanggal_15_m` int DEFAULT NULL,
  `tanggal_15_l` int DEFAULT NULL,
  `tanggal_15` int GENERATED ALWAYS AS (((`tanggal_15_s` + `tanggal_15_m`) + `tanggal_15_l`)) STORED,
  `tanggal_16_s` int DEFAULT NULL,
  `tanggal_16_m` int DEFAULT NULL,
  `tanggal_16_l` int DEFAULT NULL,
  `tanggal_16` int GENERATED ALWAYS AS (((`tanggal_16_s` + `tanggal_16_m`) + `tanggal_16_l`)) STORED,
  `tanggal_17_s` int DEFAULT NULL,
  `tanggal_17_m` int DEFAULT NULL,
  `tanggal_17_l` int DEFAULT NULL,
  `tanggal_17` int GENERATED ALWAYS AS (((`tanggal_17_s` + `tanggal_17_m`) + `tanggal_17_l`)) STORED,
  `tanggal_18_s` int DEFAULT NULL,
  `tanggal_18_m` int DEFAULT NULL,
  `tanggal_18_l` int DEFAULT NULL,
  `tanggal_18` int GENERATED ALWAYS AS (((`tanggal_18_s` + `tanggal_18_m`) + `tanggal_18_l`)) STORED,
  `tanggal_19_s` int DEFAULT NULL,
  `tanggal_19_m` int DEFAULT NULL,
  `tanggal_19_l` int DEFAULT NULL,
  `tanggal_19` int GENERATED ALWAYS AS (((`tanggal_19_s` + `tanggal_19_m`) + `tanggal_19_l`)) STORED,
  `tanggal_20_s` int DEFAULT NULL,
  `tanggal_20_m` int DEFAULT NULL,
  `tanggal_20_l` int DEFAULT NULL,
  `tanggal_20` int GENERATED ALWAYS AS (((`tanggal_20_s` + `tanggal_20_m`) + `tanggal_20_l`)) STORED,
  `tanggal_21_s` int DEFAULT NULL,
  `tanggal_21_m` int DEFAULT NULL,
  `tanggal_21_l` int DEFAULT NULL,
  `tanggal_21` int GENERATED ALWAYS AS (((`tanggal_21_s` + `tanggal_21_m`) + `tanggal_21_l`)) STORED,
  `tanggal_22_s` int DEFAULT NULL,
  `tanggal_22_m` int DEFAULT NULL,
  `tanggal_22_l` int DEFAULT NULL,
  `tanggal_22` int GENERATED ALWAYS AS (((`tanggal_22_s` + `tanggal_22_m`) + `tanggal_22_l`)) STORED,
  `tanggal_23_s` int DEFAULT NULL,
  `tanggal_23_m` int DEFAULT NULL,
  `tanggal_23_l` int DEFAULT NULL,
  `tanggal_23` int GENERATED ALWAYS AS (((`tanggal_23_s` + `tanggal_23_m`) + `tanggal_23_l`)) STORED,
  `tanggal_24_s` int DEFAULT NULL,
  `tanggal_24_m` int DEFAULT NULL,
  `tanggal_24_l` int DEFAULT NULL,
  `tanggal_24` int GENERATED ALWAYS AS (((`tanggal_24_s` + `tanggal_24_m`) + `tanggal_24_l`)) STORED,
  `tanggal_25_s` int DEFAULT NULL,
  `tanggal_25_m` int DEFAULT NULL,
  `tanggal_25_l` int DEFAULT NULL,
  `tanggal_25` int GENERATED ALWAYS AS (((`tanggal_25_s` + `tanggal_25_m`) + `tanggal_25_l`)) STORED,
  `tanggal_26_s` int DEFAULT NULL,
  `tanggal_26_m` int DEFAULT NULL,
  `tanggal_26_l` int DEFAULT NULL,
  `tanggal_26` int GENERATED ALWAYS AS (((`tanggal_26_s` + `tanggal_26_m`) + `tanggal_26_l`)) STORED,
  `tanggal_27_s` int DEFAULT NULL,
  `tanggal_27_m` int DEFAULT NULL,
  `tanggal_27_l` int DEFAULT NULL,
  `tanggal_27` int GENERATED ALWAYS AS (((`tanggal_27_s` + `tanggal_27_m`) + `tanggal_27_l`)) STORED,
  `tanggal_28_s` int DEFAULT NULL,
  `tanggal_28_m` int DEFAULT NULL,
  `tanggal_28_l` int DEFAULT NULL,
  `tanggal_28` int GENERATED ALWAYS AS (((`tanggal_28_s` + `tanggal_28_m`) + `tanggal_28_l`)) STORED,
  `tanggal_29_s` int DEFAULT NULL,
  `tanggal_29_m` int DEFAULT NULL,
  `tanggal_29_l` int DEFAULT NULL,
  `tanggal_29` int GENERATED ALWAYS AS (((`tanggal_29_s` + `tanggal_29_m`) + `tanggal_29_l`)) STORED,
  `tanggal_30_s` int DEFAULT NULL,
  `tanggal_30_m` int DEFAULT NULL,
  `tanggal_30_l` int DEFAULT NULL,
  `tanggal_30` int GENERATED ALWAYS AS (((`tanggal_30_s` + `tanggal_30_m`) + `tanggal_30_l`)) STORED,
  `tanggal_31_s` int DEFAULT NULL,
  `tanggal_31_m` int DEFAULT NULL,
  `tanggal_31_l` int DEFAULT NULL,
  `tanggal_31` int GENERATED ALWAYS AS (((`tanggal_31_s` + `tanggal_31_m`) + `tanggal_31_l`)) STORED
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `achul`
--
ALTER TABLE `achul`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bunga`
--
ALTER TABLE `bunga`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dataakun`
--
ALTER TABLE `dataakun`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `databaju`
--
ALTER TABLE `databaju`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `datasewa`
--
ALTER TABLE `datasewa`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `datatoko`
--
ALTER TABLE `datatoko`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `elisabet`
--
ALTER TABLE `elisabet`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eren`
--
ALTER TABLE `eren`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `putra`
--
ALTER TABLE `putra`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `toko`
--
ALTER TABLE `toko`
  ADD PRIMARY KEY (`id_baju`);

--
-- Indexes for table `toko_achul`
--
ALTER TABLE `toko_achul`
  ADD PRIMARY KEY (`id_baju`);

--
-- Indexes for table `toko_polistore`
--
ALTER TABLE `toko_polistore`
  ADD PRIMARY KEY (`id_baju`);

--
-- Indexes for table `toko_politeknikstore`
--
ALTER TABLE `toko_politeknikstore`
  ADD PRIMARY KEY (`id_baju`);

--
-- Indexes for table `toko_test`
--
ALTER TABLE `toko_test`
  ADD PRIMARY KEY (`id_baju`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `achul`
--
ALTER TABLE `achul`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `bunga`
--
ALTER TABLE `bunga`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `dataakun`
--
ALTER TABLE `dataakun`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `databaju`
--
ALTER TABLE `databaju`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `datasewa`
--
ALTER TABLE `datasewa`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `datatoko`
--
ALTER TABLE `datatoko`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `elisabet`
--
ALTER TABLE `elisabet`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `eren`
--
ALTER TABLE `eren`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `putra`
--
ALTER TABLE `putra`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `toko`
--
ALTER TABLE `toko`
  MODIFY `id_baju` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `toko_achul`
--
ALTER TABLE `toko_achul`
  MODIFY `id_baju` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `toko_polistore`
--
ALTER TABLE `toko_polistore`
  MODIFY `id_baju` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `toko_politeknikstore`
--
ALTER TABLE `toko_politeknikstore`
  MODIFY `id_baju` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `toko_test`
--
ALTER TABLE `toko_test`
  MODIFY `id_baju` int NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
