<?php

session_start(); // Pastikan session dimulai di awal
ob_start();

// Validasi dan ambil data dari POST
$hari = ($_POST['options']);
$id_dataakun = ($_POST['id_dataakun']);
$nama_penyewa = ($_POST['nama_penyewa']);
$nik_penyewa = ($_POST['nik_penyewa']);
$kontak_penyewa = ($_POST['kontak_penyewa']);
$alamat_penyewa = ($_POST['alamat_penyewa']);
$id_pemesanan = ($_POST['id_pemesanan']);
$tanggal_pemesanan = ($_POST['tanggal_pemesanan']);
$tanggal_sewa = ($_POST['tanggal_sewa']);
$bulan_sewa = ($_POST['bulan_sewa']);
$tahun_sewa = ($_POST['tahun_sewa']);
$tanggal_pengembalian_1_hari = ($_POST['tanggal_pengembalian_1_hari']);
$tanggal_pengembalian_2_hari = ($_POST['tanggal_pengembalian_2_hari']);
$tanggal_pengembalian_3_hari = ($_POST['tanggal_pengembalian_3_hari']);
$nama_pemilik = ($_POST['nama_pemilik']);
$alamat_pemilik = ($_POST['alamat_pemilik']);
$kontak_pemilik = ($_POST['kontak_pemilik']);
$nama_baju = ($_POST['nama_baju']);
$harga_baju = ($_POST['harga_baju']);
$foto_baju = ($_POST['foto_baju']);
$ukuran_baju = ($_POST['ukuran_baju']);
$id_datatoko = ($_POST['id_datatoko']);
$id_databaju = ($_POST['id_databaju']);

$tanggal_pengembalian = "";
$biaya_baju = "";
$biaya_layanan = "";
$biaya_pajak = "";
$biaya_total = "";

if ($hari == "1") {
    $tanggal_pengembalian = $tanggal_pengembalian_1_hari;
    $biaya_baju = $harga_baju * 1;
    $biaya_layanan = $biaya_baju * 0.05;
    $biaya_pajak = $biaya_baju * 0.11;
    $biaya_total = $biaya_baju + $biaya_layanan + $biaya_pajak;
} elseif ($hari == "2") {
    $tanggal_pengembalian = $tanggal_pengembalian_2_hari;
    $biaya_baju = $harga_baju * 2;
    $biaya_layanan = $biaya_baju * 0.05;
    $biaya_pajak = $biaya_baju * 0.11;
    $biaya_total = $biaya_baju + $biaya_layanan + $biaya_pajak;
} elseif ($hari == "3") {
    $tanggal_pengembalian = $tanggal_pengembalian_3_hari;
    $biaya_baju = $harga_baju * 3;
    $biaya_layanan = $biaya_baju * 0.05;
    $biaya_pajak = $biaya_baju * 0.11;
    $biaya_total = $biaya_baju + $biaya_layanan + $biaya_pajak;
}

require __DIR__ . "/dompdf/vendor/autoload.php"; // Tambahkan titik koma di sini

use Dompdf\Dompdf;
use Dompdf\Options; 

$options = new Options;
$options->setChroot(__DIR__);
$options->setIsRemoteEnabled(true); // Enable remote file access

$dompdf = new Dompdf($options);

$html = file_get_contents("invoice.html");

$html = str_replace(
    [
        '{{ tanggal_pengembalian }}', '{{ biaya_baju }}', '{{ biaya_layanan }}', '{{ biaya_pajak }}', '{{ biaya_total }}', '{{ hari }}', '{{ id_dataakun }}', '{{ nama_penyewa }}', '{{ nik_penyewa }}', '{{ kontak_penyewa }}', '{{ alamat_penyewa }}',
        '{{ id_pemesanan }}', '{{ tanggal_pemesanan }}', '{{ tanggal_sewa }}', '{{ bulan_sewa }}', '{{ tahun_sewa }}',
        '{{ tanggal_pengembalian_1_hari }}', '{{ tanggal_pengembalian_2_hari }}', '{{ tanggal_pengembalian_3_hari }}',
        '{{ nama_pemilik }}', '{{ alamat_pemilik }}', '{{ kontak_pemilik }}',
        '{{ nama_baju }}', '{{ harga_baju }}', '{{ foto_baju }}', '{{ ukuran_baju }}',
        '{{ id_datatoko }}', '{{ id_databaju }}'
    ],
    [
        $tanggal_pengembalian, $biaya_baju, $biaya_layanan, $biaya_pajak, $biaya_total, $hari, $id_dataakun, $nama_penyewa, $nik_penyewa, $kontak_penyewa, $alamat_penyewa,
        $id_pemesanan, $tanggal_pemesanan, $tanggal_sewa, $bulan_sewa, $tahun_sewa,
        $tanggal_pengembalian_1_hari, $tanggal_pengembalian_2_hari, $tanggal_pengembalian_3_hari,
        $nama_pemilik, $alamat_pemilik, $kontak_pemilik,
        $nama_baju, $harga_baju, $foto_baju, $ukuran_baju,
        $id_datatoko, $id_databaju
    ],
    $html
);

$dompdf->loadHtml($html); // Perbaiki 'loadhtml' menjadi 'loadHtml' dan tambahkan titik koma

$dompdf->render();

$dompdf->stream("nota_" . $nama_penyewa . "_" . $id_pemesanan . ".pdf", ["Attachment" => 1]);

$sname = "localhost";
$unmae = "root";
$password = "";
$db_name = "waju";

$conn = mysqli_connect($sname, $unmae, $password, $db_name);

if (!$conn) {
    echo "Connection failed!";
} else {
    echo "Berhasil";
}

if (isset($_POST['options']) &&
    isset($_POST['id_dataakun']) &&
    isset($_POST['nama_penyewa']) &&
    isset($_POST['nik_penyewa']) &&
    isset($_POST['kontak_penyewa']) &&
    isset($_POST['alamat_penyewa']) &&
    isset($_POST['id_pemesanan']) &&
    isset($_POST['tanggal_pemesanan']) &&
    isset($_POST['tanggal_sewa']) &&
    isset($_POST['bulan_sewa']) &&
    isset($_POST['tahun_sewa']) &&
    isset($_POST['tanggal_pengembalian_1_hari']) &&
    isset($_POST['tanggal_pengembalian_2_hari']) &&
    isset($_POST['tanggal_pengembalian_3_hari']) &&
    isset($_POST['nama_pemilik']) &&
    isset($_POST['alamat_pemilik']) &&
    isset($_POST['kontak_pemilik']) &&
    isset($_POST['nama_baju']) &&
    isset($_POST['harga_baju']) &&
    isset($_POST['foto_baju']) &&
    isset($_POST['ukuran_baju']) &&
    isset($_POST['id_datatoko']) &&
    isset($_POST['id_databaju'])) {

    function validate($data) {
        return htmlspecialchars(trim($data));
    }

    // Validasi dan ambil data dari POST
    $hari = validate($_POST['options']);
    $id_dataakun = validate($_POST['id_dataakun']);
    $nama_penyewa = validate($_POST['nama_penyewa']);
    $nik_penyewa = validate($_POST['nik_penyewa']);
    $kontak_penyewa = validate($_POST['kontak_penyewa']);
    $alamat_penyewa = validate($_POST['alamat_penyewa']);
    $id_pemesanan = validate($_POST['id_pemesanan']);
    $tanggal_pemesanan = validate($_POST['tanggal_pemesanan']);
    $tanggal_sewa = validate($_POST['tanggal_sewa']);
    $bulan_sewa = validate($_POST['bulan_sewa']);
    $tahun_sewa = validate($_POST['tahun_sewa']);
    $tanggal_pengembalian_1_hari = validate($_POST['tanggal_pengembalian_1_hari']);
    $tanggal_pengembalian_2_hari = validate($_POST['tanggal_pengembalian_2_hari']);
    $tanggal_pengembalian_3_hari = validate($_POST['tanggal_pengembalian_3_hari']);
    $nama_pemilik = validate($_POST['nama_pemilik']);
    $alamat_pemilik = validate($_POST['alamat_pemilik']);
    $kontak_pemilik = validate($_POST['kontak_pemilik']);
    $nama_baju = validate($_POST['nama_baju']);
    $harga_baju = validate($_POST['harga_baju']);
    $foto_baju = validate($_POST['foto_baju']);
    $ukuran_baju = validate($_POST['ukuran_baju']);
    $id_datatoko = validate($_POST['id_datatoko']);
    $id_databaju = validate($_POST[' id_databaju']);

    $tanggal_pengembalian = "";
    $biaya_baju = "";
    $biaya_layanan = "";
    $biaya_pajak = "";
    $biaya_total = "";

    if ($hari == "1") {
        $tanggal_pengembalian = $tanggal_pengembalian_1_hari;
        $biaya_baju = $harga_baju * 1;
        $biaya_layanan = $biaya_baju * 0.05;
        $biaya_pajak = $biaya_baju * 0.11;
        $biaya_total = $biaya_baju + $biaya_layanan + $biaya_pajak;
    } elseif ($hari == "2") {
        $tanggal_pengembalian = $tanggal_pengembalian_2_hari;
        $biaya_baju = $harga_baju * 2;
        $biaya_layanan = $biaya_baju * 0.05;
        $biaya_pajak = $biaya_baju * 0.11;
        $biaya_total = $biaya_baju + $biaya_layanan + $biaya_pajak;
    } elseif ($hari == "3") {
        $tanggal_pengembalian = $tanggal_pengembalian_3_hari;
        $biaya_baju = $harga_baju * 3;
        $biaya_layanan = $biaya_baju * 0.05;
        $biaya_pajak = $biaya_baju * 0.11;
        $biaya_total = $biaya_baju + $biaya_layanan + $biaya_pajak;
    }

    $sql = "INSERT INTO `datasewa` (
        hari,
        id_dataakun, 
        nama_penyewa, 
        nik_penyewa, 
        kontak_penyewa, 
        alamat_penyewa, 
        id_pemesanan, 
        tanggal_pemesanan, 
        tanggal_sewa, 
        bulan_sewa, 
        tahun_sewa, 
        tanggal_pengembalian, 
        nama_pemilik, 
        alamat_pemilik, 
        kontak_pemilik, 
        nama_baju, 
        harga_baju, 
        foto_baju, 
        ukuran_baju, 
        id_datatoko, 
        id_databaju, 
        biaya_baju, 
        biaya_layanan, 
        biaya_pajak, 
        biaya_total
    ) VALUES (
        '$hari',
        '$id_dataakun', 
        '$nama_penyewa', 
        '$nik_penyewa', 
        '$kontak_penyewa', 
        '$alamat_penyewa', 
        '$id_pemesanan', 
        '$tanggal_pemesanan', 
        '$tanggal_sewa', 
        '$bulan_sewa', 
        '$tahun_sewa', 
        '$tanggal_pengembalian', 
        '$nama_pemilik', 
        '$alamat_pemilik', 
        '$kontak_pemilik', 
        '$nama_baju', 
        '$harga_baju', 
        '$foto_baju', 
        '$ukuran_baju', 
        '$id_datatoko', 
        '$id_databaju', 
        '$biaya_baju', 
        '$biaya_layanan', 
        '$biaya_pajak', 
        '$biaya_total'
    )";

    $result = mysqli_query($conn, $sql);

    if (!$result) {
        die("Query gagal: " . mysqli_error($conn));}

    header("Location: ../halaman_nota/halaman_nota.php");
    }

    $dompdf->stream("nota_" . $nama_penyewa . "_" . $id_pemesanan . ".pdf", ["Attachment" => 0]);

ob_end_flush();
phpinfo();  
?>