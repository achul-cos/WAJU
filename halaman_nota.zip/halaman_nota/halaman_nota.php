<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pembayaran</title>
    <link crossorigin="anonymous" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" rel="stylesheet"/>
  
    <!-- Custom Font "Poppins" -->

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Material+Icons">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0&icon_names=check"/>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"></link>

    <!-- Menggunakan Bootstrap CSS dari file lokal -->
    <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    
    <!-- Logo Tab -->

    <link rel="icon" type="image/x-icon" href="../img/icon/logo_atas.svg">

    <!-- PHP -->

    <!-- PHP Selesai -->

  </head>

  <body>
  
    <!-- Internal CSS -->
  
        <style>

            /* Reset standar untuk semua elemen */
        
                * {
                    margin: 0;
                    padding: 0;
                    box-sizing: border-box;
                    font-family: "Poppins", sans-serif;
                }
                /* Gaya background halaman */
                body {
                    background: rgb(217,233,233);
                    background: radial-gradient(circle, rgba(217,233,233,1) 3%, rgba(224,237,227,1) 100%);
                }
        
            /* CSS : Navagation Bar */

                .navbar {
                background-image: url(../img/icon/navbar.png);
                background-size: cover;
                border-bottom-left-radius: 20em 28em;
                border-bottom-right-radius: 20em 28em;
                height: 80px;
                }

                .navbar-brand {
                display: flex;
                justify-content: center;
                padding: 0px 0px 0% 0px !important;
                margin: 0px 5px 0px 0px !important;
                transition: 0.5s;
                }

                .navbar-brand:hover {
                filter:invert(100%) !important;
                opacity: 0.7;
                }

                .tombol_pencarian {
                display: block;
                width: 50px;
                height: auto;
                margin: 0 0 0 0; /* Menggabungkan margin */
                border: 1px solid rgba(14, 89, 129, 0.178);
                border-radius: 20px;
                box-shadow: 0 0 20px rgba(0, 0, 0, 0.05); 
                background: rgb(166, 214, 239) url(../img/icon/icon_cari.svg) no-repeat center / 25% !important; /* Menggabungkan properti background */
                transition: 0.1s;
                }

                .tombol_pencarian:hover{
                border: none !important;
                filter:invert(20%) !important;
                }

                .tombol_pencarian:active{
                background-size: 50% !important;
                }

                .bar_pencarian {
                color: rgba(91, 91, 91, 0.57);            
                border: 1px solid rgba(14, 89, 129, 0.178);
                border-radius: 20px;
                box-shadow: 0 0 20px rgba(0, 0, 0, 0.05); 
                text-indent: 12px;
                letter-spacing: 1px;
                transition: 0.3s;
                }

                .bar_pencarian input:focus,
                .bar_pencarian input:hover {
                color: #00282b;
                border: 1.5px solid #00282b;
                }

                .base_keranjang, .keranjang {
                margin: auto;
                width: 30px ;
                height: 30px ;
                display: block;
                transition: 0.3s;
                transition: 0.3s;
                justify-content: center; /* Mengatur konten secara horizontal ke tengah */
                align-items: center; /* Mengatur konten secara vertikal ke tengah */
                }

                .keranjang:hover {
                transform: scale(1.2);
                }

                .keranjang:active {
                animation: beat 0.3s alternate;
                transform-origin: center;
                } 

                @keyframes beat{
                to { transform: scale(1.4); }
                }

                .base_username {
                margin: auto;
                width: auto;
                display: inline-flex; /* Menggunakan inline-flex untuk menyesuaikan lebar dengan konten */
                justify-content: center; /* Mengatur konten secara horizontal ke tengah */
                align-items: center; /* Mengatur konten secara vertikal ke tengah */
                border: 1.5px solid #f2f2f2;
                border-radius: 25px;
                color: #ffffff;
                font-family: "Poppins", sans-serif;
                letter-spacing: 1px;
                padding: 5px 12px; /* Padding untuk memberikan ruang di sekitar teks */
                font-weight: 600;
                text-decoration: none;
                transition: 0.3s; /* Hanya perlu ditulis sekali */
                }

                .tulisan {
                overflow: hidden; /* Sembunyikan teks yang melampaui batas */
                white-space: nowrap !important; /* Mencegah teks membungkus ke baris baru */
                text-overflow: ellipsis !important; /* Tambahkan ellipsis (...) */
                max-width: calc(8vw) !important; 
                width: auto;
                text-align: center !important;  
                }

                .base_username:hover {
                background-color: #f2f2f2;
                color: rgb(39, 74, 94);
                }
                
                .base_profil, .profil {
                margin: auto;
                width: auto ;
                height: 30px ;
                display: flex;
                z-index: 110;
                transition: 0.3s;
                padding-right: 30;
                transition: 0.3s;
                right: 0;   
                }
                
                .profil:hover {
                transform: scale(1.2);
                }

                .profil:active {
                animation: beat 0.3s alternate;
                transform-origin: center;
                } 

                .container-fluid {
                max-width: 95% !important;
                }

                @media (max-width: 615px) {
                    .kolom_keranjang {
                        display: none !important;
                    }
                }

                @media (max-width: 500px) {
                    .kolom_nama {
                        display: none !important;
                    }
                }

                @media (max-width: 400px) {
                    .kolom_profil {
                        display: none !important;
                    }
                }

            /* CSS : Navagation Bar Selesai */
            /* CSS : Isi Website */

                /* Setel ukuran font dan penataan teks untuk header */
                .header {
                    font-size: 20px;
                    font-weight: bold;
                    margin: 10px 0;
                    text-align: center;
                }
                /* Menambahkan padding, margin, dan bayangan untuk setiap bagian */
                .section {
                    padding: 20px;
                    margin: 30px auto;
                    background-color: transparent;
                    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
                    border-radius: 10px;
                    max-width: 1000px; 
                    width: 100%; 
                }
                /* Setel gaya untuk header pada setiap section */
                .section-header {
                    font-size: 16px;
                    font-weight: bold;
                    display: flex;
                    align-items: center;
                    background-color: transparent;
                    padding: 10px;
                    border-radius: 10px;
                    box-shadow: 0 4px 4px rgba(0, 0, 0, 0.3);
                }
                /* Menambah padding untuk isi section */
                .section-body {
                    padding: 5px 0;
                }
                /* Mengatur ukuran ikon */
                .icon {
                    font-size: 20px;
                    margin-right: 5px;
                }
                /* Menghilangkan border atas di tabel */
                .table th, .table td {
                    border-top: none;
                }
                /* Gaya untuk tombol khusus */
                .btn-custom {
                    background-color: rgb(111, 158, 172);
                    color: rgb(235, 229, 229);
                    border-radius: 5px;
                    padding: 5px 10px;
                    font-size: 14px;
                }
                /* Mengatur gambar agar responsif */
                .img-fluid {
                    max-width: 80px;
                    height: auto;
                }
                /* Menetapkan lebar untuk input jumlah produk */
                .product-quantity {
                    width: 50px;
                }
                /* Menambahkan margin atas untuk header tabel */
                .table-header {
                    font-weight: bold;
                    margin-top: 10px;
                }
                /* Menetapkan gaya untuk card */
                .card {
                    background-color: transparent;
                    border: none;
                }
                /* Gaya untuk header card */
                .card-header {
                    background-color: #ffffff;
                    border-radius: 10px;
                    font-weight: bold;
                }
                /* Gaya untuk body card */
                .card-body {
                    background-color: transparent;
                }

            /* CSS : Isi Website Selesai */

            /* Input telepon */

            .input-telepon {
                /* Anda bisa menambahkan gaya untuk .input-telepon di sini jika diperlukan */
            }

            .input-telepon .select-box {
                position: relative;
            }

            .input-telepon .select-box input {
                width: 100%;
                padding: 1rem .6rem;
                font-size: 1.1rem;
                
                border: 0.5px solid rgba(0, 0, 0, 0 .4);
                outline: none;
            }

            .input-telepon input[type="tel"] {
                border-radius: 0 .5rem .5rem 0;
            }

            .input-telepon .select-box input:focus {
                border: .1rem solid var(--primary);
            }

            .input-telepon .selected-option {
                background-color: #eee;
                border-radius: .5rem;
                overflow: hidden;

                display: flex;
                justify-content: space-between;
                align-items: center;
            }

            .input-telepon .selected-option div {
                position: relative;

                width: 6rem;
                padding: 0 2.8rem 0 .5rem;
                text-align: center;
                cursor: pointer;
            }

            .input-telepon .selected-option div::after {
                position: absolute;
                content: "";
                right: .8rem;
                top: 50%;
                transform: translateY(-50%) rotate(45deg);
                
                width: .8rem;
                height: .8rem;
                border-right: .12rem solid var(--primary);
                border-bottom: .12rem solid var(--primary);

                transition: .2s;
            }

            .input-telepon .selected-option div.active::after {
                transform: translateY(-50%) rotate(225deg);
            }

            .input-telepon .select-box .options {
                position: absolute;
                top: 4rem;
                
                width: 100%;
                background-color: #fff;
                border-radius: .5rem;

                display: none;
            }

            .input-telepon .select-box .options.active {
                display: block;
                z-index: 100;
            }

            .input-telepon .select-box .options::before {
                position: absolute;
                content: "";
                left: 1rem;
                top: -1.2rem;
                display: none;
                width: 0;
                height: 0;
                border: .6rem solid transparent;
                border-bottom-color: var(--primary);
            }

            .input-telepon input.search-box {
                background: rgb(16,181,212); 
                background: linear-gradient(90deg, rgba(16,181,212,1) 0%, rgba(110,227,202,1) 100%);
                color: #eee;
                border-radius: .5rem .5rem 0 0;
                padding: 1.4rem 1rem;
                border: none;
                font-weight: bold;
            }

            .input-telepon input.search-box::placeholder {
                color : #eee;
                opacity: 70%;
            }

            .input-telepon .select-box ol {
                list-style: none;
                max-height: 23rem;
                overflow: overlay;
            }

            .input-telepon .select-box ol::-webkit-scrollbar {
                width: 0.6rem;
            }

            .input-telepon .select-box ol::-webkit-scrollbar-thumb {
                width: 0.4rem;
                height: 3rem;
                background-color: #ccc;
                border-radius: .4rem;
            }

            .input-telepon .select-box ol li {
                padding: 1rem;
                display: flex;
                justify-content: space-between;
                cursor: pointer;
            }

            .input-telepon .select-box ol li.hide {
                display: none;
            }

            .input-telepon .select-box ol li:not(:last-child) {
                border-bottom: .1rem solid #eee;
            }

            .input-telepon .select-box ol li:hover {
                background-color: lightcyan;
            }

            .input-telepon .select-box ol li .country-name {
                margin-left: .4rem;
            }

            /* Css Input Telepon Selesai */

        </style>

    <!-- Internal CSS Selesai -->

    <!-- Navagation Bar -->

        <nav class="navbar navbar-expand-lg">

        <div class="container-fluid">

        <div class="col-auto d-flex justify-content-start kolom_logo">
            <a class="navbar-brand" href="../halaman_beranda/halaman_beranda.php">
                <img src="../img/icon/logo2.png" alt="logo" width="auto" height="auto">
            </a>
        </div>


        <div class="col-auto d-flex justify-content-end kolom_konten">

            <div class="col-md-auto d-flex kolom_keranjang d-flex px-0 mr-5 justify-content-end">
                <!-- Logo Keranjang -->

                <td>
                    <form action="../halaman_keranjang/halaman_keranjang.php" method="post" name="tombol_keranjang">
                        <button style="border: none; background: transparent;" class="base_keranjang" type="submit">
                            <img src="..\img\icon\icon_keranjang.svg" alt="keranjang" class="keranjang">
                        </button>
                    </form>
                </td>

            </div>

            <div class="col-md-auto kolom_nama d-flex mr-5 justify-content-end">
                <!-- Nama Pengguna -->

                <td>
                    <a href="../halaman_list/list_sewa.php" class="base_username d-flex justify-content-end" id="username">
                        <div class="tulisan">
                            sekopsekopang<?php # echo $_SESSION['nama_pengguna'];  ?>
                        </div>
                    </a>
                </td>

            </div>

            <div class="col-auto d-flex kolom_profil px-0">
                <!-- Foto profil -->

                <td>
                    <a href="../halaman_list/list_sewa.php" class="base_profil">
                    <img src="..\img\icon\profile.jpg<?php # if($_SESSION['foto_pengguna'] == NULL) {echo "..\img\icon\profile.jpg";} else{echo $_SESSION['foto_pengguna'];}?>" style="transform: scale(1.3); aspect-ratio: 1/1; object-fit: cover;" alt="photo_profil" class="profil rounded-circle border border-success border-opacity-25 shadow">
                    </a>
                </td>
                <style>
                    .base_profil:hover, .profil:hover {
                        transform: scale(1.3);
                    }
                
                    @media (max-width: 400px) {
                        .kolom_konten {
                            display: none !important;
                        }
                        .kolom_logo {
                            justify-content: center !important;
                            margin: auto;
                        }
                    }
        
                </style>
            </div>
        </div>

        </div>

        </nav>

    <!-- Navagation Bar Selesai -->

    <!-- Isi Website -->

        <div class="isi" style="padding-bottom: 150px">    

            <!-- Produk Dipesan Section -->

                <div class="section">

                    <div class="section-header p-3 bg-primary-subtle">
                        <i class="fa-solid fa-box icon me-3"></i>
                        Pesanan Anda Telah Dibuat
                    </div>

                    <div class="section-body mt-3">

                        <!-- PHP Data Informasi Busana -->

                            <?php

                            $con = mysqli_connect("localhost", "root", "", "waju");

                            // Cek koneksi
                            if (!$con) {
                                die("Koneksi gagal: " . mysqli_connect_error());
                            }

                            ?>

                        <!-- PHP Data Informasi Busana Selesai -->

                        <div class="card">
                            <div class="card-body bg-light rounded shadow-sm border border-success border-opacity-25 p-3" style="background-image: url(../img/foto/nota.png); object-fit: cover; background-size: cover; background-position: center;">
                                <div class="container row mt-3">

                                    <img src="../img/icon/logo2.png" class="mb-3 m-auto" alt="logo" style="filter: brightness(0) saturate(100%) invert(59%) sepia(0%) saturate(52%) hue-rotate(245deg) brightness(101%) contrast(91%); width: 250px; height: auto; opacity: 0.5;">

                                    <div class="row">

                                        <div class="col">
                                            <p class="text-start font-monospace fs-6 fst-italic">Nama Penyewa : </p>
                                        </div>

                                        <div class="col">
                                            <p class="text-end font-monospace fs-6 fst-italic">Tanggal Pemesanan :</p>
                                        </div>

                                    </div> 

                                    <div class="row">

                                        <div class="col">
                                            <p class="text-start font-monospace fs-6 fst-italic">Nama Pemilik Busana : </p>
                                        </div>

                                        <div class="col">
                                            <p class="text-end font-monospace fs-6 fst-italic">Alamat Pemilik Busana : </p>
                                        </div>

                                    </div>

                                    <hr style="border-top: 1px dashed black;">

                                    <p class="text-center" ><span class="fs-5 fst-italic fw-light font-monospace">Total Pembayaran pembayaran</span></p>

                                    <hr style="border-top: 1px dashed black;">

                                    <div class="nota_1_hari">

                                        <div class="row mt-2 mb-2">

                                            <div class="col-md-9">

                                                <p class="font-monospace fs-5 fw-bold">Nama Produk</p>

                                                <p class="font-monospace fs-6 nota_1_hari">1 hari</p>

                                                <p class="font-monospace fs-6 nota_2_hari">2 hari</p>

                                                <p class="font-monospace fs-6 nota_3_hari">3 hari</p>

                                                <p class="font-monospace fs-6 nota_ukuran_s">Ukuran S</p>

                                                <p class="font-monospace fs-6 nota_ukuran_m">Ukuran M</p>

                                                <p class="font-monospace fs-6 nota_ukuran_l">Ukuran L</p>

                                                <p class="font-monospace fs-6 nota_tanggal_penyewaan">Tanggal Penyewaan : 01 Dexember 2525</p>

                                                <p class="font-monospace fs-6 nota_tanggal_pengembaian">Tanggal Pengembalian : 02 Dexember 2525</p>

                                                <p class="font-monospace fs-6 nota_tanggal_pengembaian">Tanggal Pengembalian : 03 Dexember 2525</p>

                                                <p class="font-monospace fs-6 nota_tanggal_pengembaian">Tanggal Pengembalian : 04 Dexember 2525</p>

                                            </div>

                                            <div class="col-md-3 d-flex justify-content-end">

                                                <div class="col-md-4">

                                                    <p class="font-monospace fs-6 fw-bold">Rp.</p>

                                                </div>
                                                
                                                <div class="col-md-8 d-flex justify-content-end">

                                                    <p class="font-monospace fs-6 fw-bold">100000000</p>

                                                </div>

                                            </div>


                                        </div>

                                    </div>

                                    <hr style="border-top: 1px dashed black;">

                                    <div class="biaya_1_hari">

                                        <div class="row mt-2 mb-2"> <!-- 1 Hari -->

                                            <div class="col-md-9">

                                                <p class="font-monospace fs-6 fw-bold nota_biaya_layanan">Biaya Layanan (5%)</p>

                                            </div>
                                            

                                            <div class="col-md-3 d-flex justify-content-end">

                                                <div class="col-md-4">

                                                    <p class="font-monospace fs-6 fw-bold">Rp.</p>

                                                </div>
                                                
                                                <div class="col-md-8 d-flex justify-content-end">

                                                    <p class="font-monospace fs-6 fw-bold nota_biaya_layanan">100000000</p>

                                                </div>

                                            </div>

                                        </div>

                                        <div class="row mt-2 mb-2">

                                            <div class="col-md-9">

                                                <p class="font-monospace fs-6 fw-bold nota_biaya_layanan">PPN (11%)</p>

                                            </div>
                                            

                                            <div class="col-md-3 d-flex justify-content-end">

                                                <div class="col-md-4">

                                                    <p class="font-monospace fs-6 fw-bold">Rp.</p>

                                                </div>
                                                
                                                <div class="col-md-8 d-flex justify-content-end">

                                                    <p class="font-monospace fs-6 fw-bold nota_biaya_layanan">100000000</p>

                                                </div>

                                            </div>

                                        </div>
                                        
                                        <div class="row mt-2 mb-2">

                                            <div class="col-md-9">

                                                <p class="font-monospace fs-6 fw-bold nota_biaya_layanan">Diskon</p>

                                            </div>
                                            

                                            <div class="col-md-3 d-flex justify-content-end">

                                                <div class="col-md-4">

                                                    <p class="font-monospace fs-6 fw-bold">Rp.</p>

                                                </div>
                                                
                                                <div class="col-md-8 d-flex justify-content-end">

                                                    <p class="font-monospace fs-6 fw-bold nota_biaya_layanan">- 0</p>

                                                </div>

                                            </div>

                                        </div>
                                
                                    </div>
                                    
                                    <hr style="border-top: 1px dashed black;">

                                    <div class="total_1_hari">

                                        <div class="row mt-2 mb-2">

                                            <div class="col-md-9">

                                                <p class="font-monospace fs-6 fw-bolder nota_total">Total Pembayaran</p>

                                            </div>
                                            

                                            <div class="col-md-3 d-flex justify-content-end">

                                                <div class="col-md-4">

                                                    <p class="font-monospace fs-6 fw-bold">Rp.</p>

                                                </div>
                                                
                                                <div class="col-md-8 d-flex justify-content-end">

                                                    <p class="font-monospace fs-6 fw-bold nota_biaya_total">100000</p>

                                                </div>

                                            </div>

                                        </div>

                                    </div>
                                    
                                    <div class="footer_nota mt-5">

                                        <p class="font-monospace f-6 text-center">

                                            Terima kasih telah menggunakan WA! JU! sebagai platform sewa busana pertama di Indonesia!

                                        </p>

                                        <p class="font-monospace f-6 text-center">

                                            Saran dan Kritik : 0896-6891-4466, Instagram : @waajuu

                                        </p>

                                        <p class="font-monospace f-6 text-center">

                                            sewawaju.my.id

                                        </p>

                                    </div>

                                    <img src="../img/icon/logo2.png" class="mb-3 m-auto" alt="logo" style="filter: brightness(0) saturate(100%) invert(59%) sepia(0%) saturate(52%) hue-rotate(245deg) brightness(101%) contrast(91%); width: 150px; height: auto; opacity: 0.8;">

                                    
                                </div>
                            </div>
                        </div>
                        
                        <!-- Tombol kembali beranda -->

                        <div class="text-center mt-3 m-auto">
                            <a href="../halaman_beranda/halaman_beranda.php" class="btn btn-primary btn-lg">Kembali Ke Beranda</a>
                        </div>

                        <!-- Tombol kembali Beradna selesia -->

                    </div>

                </div>

            <!-- Isi Website Selesai -->


        </div>

    <!-- Isi Website Selesai -->

    <!-- Footer Website -->
                        
        <link rel="stylesheet" href="..\footer\footer.css">

        <?php

            // Koneksi ke database
            $con = mysqli_connect("localhost", "root", "", "waju");

            // Cek koneksi
            if (!$con) {
                die("Koneksi gagal: " . mysqli_connect_error());
            }

            $query = "SELECT * FROM footer"; // Menggunakan nama_baju
            $result = mysqli_query($con, $query);

            $footer = mysqli_fetch_assoc($result);
            
            echo $footer['footer'];

        ?>

    <!-- Footer Website Selesai -->

    <!-- Script Section -->

        <!-- Skrip JS Eksternal -->
            <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
            <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
            <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
            <script src="..\bootstrap\js\bootstrap.min.js"></script>
            <script src="https://unpkg.com/bootstrap-material-design@4.1.1/dist/js/bootstrap-material-design.js" integrity="sha384-CauSuKpEqAFajSpkdjv3z9t8E7RlpJ1UP0lKM/+NdtSarroVKu069AlsRPKkFBz9" crossorigin="anonymous"></script>

        <!-- Skrip JS Eksternal Selesai -->

        <!-- PHP Akhir -->
        <!-- PHP Akhir Selesai -->

    <!-- Script Section Selesai -->

  </body>
</html>