<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php if(isset($_GET['pencarian'])){echo $_GET['pencarian'];} ?></title>
    
    <!-- Menggunakan Bootstrap CSS dari file lokal -->
    <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

    <!-- Custom Font "Poppins" -->

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

    <!-- Logo Tab -->

    <link rel="icon" type="image/x-icon" href="../img/icon/logo_atas.svg">

    <!-- PHP -->

    <?php 

    session_start();

    if (isset($_SESSION['id']) && 
    isset($_SESSION['nama_pengguna']) &&
    isset($_SESSION['foto_pengguna'])) {

    ?>
    
    <!-- PHP Selesai -->


</head>

<body>

    <!-- Internal CSS -->

        <style>

            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
                font-family: "Poppins", sans-serif;
            }

            /* CSS : Navagation Bar */

                .navbar {
                    background-image: url(../img/icon/navbar.png);
                    background-size: cover;
                    border-bottom-left-radius: 20em 28em;
                    border-bottom-right-radius: 20em 28em;
                    height: 80px;
                    box-shadow: 0 0 100px rgba(0, 0, 0, 0.325);
                }

                .navbar-brand {
                    display: flex;
                    justify-content: center;
                    padding: 0px 0px 0% 0px !important;
                    margin: 0px 5px 0px 0px !important;
                    transition: 0.5s;
                }

                .navbar-brand:hover {
                    filter:invert(100%) !important;
                    opacity: 0.7;
                }

                .tombol_pencarian {
                    display: block;
                    width: 50px;
                    height: auto;
                    margin: 0 0 0 0; /* Menggabungkan margin */
                    border: 1px solid rgba(14, 89, 129, 0.178);
                    border-radius: 20px;
                    box-shadow: 0 0 20px rgba(0, 0, 0, 0.05); 
                    background: rgb(166, 214, 239) url(../img/icon/icon_cari.svg) no-repeat center / 25% !important; /* Menggabungkan properti background */
                    transition: 0.1s;
                }
        
                .tombol_pencarian:hover{
                    border: none !important;
                    filter:invert(20%) !important;
                }

                .tombol_pencarian:active{
                    background-size: 50% !important;
                }

                .bar_pencarian {
                    color: rgba(91, 91, 91, 0.57);            
                    border: 1px solid rgba(14, 89, 129, 0.178);
                    border-radius: 20px;
                    box-shadow: 0 0 20px rgba(0, 0, 0, 0.05); 
                    text-indent: 12px;
                    letter-spacing: 1px;
                    transition: 0.3s;
                }

                .bar_pencarian input:focus,
                .bar_pencarian input:hover {
                    color: #00282b;
                    border: 1.5px solid #00282b;
                }

                .base_keranjang, .keranjang {
                    margin: auto;
                    width: 30px ;
                    height: 30px ;
                    display: block;
                    transition: 0.3s;
                    transition: 0.3s;
                    justify-content: center; /* Mengatur konten secara horizontal ke tengah */
                    align-items: center; /* Mengatur konten secara vertikal ke tengah */
                }
            
                .keranjang:hover {
                    transform: scale(1.2);
                }

                .keranjang:active {
                    animation: beat 0.3s alternate;
                    transform-origin: center;
                } 
            
                @keyframes beat{
                    to { transform: scale(1.4); }
                }

                .base_username {
                    margin: auto;
                    width: auto;
                    display: inline-flex; /* Menggunakan inline-flex untuk menyesuaikan lebar dengan konten */
                    justify-content: center; /* Mengatur konten secara horizontal ke tengah */
                    align-items: center; /* Mengatur konten secara vertikal ke tengah */
                    border: 1.5px solid #f2f2f2;
                    border-radius: 25px;
                    color: #ffffff;
                    font-family: "Poppins", sans-serif;
                    letter-spacing: 1px;
                    padding: 5px 12px; /* Padding untuk memberikan ruang di sekitar teks */
                    font-weight: 600;
                    text-decoration: none;
                    transition: 0.3s; /* Hanya perlu ditulis sekali */
                }

                .tulisan {
                    overflow: hidden; /* Sembunyikan teks yang melampaui batas */
                    white-space: nowrap !important; /* Mencegah teks membungkus ke baris baru */
                    text-overflow: ellipsis !important; /* Tambahkan ellipsis (...) */
                    max-width: calc(8vw) !important; 
                    width: auto;
                    text-align: center;
                }


                .base_username:hover {
                    background-color: #f2f2f2;
                    color: rgb(39, 74, 94);
                }
                
                .base_profil, .profil {
                    margin: auto;
                    width: auto ;
                    height: 30px ;
                    display: flex;
                    z-index: 110;
                    transition: 0.3s;
                    padding-right: 30;
                    transition: 0.3s;
                    right: 0;   
                }
                
                .profil:hover {
                    transform: scale(1.2);
                }

                .profil:active {
                    animation: beat 0.3s alternate;
                    transform-origin: center;
                } 

                .container-fluid {
                    max-width: 95% !important;
                }

                @media (max-width: 1245px) {
                    .kolom_profil {
                        display: none !important;
                    }

                    .kolom_logo,
                    .kolom_pencarian {
                        margin-left: 30px;
                    }
                }

                @media (max-width: 992px) {
                    .kolom_logo {
                        margin: 0 0 0 50px;
                    }
                    .kolom_pencarian {
                        margin: auto;
                        max-width: 60vw;
                    }
                    .kolom_keranjang {
                        display: none !important;
                    }
                    .kolom_nama {
                        display: none;
                    }
                    .kolom_profil {
                        display: flex !important;
                    }
                    .kolom_konten {
                        width: auto !important;
                        margin: 0 0 0 30px;
                    }
                }

                @media (max-width: 741px) {
                    .kolom_konten {
                        display: none !important;
                    }
                    .kolom_logo {
                        width: 20vw !important;
                    }
                    .kolom_pencarian {
                        width: 60vw !important;
                    }
                }

                @media (max-width: 540.98px) {
                    .kolom_pencarian {
                        display: none;
                    }
                    .kolom_logo {
                        margin: 0 0 0 0 !important;
                        width: 100% !important;
                        align-items: center;
                        justify-content: center;
                        display: block !important;
                    }
                    .navbar-brand {
                        align-items: center !important;
                        justify-content: center !important;
                    }
                }

            /* CSS : Navagation Bar Selesai */

            /* CSS : Isi Website */

                .isi{
                    max-width: 100%;
                    padding-top: 0px;
                    margin: 0;
                    overflow-x: hidden;
                    padding-bottom:100px;
                }

                .info-produk-baju .card-title,
                .info-produk-baju .card-text {
                    line-clamp: 1;
                    overflow: hidden; /* Sembunyikan teks yang melampaui batas */
                    white-space: nowrap !important; /* Mencegah teks membungkus ke baris baru */
                    text-overflow: ellipsis !important; /* Tambahkan ellipsis (...) */
                }

                .foto_baju {
                    min-width: 200px;
                    aspect-ratio: 3/4;
                    height: auto;
                    object-fit: cover;
                }

                /* Tentang */
                .about {
                    padding: 50px 0;
                    background-color: #fff;
                    text-align: center;
                    }
                    .about h2 {
                    margin-bottom: 20px;
                    font-size: 2rem;
                    }
                    .about p {
                    margin: 10px 0;
                    font-size: 1.1rem;
                    }
                    
                /* Footer */

                .footer {
                    background: #333;
                    color: white;
                    text-align: center;
                    padding: 10px;
                    position: relative;
                    width: 100%;
                    bottom: 0;
                }
                .footer .social-links {
                    list-style: none;
                    display: flex;
                    justify-content: center;
                    margin: 15px 0;
                }
                .footer .social-links li {
                    margin: 0 10px;
                }
                .footer .social-links a {
                    color: white;
                    text-decoration: none;
                    font-size: 1.2rem;
                }
                .footer .social-links a:hover {
                    color: #ff6347
                }
            
            /* CSS : Isi Website Selesai */
        
        </style>

    <!-- Internal CSS Selesai --> 

    <!-- Navagation Bar -->

        <nav class="navbar navbar-expand-lg">

        <div class="container-fluid">

            <div class="col-2 kolom_logo">
                <a class="navbar-brand" href="../halaman_beranda/halaman_beranda.php">
                    <img src="../img/icon/logo2.png" alt="logo" width="auto" height="auto">
                </a>
            </div>

            <div class="col-7 kolom_pencarian">
                <!-- Bar Pencarian -->
                <form class="d-flex" style="padding-left: 20px;" action="" method="get">
                    <input class="bar_pencarian form-control me-2" name="pencarian" value="<?php if(isset($_GET['pencarian'])){echo $_GET['pencarian'];} ?>" type="search" placeholder="Hari ini mau keren yang mana?" aria-label="Search" required maxlength="60" oninvalid="this.setCustomValidity('Isi dong, mau nyari apa kalau kosong.')" oninput="setCustomValidity('')">
                    <button class="tombol_pencarian btn btn-outline-success" type="submit"></button>
                </form>
            </div>

            <div class="col-3 row d-flex justify-content-center kolom_konten">

                <div class="col-auto d-flex kolom_keranjang">
                    <!-- Logo Keranjang -->

                    <td>
                        <form action="../halaman_keranjang/halaman_keranjang.php" method="post" name="tombol_keranjang">
                            <button style="border: none; background: transparent;" class="base_keranjang" type="submit">
                                <img src="..\img\icon\icon_keranjang.svg" alt="keranjang" class="keranjang">
                            </button>
                        </form>
                    </td>

                </div>

                <div class="col-md-6 kolom_nama d-flex">
                    <!-- Nama Pengguna -->

                    <td>
                        <a href="../halaman_list/list_sewa.php" class="base_username" id="username">
                            <div class="tulisan">
                                <?php echo $_SESSION['nama_pengguna']; ?>
                            </div>
                        </a>
                    </td>

                </div>

                <div class="col-auto d-flex kolom_profil">
                    <!-- Foto profil -->

                    <td>
                    <a href="../halaman_list/list_sewa.php" class="base_profil">
                            <img src="<?php if($_SESSION['foto_pengguna'] == NULL) {echo "..\img\icon\profile.jpg";} else{echo $_SESSION['foto_pengguna'];}?>" style="transform: scale(1.3); aspect-ratio: 1/1; object-fit: cover;" alt="photo_profil" class="profil rounded-circle border border-success border-opacity-25 shadow">
                        </a>
                        <style>
                            .base_profil:hover, .profil:hover {
                            transform: scale(1.3);
                            }
                        </style>
                    </td>
                </div>

            </div>

        </div>

        </nav>

    <!-- Navagation Bar Selesai -->

    <!-- Isi Website -->

        <div class="isi" style="padding-bottom: 160px;">
            
            <!-- Content -->
            <div class="container-fluid mt-5">

                <div class="row">
                    <!-- Sidebar -->
                
                    <div class="col-md-2 bg-light">
                        <ul class="list-group list-group-flush p-2 pt-4">
                            <li class="list-group-item bg-warning">
                                <i class="fas fa-list"></i> Kategori Produk
                            </li>
                            <li class="list-group-item">
                                <a href="../halaman_pencarian/halaman_pencarian.php?pencarian=Cosplay" class="dropdown-item">
                                <i class="fas fa-angle-right"></i> Cosplay
                                </a>
                            </li>
                            <li class="list-group-item">
                                <a href="../halaman_pencarian/halaman_pencarian.php?pencarian=Baju+Adat" class="dropdown-item">
                                <i class="fas fa-angle-right"></i> Baju Adat
                                </a>
                            </li>
                            <li class="list-group-item">
                                <a href="../halaman_pencarian/halaman_pencarian.php?pencarian=Marvel" class="dropdown-item">
                                    <i class="fas fa-angle-right"></i> Marvel
                                    </a>
                            </li>
                            <li class="list-group-item">
                                <a href="../halaman_pencarian/halaman_pencarian.php?pencarian=Disney" class="dropdown-item">
                                    <i class="fas fa-angle-right"></i> Disney
                                    </a>
                            </li>
                            <li class="list-group-item">
                                <a href="../halaman_pencarian/halaman_pencarian.php?pencarian=Halloween" class="dropdown-item">
                                    <i class="fas fa-angle-right"></i> Halloween
                                    </a>
                            </li>
                            <li class="list-group-item">
                                <a href="../halaman_pencarian/halaman_pencarian.php?pencarian=Super+Hero" class="dropdown-item">
                                    <i class="fas fa-angle-right"></i> Super Hero
                                    </a>
                            </li>
                        </ul>
                    </div>
            
                    <!-- Hasil Pencarian -->

                    <div class="col-md-10">
                        <p class="text-center fw-light my-4"> Menampilkan hasil pencarian <strong>"<?php echo $_GET['pencarian']; ?>"</strong>.<p>
                        <div class="row">

                            <tbody>

                            <?php

                            $con = mysqli_connect("localhost", "root", "", "waju");

                            if (isset($_GET['pencarian'])) {
                                $filtervalues = $_GET['pencarian'];
                                
                                // Menghapus spasi dari filtervalues
                                $filtervalues_no_space = str_replace(' ', '', $filtervalues);
                                
                                // Menggunakan REPLACE untuk menghapus spasi dari nama_baju dan kategori_baju
                                $query = "SELECT * FROM databaju 
                                        WHERE LOWER(REPLACE(nama_baju, ' ', '')) LIKE LOWER('%$filtervalues_no_space%') 
                                        OR LOWER(REPLACE(kategori_baju, ' ', '')) LIKE LOWER('%$filtervalues_no_space%')";
                                
                                $query_run = mysqli_query($con, $query);

                                if (mysqli_num_rows($query_run) > 0) {
                                    foreach ($query_run as $items) {
                                        ?>
                                        <div class="col-md-3 mb-3">
                                            <div class="info-produk-baju card">
                                                <img src="<?= $items['foto_baju']; ?>" class="card-img-top img-fluid foto_baju" alt="Product1">
                                                <div class="card-body bg-light">
                                                    <h5 class="card-title"><?= $items['nama_baju']; ?></h5>
                                                    <p class="card-text"><?= $items['kategori_baju']; ?></p>
                                                    <table>
                                                        <tr style="padding-bottom: 10px">
                                                            <td style="padding-right:10px;">Tersewa <span style="font-weight: 750;"><?= $items['tersewa_baju']; ?></span> Kali</td>
                                                            <td>|</td>
                                                            <td style="padding-left:10px;">Rating <span style="font-weight: 750;"><?= $items['rating_baju']; ?></span> <i class="fa-solid fa-star" style="color: #FFD43B;"></i></td>
                                                        </tr>
                                                    </table>
                                                    <br>
                                                    <form method="get" action="../halaman_katalog/halaman_katalog.php">
                                                        <input type="hidden" name="tombol_baju" value="<?= $items['nama_baju']; ?>"> <!-- Mengirimkan nama_baju -->
                                                        <button type="submit" class="btn btn-primary"><?= $items['harga_baju']; ?>/hari</button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                    }
                                } else {
                                    echo "<p class='text-center'>Tidak ada hasil ditemukan untuk pencarian <strong>\"$filtervalues\"</strong>.</p>";
                                    echo "<style> .footer {position: absolute;} </style>";
                                }
                            }
                            ?>
                            </tbody>
                        </div>
                    </div>
                </div>
            </div>
        </div>    
                    
    <!-- Isi Website Selesai -->

    <!-- Footer -->

        <link rel="stylesheet" href="..\footer\footer.css">

        <?php

                // Koneksi ke database
                $con = mysqli_connect("localhost", "root", "", "waju");

                // Cek koneksi
                if (!$con) {
                    die("Koneksi gagal: " . mysqli_connect_error());
                }

                $query = "SELECT * FROM footer"; // Menggunakan nama_baju
                $result = mysqli_query($con, $query);

                $footer = mysqli_fetch_assoc($result);
                
                echo $footer['footer'];

        ?>
    
    <!-- Footer Selesai -->

    <!-- Script Section -->

        <!-- Bootstrap JS dari file lokal -->
        <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>


        <!-- PHP Akhir -->

            <?php 
            
            }
            
            else{
                header("Location: ../halaman_utama/halaman_utama.html");
                exit();
            }

            ?>

        <!-- PHP Akhir Selesai -->

    <!-- Script Section Selesai -->

</body>
</html>