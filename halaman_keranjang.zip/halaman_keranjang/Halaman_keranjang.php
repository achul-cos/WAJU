<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Keranjang Belanja</title>
    <link crossorigin="anonymous" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" rel="stylesheet"/>
  
    <!-- Custom Font "Poppins" -->

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0&icon_names=check" />

    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Material+Icons">
    <link rel="stylesheet" href="https://unpkg.com/bootstrap-material-design@4.1.1/dist/css/bootstrap-material-design.min.css" integrity="sha384-wXznGJNEXNG1NFsbm0ugrLFMQPWswR3lds2VeinahP8N0zJw9VWSopbjv2x7WCvX" crossorigin="anonymous">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons">    

    <!-- Menggunakan Bootstrap CSS dari file lokal -->
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <!-- Logo Tab -->

    <link rel="icon" type="image/x-icon" href="../img/icon/logo_atas.svg">

    <!-- PHP -->

    <?php 

    session_start();

    if (isset($_SESSION['id']) && 
    isset($_SESSION['nama_pengguna']) &&
    isset($_SESSION['foto_pengguna'])) {

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            // Proses data form di sini
            // Misalnya, simpan data ke database atau lakukan tindakan lain
    
            // Setelah memproses, alihkan ke halaman yang sama
            header("Location: " . $_SERVER['PHP_SELF']);
            exit(); // Pastikan untuk keluar setelah mengalihkan
        }

    ?>

    <!-- PHP Selesai -->


</head>

    <body>

        <!-- Internal CSS -->

        <style>

        /* Reset standar untuk semua elemen */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: "Poppins", sans-serif;
        }
        /* Gaya background halaman */
        body {
            background: #fffefe;
        }
  
        /* CSS : Navagation Bar */

        .navbar {
            background-image: url(../img/icon/navbar.png);
            background-size: cover;
            border-bottom-left-radius: 20em 28em;
            border-bottom-right-radius: 20em 28em;
            height: 80px;
            box-shadow: 0 0 100px rgba(0, 0, 0, 0.325);
        }

        .navbar-brand {
            display: flex;
            justify-content: center;
            padding: 0px 0px 0% 0px !important;
            margin: 0px 5px 0px 0px !important;
            transition: 0.5s;
        }

        .navbar-brand:hover {
            filter:invert(100%) !important;
            opacity: 0.7;
        }

        .tombol_pencarian {
            display: block;
            width: 50px;
            height: auto;
            margin: 0 0 0 0; /* Menggabungkan margin */
            border: 1px solid rgba(14, 89, 129, 0.178);
            border-radius: 20px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.05); 
            background: rgb(166, 214, 239) url(../img/icon/icon_cari.svg) no-repeat center / 25% !important; /* Menggabungkan properti background */
            transition: 0.1s;
        }
   
        .tombol_pencarian:hover{
            border: none !important;
            filter:invert(20%) !important;
        }

        .tombol_pencarian:active{
            background-size: 50% !important;
        }

        .bar_pencarian {
            color: rgba(91, 91, 91, 0.57);            
            border: 1px solid rgba(14, 89, 129, 0.178);
            border-radius: 20px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.05); 
            text-indent: 12px;
            letter-spacing: 1px;
            transition: 0.3s;
        }

        .bar_pencarian input:focus,
        .bar_pencarian input:hover {
            color: #00282b;
            border: 1.5px solid #00282b;
        }

        .base_keranjang, .keranjang {
            margin: auto;
            width: 30px ;
            height: 30px ;
            display: block;
            transition: 0.3s;
            transition: 0.3s;
            justify-content: center; /* Mengatur konten secara horizontal ke tengah */
            align-items: center; /* Mengatur konten secara vertikal ke tengah */
        }
    
        .keranjang:hover {
            transform: scale(1.2);
        }

        .keranjang:active {
            animation: beat 0.3s alternate;
            transform-origin: center;
        } 
    
        @keyframes beat{
            to { transform: scale(1.4); }
        }

        .base_username {
            margin: auto;
            width: auto;
            display: inline-flex; /* Menggunakan inline-flex untuk menyesuaikan lebar dengan konten */
            justify-content: center; /* Mengatur konten secara horizontal ke tengah */
            align-items: center; /* Mengatur konten secara vertikal ke tengah */
            border: 1.5px solid #f2f2f2;
            border-radius: 25px;
            color: #ffffff;
            font-family: "Poppins", sans-serif;
            letter-spacing: 1px;
            padding: 5px 12px; /* Padding untuk memberikan ruang di sekitar teks */
            font-weight: 600;
            text-decoration: none;
            transition: 0.3s; /* Hanya perlu ditulis sekali */
        }

        .tulisan {
            overflow: hidden; /* Sembunyikan teks yang melampaui batas */
            white-space: nowrap !important; /* Mencegah teks membungkus ke baris baru */
            text-overflow: ellipsis !important; /* Tambahkan ellipsis (...) */
            max-width: calc(8vw) !important; 
            width: auto;
            text-align: center !important;
            
        }

        .base_username:hover {
            background-color: #f2f2f2;
            color: rgb(39, 74, 94);
        }
        
        .base_profil, .profil {
            margin: auto;
            width: auto ;
            height: 30px ;
            display: flex;
            z-index: 110;
            transition: 0.3s;
            padding-right: 30;
            transition: 0.3s;
            right: 0;   
        }
        
        .profil:hover {
            transform: scale(1.2);
        }

        .profil:active {
            animation: beat 0.3s alternate;
            transform-origin: center;
        } 

        .container-fluid {
            max-width: 95% !important;
        }

        @media (max-width: 1245px) {
            .kolom_profil {
                display: none !important;
            }

            .kolom_logo,
            .kolom_pencarian {
                margin-left: 30px;
            }
        }

        @media (max-width: 992px) {
            .kolom_logo {
                margin: 0 0 0 50px;
            }
            .kolom_pencarian {
                margin: auto;
                max-width: 60vw;
            }
            .kolom_keranjang {
                display: none !important;
            }

            .kolom_nama {
                display: none !important;
            }
            .kolom_profil {
                display: flex !important;
            }
            .kolom_konten {
                width: auto !important;
                margin: 0 0 0 30px;
            }
        }

        @media (max-width: 741px) {
            .kolom_konten {
                display: none !important;
            }
            .kolom_logo {
                width: 20vw !important;
            }
            .kolom_pencarian {
                width: 60vw !important;
            }
        }

        @media (max-width: 600  px) {
            .kolom_pencarian {
                display: none;
            }
            .kolom_logo {
                margin: 0 0 0 0 !important;
                width: 100% !important;
                align-items: center;
                justify-content: center;
                display: block !important;
            }
            .navbar-brand {
                align-items: center !important;
                justify-content: center !important;
            }
        }

        /* CSS : Navagation Bar Selesai */

        /* Card ringkasan belanja */
        .summary-card {
            background: #d7eef1;
            padding: 30px;
            width: 420px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }
        
        /* Judul pada card ringkasan */
        .summary-card h5 {
            font-weight: bold;
        }

        /* Tampilan total di card ringkasan */
        .summary-card .total {
            font-weight: bold;
            font-size: 1.2em;
        }

        /* Tombol di dalam card ringkasan */
        .summary-card .btn {
            background-color: #89c0c7;
            border: none;
            border-radius: 15px;
            padding: 10px 20px;
            font-weight: bold;
            width: 360px;
        }

        /* Header pada halaman */
        .header {
            background-color: #d1e7dd;
            padding: 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        /* Gambar logo di header */
        .header img {
            height: 50px;
        }

        /* Judul di header */
        .header h1 {
            margin: 0;
            font-size: 24px;
            color: #333;
        }

        /* Input pencarian di header */
        .header input {
            width: 300px;
            padding: 5px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        /* Tombol pencarian di header */
        .header button {
            background-color: #0d6efd;
            border: none;
            padding: 5px 10px;
            color: white;
            border-radius: 5px;
        }
        .container {
            margin-top: 20px;
        }
        /* Daftar produk */
        .product-list {
            padding: 20px;
            background: #d7eef1;
            border-radius: 0px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }
        /* Item produk */
        .product-item {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
            border-bottom: 1px solid #ccc;
            padding-bottom: 10px;
        }
        /* Gambar produk */
        .product-item img {
            width: 100px;
            height: 110px;
        }
        /* Info produk */
        .product-item .product-info {
            flex-grow: 1;
            padding-left: 15px;
        }
        /* Aksi pada produk (misal tombol tambah dan hapus) */
        .product-item .product-actions {
            display: flex;
            align-items: center;
            margin-top: 10px;
        }
        /* Tombol dalam aksi produk */
        .product-item .product-actions button {
            margin: 0 5px;
        }
        /* Tampilan tombol aksi */
        .product-item .product-actions .btn {
            background-color: #6c757d;
            color: #ffffff;
            border-radius: 0;
            padding: 2px 5px;
        }
        /* Ikon di dalam tombol aksi */
        .product-item .product-actions .btn i {
            margin-right: 5px;
        }
        /* Tampilan kuantitas produk */
        .product-item .product-actions .quantity {
            display: flex;
            align-items: center;
        }
        /* Input kuantitas produk */
        .product-item .product-actions .quantity input {
            width: 30px;
            text-align: center;
            padding: 2px;
        }
        /* Tombol untuk menghapus produk */
        .product-item .product-actions .btn-trash {
            background-color: transparent;
            color: #636566;
            border: none;
        }
        /* Pembatas antar produk */
        .divider {
            border-bottom: 1.5px solid #636566;
            margin: 6px 0;
        }
        /* Checkbox untuk memilih produk */
        .product-item .form-check-input {
            margin-right: 15px;
            border: 2px solid #636566;
        }
        /* Checkbox yang tercentang */
        .product-item .form-check-input:checked {
            background-color: #636566;
            border-color: #636566;
        }
        /* Pembatas antara header */
        .header-divider {
            border-bottom: 2px solid #6c757d;
            margin-bottom: 20px;
        }
        /* Warna teks untuk judul header */
        .header h1.produk, .header h2.total {
            color: #333;
        /* Warna teks untuk judul header */
        }
        .header h1, .header h2 {
            color: #53575c;
        }
        /* Tampilan total di ringkasan */
        .summary .total {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
            font-weight: bold;
        }
        /* Tombol untuk melanjutkan ke checkout */
        .summary button {
            background-color: #c2e2e7;
            border: none;
            color: black;
            font-weight: bold;
            padding: 10px 20px;
            border-radius: 5px;
            width: 100%;
        }

        /* alerts */

        .alert {
            border: 0;
            border-radius: 0;
            padding: 20px 15px !important;
            line-height: 20px;
            font-weight: 300;
            color: #fff;
        }

        .alert .alert-icon {
            display: block;
            float: left;
            margin-right: 1.071rem;
        }

        .alert b {
            font-weight: 500;
            font-size: 12px;
            text-transform: uppercase;
        }

        .close {
            float: right;
            font-size: 1.5rem;
            color: #000;
            text-shadow: 0 1px 0 #fff;
            opacity: .5;
        }
        .alert .close {
            color: #fff;
            text-shadow: none;
            opacity: .9;
        }
        .alert .close i {
            font-size: 20px;
        }
        .alert .close:hover{
            opacity: 1;
            color: #fff;
        }
        .alert.alert-info {
            background-color: #00cae3;
            color: #fff;
        }

        .alert.alert-success {
            background-color: #55b559;
            color: #fff;
        }

        .alert.alert-warning {
            background-color: #ff9e0f;
            color: #fff;
        }

        .alert.alert-danger {
            background-color: #f55145;
            color: #fff;
        }

        .alert.alert-primary {
            background-color: #a72abd;
            color: #fff;
        }

    </style>

   <!--------------------------------------------------------------------------------------------->

    <!-- Navagation Bar -->

        <nav class="navbar navbar-expand-lg">

        <div class="container-fluid">

            <div class="col-2 kolom_logo">
                <a class="navbar-brand" href="../halaman_beranda/halaman_beranda.php">
                    <img src="../img/icon/logo2.png" alt="logo" width="auto" height="auto">
                </a>
            </div>

            <div class="col-7 kolom_pencarian">
                <!-- Bar Pencarian -->
                <form class="d-flex" style="padding-left: 20px;" method="get" action="../halaman_pencarian/halaman_pencarian.php">
                    <input class="bar_pencarian form-control me-2" name="pencarian" value="<?php if(isset($_GET['pencarian'])){echo $_GET['pencarian'];}?>" type="search" placeholder="Hari ini mau keren yang mana?" aria-label="Search" required maxlength="60" oninvalid="this.setCustomValidity('Isi dong, mau nyari apa kalau kosong.')" oninput="setCustomValidity('')">
                    <button class="tombol_pencarian btn btn-outline-success" type="submit"></button>
                </form>
            </div>

            <div class="col-3 row d-flex justify-content-center kolom_konten">

                <div class="col-auto d-flex kolom_keranjang">
                    <!-- Logo Keranjang -->

                    <td>
                        <form action="../halaman_keranjang/halaman_keranjang.php" method="post" name="tombol_keranjang">
                            <button style="border: none; background: transparent;" class="base_keranjang" type="submit">
                                <img src="..\img\icon\icon_keranjang.svg" alt="keranjang" class="keranjang">
                            </button>
                        </form>
                    </td>

                </div>

                <div class="col-md-6 kolom_nama d-flex">
                    <!-- Nama Pengguna -->

                    <td>
                        <a href="../halaman_list/list_sewa.php" class="base_username" id="username">
                            <div class="tulisan">
                                <?php echo $_SESSION['nama_pengguna']; ?>
                            </div>
                        </a>
                    </td>

                </div>

                <div class="col-auto d-flex kolom_profil">
                    <!-- Foto profil -->

                    <td>
                        <a href="../halaman_list/list_sewa.php" class="base_profil">
                        <img src="<?php if($_SESSION['foto_pengguna'] == NULL) {echo "..\img\icon\profile.jpg";} else{echo $_SESSION['foto_pengguna'];}?>" style="transform: scale(1.3); aspect-ratio: 1/1; object-fit: cover;" alt="photo_profil" class="profil rounded-circle border border-success border-opacity-25 shadow">
                    </a>
                    <style>
                        .base_profil:hover, .profil:hover {
                            transform: scale(1.3);
                        }
                    </style>
                    </td>
                </div>

            </div>

        </div>

        </nav>

    <!-- Navagation Bar Selesai -->
  
  <!--------------------------------------------------------------------------------------------->    

    <!-- Kontainer Produk dan Ringkasan Belanja -->
    <div style="padding-bottom: 120px;">
    <div class="container ">
        <div class="row">

            <!-- Kolom Produk -->
            <div class="col-md-12">
                <div class="product-list mb-5">
                    <h2 class="fw-bold">Keranjang</h2>
                    <div class="header-divider"></div>

                    <tbody>

                        <?php

                            $con = mysqli_connect("localhost","root","","waju");

                            if (!$con) {
                                die("Koneksi gagal: " . mysqli_connect_error());}
                                
                            // Ambil nama_baju dari URL
                            if ($_SESSION['nama_pengguna']) {
                                $Keranjang_pengguna = $_SESSION['nama_pengguna'];

                                $query = "SELECT * FROM `$Keranjang_pengguna` ORDER BY id DESC"; // Menggunakan nama_baju
                                $result = mysqli_query($con, $query);

                                // Cek apakah query berhasil
                                if (!$result) {
                                    die("Query gagal: " . mysqli_error($con));
                                }
                    
                                if (mysqli_num_rows($result) > 0) {
                                    
                                    foreach($result as $keranjang)
                                    {
                                    ?>
                                    
                                        <!-- Item Produk Keranjang -->

                                        <div class="card bg-body rounded-3 shadow mb-3">

                                            <div class="card-body py-4 d-flex align-items-center justify-content-start">

                                                <div class="col-md row px-3">

                                                    <div class="col-md-2 d-flex align-items-center my-1">
                                                        <a href="../halaman_katalog/halaman_katalog.php?tombol_baju=<?= $keranjang['nama_baju']; ?>">
                                                            <img alt="<?= $keranjang['nama_baju'] ?>" class="rounded-3 shadow-lg border-1" src="<?= $keranjang['foto_baju'] ?>" style="
                                                                width: 125px;
                                                                height: auto;
                                                                object-fit: cover;
                                                            ">
                                                        </a>

                                                    </div>

                                                    <div class="col-md-10 row">

                                                        <div class="col-md-9 d-flex flex-column justify-content-start align-items-start px-4">
                                                            <a href="../halaman_katalog/halaman_katalog.php?tombol_baju=<?= $keranjang['nama_baju']; ?>" style="text-decoration: none;" class="text-dark">
                                                                <p class="fs-5 fw-bolder">
                                                                    <?= $keranjang['nama_baju'] ?>
                                                                </p>
                                                            </a>
                                                            <p class="fs-6 fw-bold bg-info p-1 px-2 rounded bg-gradient shadow-sm border-1">
                                                                Rp. <?= $keranjang['harga_baju'] ?>
                                                            </p>
                                                            <p class="fs-6">
                                                                Ukuran : <span class="rounded bg-gradient shadow-sm border-1 fw-bold bg-primary text-white p-1 px-2"> <?= $keranjang['ukuran_baju'] ?></span> 
                                                            </p>

                                                            <?php
                                                            // Koneksi ke database
                                                            $con = mysqli_connect("localhost", "root", "", "waju");
    
                                                            // Cek koneksi
                                                            if (!$con) {
                                                                die("Koneksi gagal: " . mysqli_connect_error());
                                                            }
    
                                                            if (isset($keranjang['id_databaju'])) {
    
                                                                $id_data_baju = $keranjang['id_databaju'];
    
                                                                $sql_kueri = " SELECT * FROM databaju WHERE id = '$id_data_baju'";
                                                                $hasil = mysqli_query($con, $sql_kueri);
    
                                                                // Cek apakah query berhasil
                                                                if (!$hasil) {
                                                                    die("Query gagal: " . mysqli_error($con));
                                                                }
    
                                                                $databaju = mysqli_fetch_assoc($hasil);
                                                            } 
                                                            else {
                                                                echo "<p>Produk tidak ditemukan.</p>";
                                                                exit();
                                                            }
                                                            ?>
                                                            <?php
                                                            // Mengambil data dari $keranjang
                                                            $tanggal_sewa = $keranjang['tanggal_sewa'];
                                                            $bulan_sewa = $keranjang['bulan_sewa'];
                                                            $tahun_sewa = $keranjang['tahun_sewa'];

                                                            // Membuat string tanggal
                                                            $tanggal_string = "$tanggal_sewa $bulan_sewa $tahun_sewa";

                                                            // Membuat objek DateTime untuk tanggal penyewaan
                                                            $tanggal_sewa_obj = DateTime::createFromFormat('d F Y', $tanggal_string);
                                                            $tanggal_sekarang_obj = new DateTime(); // Tanggal saat ini

                                                            // Menentukan kelas CSS berdasarkan perbandingan tanggal
                                                            $menentukan_tanggal_sewa = ($tanggal_sewa_obj >= $tanggal_sekarang_obj) ? "bg-info" : "bg-danger";

                                                            if ($tanggal_sewa_obj >= $tanggal_sekarang_obj) {
                                                                echo "<style> .info_tidak_tersedia { display: none; } </style>";
                                                            }

                                                            // Inisialisasi variabel
                                                            $keterangan_tersedia = "";
                                                            $ukuran = "";
                                                            $warna_tersedia = ""; // Variabel untuk warna ketersediaan
                                                            $status_tersedia_baju = 0; // Inisialisasi status ketersediaan baju

                                                            // Cek ukuran yang dipilih
                                                            if ($keranjang['ukuran_s'] == 1) {
                                                                $ukuran = 's';
                                                            } elseif ($keranjang['ukuran_m'] == 1) {
                                                                $ukuran = 'm';
                                                            } elseif ($keranjang['ukuran_l'] == 1) {
                                                                $ukuran = 'l';
                                                            }

                                                            // Ambil jumlah baju yang tersedia berdasarkan ukuran dan tanggal sewa
                                                            if ($ukuran) {
                                                                // Menghilangkan spasi dari tanggal_sewa dan ukuran
                                                                $tanggal_sewa = trim($tanggal_sewa); // Menghapus spasi di awal dan akhir
                                                                $ukuran = str_replace(' ', '', $ukuran); // Menghapus semua spasi
                                                            
                                                                // Membuat nama kolom tanpa spasi
                                                                $kolom = 'tanggal_' . $tanggal_sewa . '_' . $ukuran;
                                                            
                                                                // Ambil jumlah baju dari array $databaju
                                                                $jumlah_baju = $databaju[$kolom];
                                                            
                                                                // Cek ketersediaan baju
                                                                if ($jumlah_baju < 1) {
                                                                    $warna_tersedia = "bg-danger";
                                                                    $keterangan_tersedia = "Habis";
                                                                } else {
                                                                    // Jika baju tersedia, cek tanggal sewa
                                                                    if ($menentukan_tanggal_sewa == "bg-danger") {
                                                                        $keterangan_tersedia = "Tidak dapat disewa";
                                                                        $warna_tersedia = "bg-danger";
                                                                    } else {
                                                                        $keterangan_tersedia = "Tersedia";
                                                                        $warna_tersedia = "bg-info";
                                                                        $status_tersedia_baju = 1; // Set status tersedia baju menjadi 1
                                                                    }
                                                                }
                                                            } else {
                                                                echo "<p>Ukuran tidak dipilih.</p>";
                                                            }
                                                            ?>

                                                            <p class="fs-6">
                                                                Tanggal Penyewaan : 
                                                                <span class="rounded bg-gradient shadow-sm border-1 fw-bold <?= $menentukan_tanggal_sewa ?> text-white p-1 px-2">
                                                                    <?= $tanggal_string ?>
                                                                </span> 
                                                            </p>

                                                        </div>

                                                        <div class="col-md-3">

                                                        <p class="fs-6 rounded bg-gradient shadow-sm border-1 fw-bold p-1 px-2 d-flex text-white justify-content-center text-center <?= $warna_tersedia ?> align-items-center"> 

                                                        <?= $keterangan_tersedia ?>

                                                        </p>

                                                        <form class="d-flex justify-content-end mb-3" method="post" action="../mysql_database/hapus_keranjang.php">

                                                            <input type="hidden" name="id" value="<?= $keranjang['id']; ?>">
                                                            <input type="hidden" name="nama_pengguna" value="<?php echo $_SESSION['nama_pengguna']; ?>">
                                                            <button type="submit" name="hapus" class="btn btn-outline-danger fw-medium shadow-sm">
                                                                Hapus
                                                            </button>

                                                        </form>

                                                        <style>

                                                            .sewa {
                                                                transition: 0.3s;
                                                            }

                                                            .sewa:hover{transform: scale(1.1);}

                                                        </style>

                                                        <form class="d-flex justify-content-end" method="post" action="../halaman_pembayaran/halaman_pembayaran.php">

                                                            <input type="hidden" name="id_databaju" value="<?= $keranjang['id_databaju']; ?>">

                                                            <input type="hidden" name="id_toko" value="<?= $keranjang['id_toko']; ?>">

                                                            <input type="hidden" name="id_keranjang" value="<?= $keranjang['id']; ?>">

                                                            <button type="submit" class="sewa btn fw-bold text-white shadow-sm align-items-end" style=" <?php if($status_tersedia_baju == 0){echo "display: none;";} ?> border: 1px solid #ffeaea; background: rgb(16,181,212); background: linear-gradient(90deg, rgba(16,181,212,1) 0%, rgba(110,227,202,1) 100%);">
                                                                Sewa
                                                            </button>

                                                        </form>

                                                        </div>

                                                    </div>                

                                                </div>

                                            </div>

                                        </div>
                                    
                                    <?php
                                    }
                    
                                } else {
                                    echo "<p>Keranjang Kamu Kosong Cuy, Yok Liat-Liat Baju Yang Keren.</p>";
                                    echo "<style> footer{display: none !important;} </style>";
                                    echo "<style> .info_tidak_tersedia {display: none;} </style>";
                                }
                            } else {
                                echo "<p>Nama pengguna tidak diberikan.</p>";
                                exit();
                            }

                        ?>

                        </tbody>
                        
                </div>



            </div>

        </div>

    </div>    
    
    <div class="alert alert-info info_tidak_tersedia">
        <div class="container">
            <div class="alert-icon">
                <i class="material-icons">info_outline</i>
            </div>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true"><i class="material-icons">clear</i></span>
            </button>
            <div style="padding-bottom: 10px"><b>Tidak dapat disewa</b> : berarti tanggal penyewaan melewati atau bertepatan hari ini.</div>
        </div>
    </div>

    </div> <!-- div padding -->

    <script src="https://unpkg.com/bootstrap-material-design@4.1.1/dist/js/bootstrap-material-design.js" integrity="sha384-CauSuKpEqAFajSpkdjv3z9t8E7RlpJ1UP0lKM/+NdtSarroVKu069AlsRPKkFBz9" crossorigin="anonymous"></script>

    <script src="..\bootstrap\js\bootstrap.min.js"></script>

    <script>

        $(document).ready(function() {
            $('body').bootstrapMaterialDesign();
        });

    </script>

        <!-- PHP Akhir -->

        <!-- PHP User -->

        <?php 
        
        }
        
        else{
            header("Location: ../halaman_utama/halaman_utama.html");
            exit();
        }

        ?>


        <link rel="stylesheet" href="..\footer\footer.css">

            <?php 

                // Koneksi ke database
                $con = mysqli_connect("localhost", "root", "", "waju");

                // Cek koneksi
                if (!$con) {
                    die("Koneksi gagal: " . mysqli_connect_error());
                }

                $query = "SELECT * FROM footer"; // Menggunakan nama_baju
                $result = mysqli_query($con, $query);

                $footer = mysqli_fetch_assoc($result);
                
                echo $footer['footer'];


            ?>

    </body>

</html>