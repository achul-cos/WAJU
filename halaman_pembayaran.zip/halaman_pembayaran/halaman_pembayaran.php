<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pembayaran</title>
    <link crossorigin="anonymous" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" rel="stylesheet"/>
  
    <!-- Custom Font "Poppins" -->

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Material+Icons">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0&icon_names=check"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"></link>

    <!-- Menggunakan Bootstrap CSS dari file lokal -->
    <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    
    <script>
        function pindahHalaman() {
            window.location.href = '../halaman_nota/halaman_nota.php';
        }
    </script>

    <!-- Logo Tab -->

    <link rel="icon" type="image/x-icon" href="../img/icon/logo_atas.svg">

    <!-- PHP AWal -->

        <?php

        session_start();

        if (isset($_SESSION['id']) && 
            isset($_SESSION['nama_pengguna']) &&
            isset($_SESSION['foto_pengguna'])) {

            $con = mysqli_connect("localhost", "root", "", "waju");

            // Cek koneksi
            if (!$con) {
                die("Koneksi gagal: " . mysqli_connect_error());
            }
            
        ?>

    <!-- PHP AWal -->

  </head>

  <body>
  
    <!-- Internal CSS -->
  
        <style>

            /* Reset standar untuk semua elemen */
        
                * {
                    margin: 0;
                    padding: 0;
                    box-sizing: border-box;
                    font-family: "Poppins", sans-serif;
                }
                /* Gaya background halaman */
                body {
                    background: rgb(217,233,233);
                    background: radial-gradient(circle, rgba(217,233,233,1) 3%, rgba(224,237,227,1) 100%);
                }
        
            /* CSS : Navagation Bar */

                .navbar {
                background-image: url(../img/icon/navbar.png);
                background-size: cover;
                border-bottom-left-radius: 20em 28em;
                border-bottom-right-radius: 20em 28em;
                height: 80px;
                }

                .navbar-brand {
                display: flex;
                justify-content: center;
                padding: 0px 0px 0% 0px !important;
                margin: 0px 5px 0px 0px !important;
                transition: 0.5s;
                }

                .navbar-brand:hover {
                filter:invert(100%) !important;
                opacity: 0.7;
                }

                .tombol_pencarian {
                display: block;
                width: 50px;
                height: auto;
                margin: 0 0 0 0; /* Menggabungkan margin */
                border: 1px solid rgba(14, 89, 129, 0.178);
                border-radius: 20px;
                box-shadow: 0 0 20px rgba(0, 0, 0, 0.05); 
                background: rgb(166, 214, 239) url(../img/icon/icon_cari.svg) no-repeat center / 25% !important; /* Menggabungkan properti background */
                transition: 0.1s;
                }

                .tombol_pencarian:hover{
                border: none !important;
                filter:invert(20%) !important;
                }

                .tombol_pencarian:active{
                background-size: 50% !important;
                }

                .bar_pencarian {
                color: rgba(91, 91, 91, 0.57);            
                border: 1px solid rgba(14, 89, 129, 0.178);
                border-radius: 20px;
                box-shadow: 0 0 20px rgba(0, 0, 0, 0.05); 
                text-indent: 12px;
                letter-spacing: 1px;
                transition: 0.3s;
                }

                .bar_pencarian input:focus,
                .bar_pencarian input:hover {
                color: #00282b;
                border: 1.5px solid #00282b;
                }

                .base_keranjang, .keranjang {
                margin: auto;
                width: 30px ;
                height: 30px ;
                display: block;
                transition: 0.3s;
                transition: 0.3s;
                justify-content: center; /* Mengatur konten secara horizontal ke tengah */
                align-items: center; /* Mengatur konten secara vertikal ke tengah */
                }

                .keranjang:hover {
                transform: scale(1.2);
                }

                .keranjang:active {
                animation: beat 0.3s alternate;
                transform-origin: center;
                } 

                @keyframes beat{
                to { transform: scale(1.4); }
                }

                .base_username {
                margin: auto;
                width: auto;
                display: inline-flex; /* Menggunakan inline-flex untuk menyesuaikan lebar dengan konten */
                justify-content: center; /* Mengatur konten secara horizontal ke tengah */
                align-items: center; /* Mengatur konten secara vertikal ke tengah */
                border: 1.5px solid #f2f2f2;
                border-radius: 25px;
                color: #ffffff;
                font-family: "Poppins", sans-serif;
                letter-spacing: 1px;
                padding: 5px 12px; /* Padding untuk memberikan ruang di sekitar teks */
                font-weight: 600;
                text-decoration: none;
                transition: 0.3s; /* Hanya perlu ditulis sekali */
                }

                .tulisan {
                overflow: hidden; /* Sembunyikan teks yang melampaui batas */
                white-space: nowrap !important; /* Mencegah teks membungkus ke baris baru */
                text-overflow: ellipsis !important; /* Tambahkan ellipsis (...) */
                max-width: calc(8vw) !important; 
                width: auto;
                text-align: center !important;  
                }

                .base_username:hover {
                background-color: #f2f2f2;
                color: rgb(39, 74, 94);
                }
                
                .base_profil, .profil {
                margin: auto;
                width: auto ;
                height: 30px ;
                display: flex;
                z-index: 110;
                transition: 0.3s;
                padding-right: 30;
                transition: 0.3s;
                right: 0;   
                }
                
                .profil:hover {
                transform: scale(1.2);
                }

                .profil:active {
                animation: beat 0.3s alternate;
                transform-origin: center;
                } 

                .container-fluid {
                max-width: 95% !important;
                }

                @media (max-width: 615px) {
                    .kolom_keranjang {
                        display: none !important;
                    }
                }

                @media (max-width: 500px) {
                    .kolom_nama {
                        display: none !important;
                    }
                }

                @media (max-width: 400px) {
                    .kolom_profil {
                        display: none !important;
                    }
                }

            /* CSS : Navagation Bar Selesai */
            /* CSS : Isi Website */

                /* Setel ukuran font dan penataan teks untuk header */
                .header {
                    font-size: 20px;
                    font-weight: bold;
                    margin: 10px 0;
                    text-align: center;
                }
                /* Menambahkan padding, margin, dan bayangan untuk setiap bagian */
                .section {
                    padding: 20px;
                    margin: 30px auto;
                    background-color: transparent;
                    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
                    border-radius: 10px;
                    max-width: 1000px; 
                    width: 100%; 
                }
                /* Setel gaya untuk header pada setiap section */
                .section-header {
                    font-size: 16px;
                    font-weight: bold;
                    display: flex;
                    align-items: center;
                    background-color: transparent;
                    padding: 10px;
                    border-radius: 10px;
                    box-shadow: 0 4px 4px rgba(0, 0, 0, 0.3);
                }
                /* Menambah padding untuk isi section */
                .section-body {
                    padding: 5px 0;
                }
                /* Mengatur ukuran ikon */
                .icon {
                    font-size: 20px;
                    margin-right: 5px;
                }
                /* Menghilangkan border atas di tabel */
                .table th, .table td {
                    border-top: none;
                }
                /* Gaya untuk tombol khusus */
                .btn-custom {
                    background-color: rgb(111, 158, 172);
                    color: rgb(235, 229, 229);
                    border-radius: 5px;
                    padding: 5px 10px;
                    font-size: 14px;
                }
                /* Mengatur gambar agar responsif */
                .img-fluid {
                    max-width: 80px;
                    height: auto;
                }
                /* Menetapkan lebar untuk input jumlah produk */
                .product-quantity {
                    width: 50px;
                }
                /* Menambahkan margin atas untuk header tabel */
                .table-header {
                    font-weight: bold;
                    margin-top: 10px;
                }
                /* Menetapkan gaya untuk card */
                .card {
                    background-color: transparent;
                    border: none;
                }
                /* Gaya untuk header card */
                .card-header {
                    background-color: #ffffff;
                    border-radius: 10px;
                    font-weight: bold;
                }
                /* Gaya untuk body card */
                .card-body {
                    background-color: transparent;
                }

            /* CSS : Isi Website Selesai */

            /* Input telepon */

            .input-telepon {
                /* Anda bisa menambahkan gaya untuk .input-telepon di sini jika diperlukan */
            }

            .input-telepon .select-box {
                position: relative;
            }

            .input-telepon .select-box input {
                width: 100%;
                padding: 1rem .6rem;
                font-size: 1.1rem;
                
                border: 0.5px solid rgba(0, 0, 0, 0 .4);
                outline: none;
            }

            .input-telepon input[type="tel"] {
                border-radius: 0 .5rem .5rem 0;
            }

            .input-telepon .select-box input:focus {
                border: .1rem solid var(--primary);
            }

            .input-telepon .selected-option {
                background-color: #eee;
                border-radius: .5rem;
                overflow: hidden;

                display: flex;
                justify-content: space-between;
                align-items: center;
            }

            .input-telepon .selected-option div {
                position: relative;

                width: 6rem;
                padding: 0 2.8rem 0 .5rem;
                text-align: center;
                cursor: pointer;
            }

            .input-telepon .selected-option div::after {
                position: absolute;
                content: "";
                right: .8rem;
                top: 50%;
                transform: translateY(-50%) rotate(45deg);
                
                width: .8rem;
                height: .8rem;
                border-right: .12rem solid var(--primary);
                border-bottom: .12rem solid var(--primary);

                transition: .2s;
            }

            .input-telepon .selected-option div.active::after {
                transform: translateY(-50%) rotate(225deg);
            }

            .input-telepon .select-box .options {
                position: absolute;
                top: 4rem;
                
                width: 100%;
                background-color: #fff;
                border-radius: .5rem;

                display: none;
            }

            .input-telepon .select-box .options.active {
                display: block;
                z-index: 100;
            }

            .input-telepon .select-box .options::before {
                position: absolute;
                content: "";
                left: 1rem;
                top: -1.2rem;
                display: none;
                width: 0;
                height: 0;
                border: .6rem solid transparent;
                border-bottom-color: var(--primary);
            }

            .input-telepon input.search-box {
                background: rgb(16,181,212); 
                background: linear-gradient(90deg, rgba(16,181,212,1) 0%, rgba(110,227,202,1) 100%);
                color: #eee;
                border-radius: .5rem .5rem 0 0;
                padding: 1.4rem 1rem;
                border: none;
                font-weight: bold;
            }

            .input-telepon input.search-box::placeholder {
                color : #eee;
                opacity: 70%;
            }

            .input-telepon .select-box ol {
                list-style: none;
                max-height: 23rem;
                overflow: overlay;
            }

            .input-telepon .select-box ol::-webkit-scrollbar {
                width: 0.6rem;
            }

            .input-telepon .select-box ol::-webkit-scrollbar-thumb {
                width: 0.4rem;
                height: 3rem;
                background-color: #ccc;
                border-radius: .4rem;
            }

            .input-telepon .select-box ol li {
                padding: 1rem;
                display: flex;
                justify-content: space-between;
                cursor: pointer;
            }

            .input-telepon .select-box ol li.hide {
                display: none;
            }

            .input-telepon .select-box ol li:not(:last-child) {
                border-bottom: .1rem solid #eee;
            }

            .input-telepon .select-box ol li:hover {
                background-color: lightcyan;
            }

            .input-telepon .select-box ol li .country-name {
                margin-left: .4rem;
            }

            /* Css Input Telepon Selesai */

        </style>

    <!-- Internal CSS Selesai -->

    <!-- Navagation Bar -->

        <nav class="navbar navbar-expand-lg">

        <div class="container-fluid">

        <div class="col-auto d-flex justify-content-start kolom_logo">
            <a class="navbar-brand" href="../halaman_beranda/halaman_beranda.php">
                <img src="../img/icon/logo2.png" alt="logo" width="auto" height="auto">
            </a>
        </div>


        <div class="col-auto d-flex justify-content-end kolom_konten">

            <div class="col-md-auto d-flex kolom_keranjang d-flex px-0 mr-5 justify-content-end">
                <!-- Logo Keranjang -->

                <td>
                    <form action="../halaman_keranjang/halaman_keranjang.php" method="post" name="tombol_keranjang">
                        <button style="border: none; background: transparent;" class="base_keranjang" type="submit">
                            <img src="..\img\icon\icon_keranjang.svg" alt="keranjang" class="keranjang">
                        </button>
                    </form>
                </td>

            </div>

            <div class="col-md-auto kolom_nama d-flex mr-5 justify-content-end">
                <!-- Nama Pengguna -->

                <td>
                    <a href="../halaman_list/list_sewa.php" class="base_username d-flex justify-content-end" id="username">
                        <div class="tulisan">
                            <?php echo $_SESSION['nama_pengguna'];  ?>
                        </div>
                    </a>
                </td>

            </div>

            <div class="col-auto d-flex kolom_profil px-0">
                <!-- Foto profil -->

                <td>
                    <a href="../halaman_list/list_sewa.php" class="base_profil">
                    <img src="<?php if($_SESSION['foto_pengguna'] == NULL) {echo "..\img\icon\profile.jpg";} else{echo $_SESSION['foto_pengguna'];}?>" style="transform: scale(1.3); aspect-ratio: 1/1; object-fit: cover;" alt="photo_profil" class="profil rounded-circle border border-success border-opacity-25 shadow">
                    </a>
                </td>
                <style>
                    .base_profil:hover, .profil:hover {
                        transform: scale(1.3);
                    }
                
                    @media (max-width: 400px) {
                        .kolom_konten {
                            display: none !important;
                        }
                        .kolom_logo {
                            justify-content: center !important;
                            margin: auto;
                        }
                    }
        
                </style>
            </div>
        </div>

        </div>

        </nav>

    <!-- Navagation Bar Selesai -->

    <!-- Isi Website -->

        <div class="isi" style="padding-bottom: 150px">
            
            <!-- Informasi Penyewa Section -->

                <div class="section">

                    <div class="section-header p-3 bg-primary-subtle">
                        <i class="bi bi-person-bounding-box icon me-3"></i>
                        Informasi Penyewa
                    </div>

                    <!-- PHP Data Akun Penyewa -->
                
                        <?php 
                        
                        $id = $_SESSION['id'];

                        $kueri_dataakun = "SELECT * FROM dataakun WHERE id = '$id'";
                        $hasil_kueri_dataakun = mysqli_query($con, $kueri_dataakun);
            
                        // Cek apakah query berhasil
                        if (!$hasil_kueri_dataakun) {
                          die("Query gagal: " . mysqli_error($con));
                        }
            
                        if (mysqli_num_rows($hasil_kueri_dataakun) > 0) {
                          $data_pengguna = mysqli_fetch_assoc($hasil_kueri_dataakun);
                        } else {
                          echo "<p>Data Tidak Ditemukan</p>";
                          exit();
                        }
                        
                        ?>

                    <!-- PHP Data Akun Penyewa Selesai -->

                    <form method="POST" action="../mysql_database/update_data_pengguna_khusus.php">
                        <input class="form-control" type=hidden name="id_pengguna" id="id_pengguna" type="text" value="<?= $_SESSION['id'] ?>"/>

                        <div class="section-body mt-3">

                            <div class="card">
                                <div class="card-body bg-light rounded shadow-sm border border-success border-opacity-25 p-3">
                                    <div class="container row">
                                        <div class="col-md-2">
                                            <p class="fs-5 fw-bold justify-content-start"> Nama</p>
                                        </div>
                                        <div class="col-md-auto p-0 d-flex">
                                            <p class="fs-5 fw-bold me-3">:</p>
                                        </div>
                                        <div class="col-md-6 p-0 m-0">
                                            <input class="form-control" type=hidden name="nama_pengguna" id="nama_pengguna" type="text" placeholder="Nama Anda..." style="font-style: italic;" value="<?= $data_pengguna['nama_pengguna'] ?>" autocapitalize="none" required/>
                                            <input class="form-control" disabled name="nama_pengguna" id="nama_pengguna" type="text" placeholder="Nama Anda..." style="font-style: italic;" value="<?= $data_pengguna['nama_pengguna'] ?>" autocapitalize="none" required/>
                                        </div>
                                    </div>

                                    <div class="container row mt-2">
                                        <div class="col-md-2">
                                            <p class="fs-5 fw-bold dflex justify-content-start"> Email</p>
                                        </div>
                                        <div class="col-md-auto p-0 d-flex">
                                            <p class="fs-5 fw-bold me-3">:</p>
                                        </div>
                                        <div class="col-md-6 p-0 m-0">
                                            <input class="form-control" type="hidden" name="email_pengguna" id="email" type="email" placeholder="Email Anda..." style="font-style: italic;" value="<?= $data_pengguna['email'] ?>" required/>
                                            <input class="form-control" disabled name="email_pengguna" id="email" type="email" placeholder="Email Anda..." style="font-style: italic;" value="<?= $data_pengguna['email'] ?>" required/>
                                        </div>
                                    </div>

                                    <div class="container row mt-2">
                                        <div class="col-md-2">
                                            <p class="fs-5 fw-bold d-flex justify-content-start"> Alamat</p>
                                        </div>
                                        <div class="col-md-auto p-0 d-flex">
                                            <p class="fs-5 fw-bold me-3">:</p>
                                        </div>
                                        <div class="col-md-6 p-0 m-0">
                                            <input class="form-control" name="alamat_pengguna" id="alamat" type="text" placeholder="Alamat Anda..." style="font-style: italic;" value="<?= $data_pengguna['alamat_pengguna'] ?>" required/>
                                        </div>
                                    </div>

                                    <div class="container row mt-2">
                                        <div class="col-md-2">
                                            <p class="fs-5 fw-bold d-flex justify-content-start"> NIK</p>
                                        </div>
                                        <div class="col-md-auto p-0 d-flex">
                                            <p class="fs-5 fw-bold me-3">:</p>
                                        </div>
                                        <div class="col-md-6 p-0 m-0">
                                            <input class="form-control" name="nik_pengguna" id="nik" type="text" minlength="16" maxlength="16" inputmode="numeric" placeholder="16-Digit NIK..." style="font-style: italic;" value="<?= $data_pengguna['nik_pengguna'] ?>" required />
                                        </div>
                                    </div>

                                    <div class="container row mt-2 d-flex align-items-center">
                                        <div class="col-md-2">
                                            <p class="fs-5 fw-bold d-flex justify-content-start align-items-center"> No. Telepon</p>
                                        </div>
                                        <div class="col-md-auto p-0 d-flex">
                                            <p class="fs-5 fw-bold me-3">:</p>
                                        </div>
                                        <div class="col-md-6 p-0 m-0 input-telepon">

                                            <!-- <input class="form-control" id="telepon" type="text" style="font-style: italic;" placeholder="Nomor Telepon Anda..." style="font-style: italic;" value="" required/> -->
                            
                                            <div class="select-box">
                                                <div class="selected-option">
                                                    <div class="d-flex align-items-center" style="width: 150px; gap: 5px;">
                                                        <span class="iconify" data-icon="flag:id-4x3"></span>
                                                        <strong>+62</strong>
                                                    </div>
                                                    <input class="shadow-lg" type="tel" inputmode="numeric" minlength="12" maxlength="17" onkeypress="return numbersonly(this, event)" name="nomor_telepon" placeholder="Nomor Telepon Anda.." value="<?php if ($data_pengguna['nomor_telepon'] == NULL) {echo "+62";} else {echo $data_pengguna['nomor_telepon'];}   ?>">
                                                </div>
                                                <div class="options">
                                                    <input type="text" class="search-box" placeholder="Kode Telepon Negara...">
                                                    <ol class="shadow-lg">

                                                    </ol>
                                                </div>
                                            </div>
                                            <script src="script.js"></script>
                                            <script src="https://code.iconify.design/3/3.1.0/iconify.min.js"></script>

                                        </div>
                                    
                                    </div>

                                    <div class="container d-flex alert alert-info mt-4">
                                        <div class="col-10 d-flex justify-content-start">
                                            <div class="col-auto alert-icon d-flex">
                                                <i class="material-icons">info_outline</i>
                                            </div>
                                            <div class="col-auto d-flex"><p><span class="fw-bold">Lengkapi Data Anda Terlebih Dahulu Sebelum Menyewa, </span>Dengan anda mengubah data anda di sini, Anda juga mengubah data akun anda juga.</p></div>
                                        </div>
                                        <div class="col-2 d-flex justify-content-end">
                                            <div class="col-2 d-flex justify-content-center">
                                            <button class="d-flex justify-content-end bg-transparent border-0" type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                <span aria-hidden="true"><i class="material-icons">clear</i></span>
                                            </button>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="container row mt-5 d-flex justify-content-start">
                                        <div class="col-md-2 m-0 p-0">
                                            <button type="submit" class="btn btn-success border border-succes border border-opacity-25 shadow text-white fw-bold">Simpan</button>
                                        </div>
                                    </div>

                                </div>
                            </div>

                        </div>

                    </form>
                    
                </div>

            <!-- Informasi Penyewa Section Selesai -->

            <!-- Informasi Toko/Pemilik Busana Section -->

                <div class="section">

                    <div class="section-header p-3 bg-primary-subtle">
                        <i class="bi bi-shop icon me-3"></i>
                        Informasi Toko 
                    </div>

                    <div class="section-body mt-3">

                        <!-- PHP Data Informasi Toko -->

                            <?php

                            $con = mysqli_connect("localhost", "root", "", "waju");

                            // Cek koneksi
                            if (!$con) {
                                die("Koneksi gagal: " . mysqli_connect_error());
                            }

                            if (isset($_POST['id_toko'])) {

                                $id_toko = $_POST['id_toko'];

                                $kueri_datatoko = "SELECT * FROM datatoko WHERE id = '$id_toko'";
                                $hasil_kueri_datatoko = mysqli_query($con, $kueri_datatoko);
                    
                                // Cek apakah query berhasil
                                if (!$hasil_kueri_datatoko) {
                                  die("Query gagal: " . mysqli_error($con));
                                }
                    
                                if (mysqli_num_rows($hasil_kueri_datatoko) > 0) {
                                  $data_toko = mysqli_fetch_assoc($hasil_kueri_datatoko);
                                } else {
                                  echo "<p>Data Tidak Ditemukan</p>";
                                  exit();
                                }
                            }


                            ?>

                        <!-- PHP Data Informasi Toko Selesai -->

                        <div class="card">
                            <div class="card-body bg-light rounded shadow-sm border border-success border-opacity-25 p-3">
                                <div class="container row mt-3">
                                    <div class="col-md-2">
                                        <p class="fs-5 fw-bold justify-content-start"> Nama</p>
                                    </div>
                                    <div class="col-md-auto p-0 d-flex">
                                        <p class="fs-5 fw-bold me-3">:</p>
                                    </div>
                                    <div class="col-md-6 p-0 m-0">
                                        <p class="fw-bold fs-5 bg-info bg-gradient rounded border border-succes border-opacity-50 shadow-sm text-white d-inline p-2"><?= $data_toko['nama_toko'] ?></p>
                                    </div>
                                </div>

                                <div class="container row mt-2">
                                    <div class="col-md-2">
                                        <p class="fs-5 fw-bold dflex justify-content-start"> Email</p>
                                    </div>
                                    <div class="col-md-auto p-0 d-flex">
                                        <p class="fs-5 fw-bold me-3">:</p>
                                    </div>
                                    <div class="col-md-6 p-0 m-0">
                                        <p class="fw-bold fs-5 bg-info bg-gradient rounded border border-succes border-opacity-50 shadow-sm text-white d-inline p-2"><?= $data_toko['email_toko'] ?></p>
                                    </div>
                                </div>

                                <div class="container row mt-2">
                                    <div class="col-md-2">
                                        <p class="fs-5 fw-bold d-flex justify-content-start"> Alamat</p>
                                    </div>
                                    <div class="col-md-auto p-0 d-flex">
                                        <p class="fs-5 fw-bold me-3">:</p>
                                    </div>
                                    <div class="col-md-6 p-0 m-0">
                                        <p class="fw-bold fs-5 bg-info bg-gradient rounded border border-succes border-opacity-50 shadow-sm text-white d-inline p-2"><?= $data_toko['alamat_toko'] ?></p>
                                    </div>
                                </div>

                                <div class="container row mt-2">
                                    <div class="col-md-2">
                                        <p class="fs-5 fw-bold d-flex justify-content-start"> Jam Buka</p>
                                    </div>
                                    <div class="col-md-auto p-0 d-flex">
                                        <p class="fs-5 fw-bold me-3">:</p>
                                    </div>
                                    <div class="col-md-6 p-0 m-0">
                                        <p class="fw-bold fs-5 bg-info bg-gradient rounded border border-succes border-opacity-50 shadow-sm text-white d-inline p-2"><?= $data_toko['jam_buka_display'] ?></p>
                                    </div>
                                </div>

                                <div class="container row mt-2">
                                    <div class="col-md-2">
                                        <p class="fs-5 fw-bold d-flex justify-content-start"> Jam Tutup</p>
                                    </div>
                                    <div class="col-md-auto p-0 d-flex">
                                        <p class="fs-5 fw-bold me-3">:</p>
                                    </div>
                                    <div class="col-md-6 p-0 m-0">
                                        <p class="fw-bold fs-5 bg-info bg-gradient rounded border border-succes border-opacity-50 shadow-sm text-white d-inline p-2"><?= $data_toko['jam_tutup_display'] ?></p>
                                    </div>
                                </div>

                                <div class="container row mt-2 d-flex align-items-center">
                                    <div class="col-md-2">
                                        <p class="fs-5 fw-bold d-flex justify-content-start align-items-center"> No. Telepon</p>
                                    </div>
                                    <div class="col-md-auto p-0 d-flex">
                                        <p class="fs-5 fw-bold me-3">:</p>
                                    </div>
                                    <div class="col-md-6 p-0 m-0 input-telepon">
                                        <p class="fw-bold fs-5 bg-info bg-gradient rounded border border-succes border-opacity-50 shadow-sm text-white d-inline p-2"><?= $data_toko['kontak_toko'] ?></p>
                                    </div>
                                
                                </div>

                                <div class="container d-flex alert alert-info mt-4">
                                    <div class="col-10 d-flex justify-content-start">
                                        <div class="col-auto alert-icon d-flex">
                                            <i class="material-icons">info_outline</i>
                                        </div>
                                        <div class="col-auto d-flex"><p>Dengan anda menyewa busana di toko ini anda menyetujui <a href="" class="link-underline-primary" data-bs-toggle="modal" data-bs-target="#modal_syarat">syarat & ketentuan berlaku.</a> <span class="fw-bold">Pelanggaran dapat mengakibatkan denda.</span></p></div>
                                    </div>
                                    <div class="col-2 d-flex justify-content-end">
                                        <div class="col-2 d-flex justify-content-center">
                                        <button class="d-flex justify-content-end bg-transparent border-0" type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true"><i class="material-icons">clear</i></span>
                                        </button>
                                        </div>
                                    </div>
                                </div>

                                <div class="container row mt-5 d-flex justify-content-start">
                                    <div class="col-md-2 m-0 p-0">
                                        <a href="https://api.whatsapp.com/send?phone=<?php echo $data_toko['kontak_toko']; ?>&text=Halo WAJU Lovers! Saya Ingin Bertanya." target="_blank" class="btn btn-success border border-succes border border-opacity-25 shadow text-white fw-bold">Chat Toko</a>
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>
                    
                </div>

            <!-- Informasi Penyewa Section Selesai -->

            <!-- Modal Syarat Ketentuan -->

                <!-- Modal -->

                <div class="modal fade" id="modal_syarat" tabindex="-1" aria-labelledby="modal_syaratLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">Syarat dan Ketentuan</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <h1>Syarat dan Ketentuan Penyewaan Busana</h1>
                            <p>Selamat datang di layanan penyewaan busana kami. Mohon baca dan pahami Syarat dan Ketentuan berikut sebelum menggunakan layanan ini. Dengan menyewa busana dari kami, Anda dianggap telah menyetujui semua poin di bawah ini.</p>
                            
                            <h2>1. Ketentuan Umum</h2>
                            <ol>
                                <li>Setiap penyewa wajib memberikan data diri yang valid dan dapat dipertanggungjawabkan saat melakukan pemesanan.</li>
                                <li>Penyewaan hanya dapat dilakukan melalui platform resmi kami.</li>
                                <li>Busana yang disewa hanya untuk keperluan pribadi, bukan untuk dijual kembali atau disewakan ulang.</li>
                            </ol>

                            <h2>2. Kewajiban Penyewa</h2>
                            <ol>
                                <li>Penyewa wajib mengembalikan busana sesuai dengan jadwal pengembalian yang telah disepakati.</li>
                                <li>Busana harus dikembalikan dalam kondisi bersih, rapi, dan tanpa kerusakan melebihi pemakaian wajar.</li>
                                <li>Penyewa bertanggung jawab penuh atas keamanan dan keutuhan busana selama masa penyewaan.</li>
                            </ol>

                            <h2>3. Larangan</h2>
                            <ol>
                                <li>Dilarang memodifikasi, mengubah, atau merusak busana dalam bentuk apa pun.</li>
                                <li>Dilarang meminjamkan busana kepada pihak lain yang tidak terdaftar sebagai penyewa.</li>
                                <li>Dilarang menggunakan busana untuk aktivitas yang dapat merusak atau menodai busana secara permanen.</li>
                            </ol>

                            <h2>4. Denda dan Sanksi</h2>
                            <p>Jika terjadi pelanggaran terhadap ketentuan di atas, penyewa akan dikenakan denda atau sanksi berikut:</p>
                            <ul>
                                <li><strong>Keterlambatan Pengembalian:</strong> Rp10.000 per hari keterlambatan.</li>
                                <li><strong>Kondisi Busana Tidak Layak:</strong> Biaya pembersihan khusus sebesar Rp50.000.</li>
                                <li><strong>Kerusakan Busana:</strong> Denda hingga sebesar harga busana atau biaya perbaikan yang ditentukan oleh penyedia layanan.</li>
                                <li><strong>Pelanggaran Berat:</strong> Jika busana hilang atau sengaja dirusak, penyewa wajib mengganti sebesar harga busana yang berlaku.</li>
                            </ul>

                            <h2>5. Pembatalan dan Pengembalian Dana</h2>
                            <ol>
                                <li>Permintaan pembatalan harus dilakukan maksimal 24 jam sebelum waktu pengambilan.</li>
                                <li>Pengembalian dana tidak berlaku untuk pembatalan mendadak di hari pengambilan.</li>
                            </ol>

                            <h2>6. Ketentuan Lain-lain</h2>
                            <ol>
                                <li>Penyedia layanan tidak bertanggung jawab atas kerugian atau kecelakaan yang terjadi selama penyewa menggunakan busana.</li>
                                <li>Busana yang tidak dikembalikan dalam waktu 30 hari sejak tanggal pengembalian akan dianggap hilang, dan penyewa diwajibkan mengganti sesuai nilai busana tersebut.</li>
                            </ol>

                            <p>Dengan menyewa busana dari kami, Anda menyatakan telah memahami dan menerima semua poin dalam Syarat dan Ketentuan ini. Terima kasih atas kepercayaan Anda menggunakan layanan kami!</p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                        </div>
                        </div>
                    </div>
                </div>

            <!-- Modal Syarat Ketentuan Selesai -->

            <!-- Informasi Produk Section -->

                <div class="section">

                    <div class="section-header p-3 bg-primary-subtle">
                        <i class="fa-duotone fa-solid fa-shirt icon me-3"></i>
                        Informasi Produk 
                    </div>

                    <div class="section-body mt-3">

                        <!-- PHP Data Informasi Busana -->

                            <?php

                            $con = mysqli_connect("localhost", "root", "", "waju");

                            // Cek koneksi
                            if (!$con) {
                                die("Koneksi gagal: " . mysqli_connect_error());
                            }

                            if (isset($_POST['id_databaju'])) {

                                $id_databaju = $_POST['id_databaju'];

                                $kueri_databaju = "SELECT * FROM databaju WHERE id = '$id_databaju'";
                                $hasil_kueri_databaju = mysqli_query($con, $kueri_databaju);
                    
                                // Cek apakah query berhasil
                                if (!$hasil_kueri_databaju) {
                                  die("Query gagal: " . mysqli_error($con));
                                }
                    
                                if (mysqli_num_rows($hasil_kueri_databaju) > 0) {
                                  $data_baju = mysqli_fetch_assoc($hasil_kueri_databaju);
                                } else {
                                  echo "<p>Data Tidak Ditemukan</p>";
                                  exit();
                                }

                                if (isset($_POST['id_keranjang'])) {

                                    $id_keranjang = $_POST['id_keranjang'];

                                    $nama = $data_pengguna['nama_pengguna'];
    
                                    $kueri_databaju_khusus = "SELECT * FROM `$nama` WHERE id = '$id_keranjang'";
                                    $hasil_kueri_databaju_khusus = mysqli_query($con, $kueri_databaju_khusus);
                        
                                    // Cek apakah query berhasil
                                    if (!$hasil_kueri_databaju_khusus) {
                                      die("Query gagal: " . mysqli_error($con));
                                    }
                        
                                    if (mysqli_num_rows($hasil_kueri_databaju_khusus) > 0) {
                                      $data_baju_khusus = mysqli_fetch_assoc($hasil_kueri_databaju_khusus);
                                    } else {
                                      echo "<p>Data Tidak Ditemukan</p>";
                                      exit();
                                    }
                                }
                                }


                            ?>

                        <!-- PHP Data Informasi Busana Selesai -->

                        <div class="card">
                            <div class="card-body bg-light rounded shadow-sm border border-success border-opacity-25 p-3">
                                <div class="container row mt-3">

                                    <div class="col-md-3 d-flex">

                                        <img src="<?php if($data_baju['foto_baju'] == NULL) {echo "../img/icon/preview_img.svg";} else{echo $data_baju['foto_baju'];}?>" alt="Busana" class="rounded-3 shadow border border-succes border-opacity-25" style="
                                            width: 100%;
                                            height: auto;
                                            aspect-ratio: 3/4;
                                            object-fit: cover;
                                            background-repeat: no-repeat;
                                        "/>

                                    </div>

                                    <div class="col-md-9 row d-flex justify-content-start" style="align-content: flex-start;">

                                        <div class="row d-flex flex-nowrap align-items-center justify-content-start">

                                            <p class=" fs-5 mt-2 p-0 me-0"><span class="bg-info fw-bold bg-gradient p-2 m-0 rounded shadow-sm text-white"><?= $data_baju['nama_baju'] ?></span>
                                        
                                            <span class="fw-light mx-2">
                                            |
                                            </span>

                                            <span class="text-body-secondary">
                                            <?= $data_baju['kategori_baju'] ?>
                                            </span>

                                            </p>

                                        </div>

                                        <div class="flex-nowrap justify-content-start d-flex mt-3 align-items-center text-center p-0">

                                            <span class="rounded bg-success shadow-sm text-white flex-norwrap d-flex align-items-center text-center p-1 px-2 ms-n2">

                                            <i class="fa-sharp-duotone fa-solid fa-rupiah-sign"></i>

                                            <p class="fw-bold fs-5 text-center ms-1 m-auto"><?= $data_baju['harga_baju'] ?></p>

                                            <p class="fs-6 fw fs-5 ms-1 m-auto">/ hari</p>
                                            
                                            </span>

                                        </div>

                                        <div class="flex-nowrap justify-content-start d-flex align-items-center mt-3 p-0 text-center">
                                            
                                            <p>Tanggal Penyewaan :</p>

                                            <p class="fs-6 ms-2 flex-nowrap row d-flex justify-content-start">
                                            
                                            <span class="rounded bg-success shadow-sm text-white flex-norwrap d-flex align-items-center text-center p-1 px-2">

                                                <?= $data_baju_khusus['tanggal_sewa'] ?> <?= $data_baju_khusus['bulan_sewa'] ?> <?= $data_baju_khusus['tahun_sewa'] ?>

                                            </span>
                                            
                                            </p>

                                        </div>

                                        <div class="flex-nowrap justify-content-start d-flex align-items-center p-0 text-center">
                                            
                                            <p>Ukuran :</p>

                                            <p class="fs-6 ms-2 flex-nowrap row d-flex justify-content-start">
                                            
                                            <span class="rounded bg-success shadow-sm text-white flex-norwrap d-flex align-items-center text-center p-1 px-2">

                                                <?= $data_baju_khusus['ukuran_baju'] ?>

                                            </span>
                                            
                                            </p>

                                        </div>

                                        <div class="flex-nowrap justify-content-start d-flex align-items-center p-0 text-center">
                                            
                                            <p class="me-2">Jumlah Hari Penyewaan :</p>

                                            <form method="post" action="../nota/export.php">

                                            <input type="radio" onclick="hideShowDiv(1)" class="btn-check" name="options" value="1" id="option1" autocomplete="off">
                                            <label class="btn btn-outline-success me-2" for="option1">1 Hari</label>

                                            <input type="radio" onclick="hideShowDiv(2)" class="btn-check" name="options" value="2" id="option2" autocomplete="off">
                                            <label class="btn btn-outline-success me-2" for="option2">2 Hari</label>

                                            <input type="radio" onclick="hideShowDiv(3)" class="btn-check" name="options" value="3" id="option3" autocomplete="off">
                                            <label class="btn btn-outline-success" for="option3">3 Hari</label>                                        

                                        </div>

                                    </div>

                                </div>
                            </div>
                        </div>

                    </div>
                    
                </div>

            <!-- Informasi Penyewa Section Selesai -->        

            <!-- Produk Dipesan Section -->

                <div class="section">

                    <div class="section-header p-3 bg-primary-subtle">
                        <i class="fa-solid fa-rupiah-sign icon me-3"></i>
                        Informasi Pembayaran
                    </div>

                    <div class="section-body mt-3">

                        <!-- PHP Data Informasi Busana -->

                            <?php

                            $con = mysqli_connect("localhost", "root", "", "waju");

                            // Cek koneksi
                            if (!$con) {
                                die("Koneksi gagal: " . mysqli_connect_error());
                            }

                            ?>

                        <!-- PHP Data Informasi Busana Selesai -->

                        <div class="card">
                            <div class="card-body bg-light rounded shadow-sm border border-success border-opacity-25 p-3" style="background-image: url(../img/foto/nota.png); object-fit: cover; background-size: cover; background-position: center;">
                                <div class="container row mt-3">

                                    <img src="../img/icon/logo2.png" class="mb-3 m-auto" alt="logo" style="filter: brightness(0) saturate(100%) invert(59%) sepia(0%) saturate(52%) hue-rotate(245deg) brightness(101%) contrast(91%); width: 250px; height: auto; opacity: 0.5;">

                                    <div class="row">

                                        <div class="col">
                                            <p class="text-start font-monospace fs-6 fst-italic">Nama Penyewa : <?= $data_pengguna['nama_pengguna'] ?></p>
                                        </div>

                                        <?php
                                            $tanggal_pemesanan = '';

                                            date_default_timezone_set('Asia/Jakarta');

                                            $hariIndo = array(
                                                "Sunday" => "Minggu",
                                                "Monday" => "Senin",
                                                "Tuesday" => "Selasa",
                                                "Wednesday" => "Rabu",
                                                "Thursday" => "Kamis",
                                                "Friday" => "Jumat",
                                                "Saturday" => "Sabtu"
                                            );

                                            $hari_bing = date('l');

                                            $hari_indo = $hariIndo[$hari_bing];

                                            $tanggal_pemesanan = $hari_indo . ", " . date('d-m-Y');
                                        ?>

                                        <?php

                                        // Membuat string tanggal penyewaan
                                        $tanggal_penyewaan = $data_baju_khusus['tanggal_sewa'] . ' ' . $data_baju_khusus['bulan_sewa'] . ' ' . $data_baju_khusus['tahun_sewa'];

                                        // Menghitung tanggal satu, dua, dan tiga hari setelah tanggal penyewaan
                                        $tanggal_penyewaan_1_hari = date('d F Y', strtotime($tanggal_penyewaan . ' +1 day'));
                                        $tanggal_penyewaan_2_hari = date('d F Y', strtotime($tanggal_penyewaan . ' +2 days'));  
                                        $tanggal_penyewaan_3_hari = date('d F Y', strtotime($tanggal_penyewaan . ' +3 days'));

                                        $harga_baju = $data_baju_khusus['harga_baju'];

                                        $harga_baju_1_hari = $harga_baju * 1;
                                        $harga_baju_2_hari = $harga_baju * 2;
                                        $harga_baju_3_hari = $harga_baju * 3;

                                        $biaya_layanan_1_hari = $harga_baju_1_hari * 0.05;
                                        $biaya_layanan_2_hari = $harga_baju_2_hari * 0.05;
                                        $biaya_layanan_3_hari = $harga_baju_3_hari * 0.05;

                                        $ppn_1_hari = $harga_baju_1_hari * 0.11;
                                        $ppn_2_hari = $harga_baju_2_hari * 0.11;
                                        $ppn_3_hari = $harga_baju_3_hari * 0.11;

                                        $total_1_hari = $harga_baju_1_hari + $biaya_layanan_1_hari + $ppn_1_hari;
                                        $total_2_hari = $harga_baju_2_hari + $biaya_layanan_2_hari + $ppn_2_hari;
                                        $total_3_hari = $harga_baju_3_hari + $biaya_layanan_3_hari + $ppn_3_hari;

                                        ?>

                                        <div class="col">
                                            <p class="text-end font-monospace fs-6 fst-italic">Tanggal Pemesanan : <?php echo $tanggal_pemesanan; ?></p>
                                        </div>

                                    </div>

                                    <div class="row">

                                        <div class="col">
                                            <p class="text-start font-monospace fs-6 fst-italic">Nama Pemilik Busana : <?= $data_toko['nama_toko'] ?></p>
                                        </div>

                                        <?php
                                            $id_pemesanan = '';
                                            $id_pemesanan = date('dmy') .rand(10,1000);
                                        ?>

                                        <div class="col">
                                            <p class="text-end font-monospace fs-6 fst-italic">ID Pemesanan : #<?php echo $id_pemesanan; ?></p>
                                        </div>

                                    </div>

                                    <hr style="border-top: 1px dashed black;">

                                    <p class="text-center" ><span class="fs-5 fst-italic fw-light font-monospace">Total Pembayaran pembayaran</span></p>

                                    <hr style="border-top: 1px dashed black;">

                                    <style> .hari {display: none;} </style>

                                    <div class="nota_1_hari hari_1 hari">

                                        <div class="row mt-2 mb-2">

                                            <div class="col-md-9">

                                                <p class="font-monospace fs-5 fw-bold">Nama Produk : <?= $data_baju['nama_baju']; ?></p>

                                                <p class="font-monospace fs-6 nota_1_hari">1 hari</p>

                                                <p class="font-monospace fs-6 nota_ukuran_s">Ukuran <?= $data_baju_khusus['ukuran_baju']; ?></p>

                                                <p class="font-monospace fs-6 nota_tanggal_penyewaan">Tanggal Penyewaan : <?= $data_baju_khusus['tanggal_sewa']; ?> <?= $data_baju_khusus['bulan_sewa']; ?> <?= $data_baju_khusus['tahun_sewa']; ?></p>

                                                <p class="font-monospace fs-6 nota_tanggal_pengembalian">Tanggal Pengembalian : <?= $tanggal_penyewaan_1_hari; ?></p>

                                            </div>

                                            <div class="col-md-3 d-flex justify-content-end">

                                                <div class="col-md-4">

                                                    <p class="font-monospace fs-6 fw-bold">Rp.</p>

                                                </div>
                                                
                                                <div class="col-md-8 d-flex justify-content-end">

                                                    <p class="font-monospace fs-6 fw-bold"><?= $harga_baju_1_hari ?></p>

                                                </div>

                                            </div>

                                        </div>

                                        <hr style="border-top: 1px dashed black;">

                                        <div class="biaya_1_hari d-block">

                                            <div class="row mt-2 mb-2"> <!-- 1 Hari -->

                                                <div class="col-md-9">

                                                    <p class="font-monospace fs-6 fw-bold nota_biaya_layanan">Biaya Layanan (5%)</p>

                                                </div>
                                                

                                                <div class="col-md-3 d-flex justify-content-end">

                                                    <div class="col-md-4">

                                                        <p class="font-monospace fs-6 fw-bold">Rp.</p>

                                                    </div>
                                                    
                                                    <div class="col-md-8 d-flex justify-content-end">

                                                        <p class="font-monospace fs-6 fw-bold nota_biaya_layanan"><?= $biaya_layanan_1_hari ?></p>

                                                    </div>

                                                </div>

                                            </div>

                                            <div class="row mt-2 mb-2">

                                                <div class="col-md-9">

                                                    <p class="font-monospace fs-6 fw-bold nota_biaya_layanan">PPN (11%)</p>

                                                </div>
                                                

                                                <div class="col-md-3 d-flex justify-content-end">

                                                    <div class="col-md-4">

                                                        <p class="font-monospace fs-6 fw-bold">Rp.</p>

                                                    </div>
                                                    
                                                    <div class="col-md-8 d-flex justify-content-end">

                                                        <p class="font-monospace fs-6 fw-bold nota_biaya_layanan"><?= $ppn_1_hari ?></p>

                                                    </div>

                                                </div>

                                            </div>
                                            
                                            <div class="row mt-2 mb-2">

                                                <div class="col-md-9">

                                                    <p class="font-monospace fs-6 fw-bold nota_biaya_layanan">Diskon</p>

                                                </div>
                                                

                                                <div class="col-md-3 d-flex justify-content-end">

                                                    <div class="col-md-4">

                                                        <p class="font-monospace fs-6 fw-bold">Rp.</p>

                                                    </div>
                                                    
                                                    <div class="col-md-8 d-flex justify-content-end">

                                                        <p class="font-monospace fs-6 fw-bold nota_biaya_layanan">- 0</p>

                                                    </div>

                                                </div>

                                            </div>
                                    
                                        </div>

                                        <hr style="border-top: 1px dashed black;">

                                        <div class="total_1_hari">

                                            <div class="row mt-2 mb-2">

                                                <div class="col-md-9">

                                                    <p class="font-monospace fs-6 fw-bolder nota_total">Total Pembayaran</p>

                                                </div>
                                                

                                                <div class="col-md-3 d-flex justify-content-end">

                                                    <div class="col-md-4">

                                                        <p class="font-monospace fs-6 fw-bold">Rp.</p>

                                                    </div>
                                                    
                                                    <div class="col-md-8 d-flex justify-content-end">

                                                        <p class="font-monospace fs-6 fw-bold nota_biaya_total"><?= $total_1_hari ?></p>

                                                    </div>

                                                </div>

                                            </div>

                                        </div>

                                    </div>

                                    <div class="nota_2_hari hari_2 hari">

                                        <div class="row mt-2 mb-2">

                                            <div class="col-md-9">

                                                <p class="font-monospace fs-5 fw-bold">Nama Produk : <?= $data_baju['nama_baju'] ?></p>

                                                <p class="font-monospace fs-6 nota_2_hari">2 hari</p>

                                                <p class="font-monospace fs-6 nota_ukuran_s">Ukuran <?= $data_baju_khusus['ukuran_baju'] ?></p>

                                                <p class="font-monospace fs-6 nota_tanggal_penyewaan">Tanggal Penyewaan : <?= $data_baju_khusus['tanggal_sewa'] ?> <?= $data_baju_khusus['bulan_sewa'] ?> <?= $data_baju_khusus['tahun_sewa'] ?></p>

                                                <p class="font-monospace fs-6 nota_tanggal_pengembalian">Tanggal Pengembalian : <?= $tanggal_penyewaan_2_hari ?></p>

                                            </div>

                                            <div class="col-md-3 d-flex justify-content-end">

                                                <div class="col-md-4">

                                                    <p class="font-monospace fs-6 fw-bold">Rp.</p>

                                                </div>
                                                
                                                <div class="col-md-8 d-flex justify-content-end">

                                                    <p class="font-monospace fs-6 fw-bold"><?= $harga_baju_2_hari ?></p>

                                                </div>

                                            </div>

                                        </div>

                                        <hr style="border-top: 1px dashed black;">

                                        <div class="biaya_2_hari d-block">

                                            <div class="row mt-2 mb-2"> <!-- 2 Hari -->

                                                <div class="col-md-9">

                                                    <p class="font-monospace fs-6 fw-bold nota_biaya_layanan">Biaya Layanan (5%)</p>

                                                </div>
                                                

                                                <div class="col-md-3 d-flex justify-content-end">

                                                    <div class="col-md-4">

                                                        <p class="font-monospace fs-6 fw-bold">Rp.</p>

                                                    </div>
                                                    
                                                    <div class="col-md-8 d-flex justify-content-end">

                                                        <p class="font-monospace fs-6 fw-bold nota_biaya_layanan"><?= $biaya_layanan_2_hari ?></p>

                                                    </div>

                                                </div>

                                            </div>

                                            <div class="row mt-2 mb-2">

                                                <div class="col-md-9">

                                                    <p class="font-monospace fs-6 fw-bold nota_biaya_layanan">PPN (11%)</p>

                                                </div>
                                                

                                                <div class="col-md-3 d-flex justify-content-end">

                                                    <div class="col-md-4">

                                                        <p class="font-monospace fs-6 fw-bold">Rp.</p>

                                                    </div>
                                                    
                                                    <div class="col-md-8 d-flex justify-content-end">

                                                        <p class="font-monospace fs-6 fw-bold nota_biaya_layanan"><?= $ppn_2_hari ?></p>

                                                    </div>

                                                </div>

                                            </div>
                                            
                                            <div class="row mt-2 mb-2">

                                                <div class="col-md-9">

                                                    <p class="font-monospace fs-6 fw-bold nota_biaya_layanan">Diskon</p>

                                                </div>
                                                

                                                <div class="col-md-3 d-flex justify-content-end">

                                                    <div class="col-md-4">

                                                        <p class="font-monospace fs-6 fw-bold">Rp.</p>

                                                    </div>
                                                    
                                                    <div class="col-md-8 d-flex justify-content-end">

                                                        <p class="font-monospace fs-6 fw-bold nota_biaya_layanan">- 0</p>

                                                    </div>

                                                </div>

                                            </div>
                                    
                                        </div>
                                        
                                        <hr style="border-top: 1px dashed black;">

                                        <div class="total_2_hari">

                                            <div class="row mt-2 mb-2">

                                                <div class="col-md-9">

                                                    <p class="font-monospace fs-6 fw-bolder nota_total">Total Pembayaran</p>

                                                </div>
                                                

                                                <div class="col-md-3 d-flex justify-content-end">

                                                    <div class="col-md-4">

                                                        <p class="font-monospace fs-6 fw-bold">Rp.</p>

                                                    </div>
                                                    
                                                    <div class="col-md-8 d-flex justify-content-end">

                                                        <p class="font-monospace fs-6 fw-bold nota_biaya_total"><?= $total_2_hari ?></p>

                                                    </div>

                                                </div>

                                            </div>

                                        </div>

                                    </div>
                                    
                                    <div class="nota_3_hari hari_3 hari">

                                        <div class="row mt-2 mb-2">

                                            <div class="col-md-9">

                                                <p class="font-monospace fs-5 fw-bold">Nama Produk : <?= $data_baju['nama_baju'] ?></p>

                                                <p class="font-monospace fs-6 nota_3_hari">3 hari</p>

                                                <p class="font-monospace fs-6 nota_ukuran_s">Ukuran <?= $data_baju_khusus['ukuran_baju']; ?></p>

                                                <p class="font-monospace fs-6 nota_tanggal_penyewaan">Tanggal Penyewaan : <?= $data_baju_khusus['tanggal_sewa'] ?> <?= $data_baju_khusus['bulan_sewa'] ?> <?= $data_baju_khusus['tahun_sewa'] ?></p>

                                                <p class="font-monospace fs-6 nota_tanggal_pengembalian">Tanggal Pengembalian : <?= $tanggal_penyewaan_3_hari ?></p>

                                            </div>

                                            <div class="col-md-3 d-flex justify-content-end">

                                                <div class="col-md-4">

                                                    <p class="font-monospace fs-6 fw-bold">Rp.</p>

                                                </div>
                                                
                                                <div class="col-md-8 d-flex justify-content-end">

                                                    <p class="font-monospace fs-6 fw-bold"><?= $harga_baju_3_hari ?></p>

                                                </div>

                                            </div>

                                        </div>

                                        <hr style="border-top: 1px dashed black;">

                                        <div class="biaya_3_hari d-block">

                                            <div class="row mt-2 mb-2"> <!-- 3 Hari -->

                                                <div class="col-md-9">

                                                    <p class="font-monospace fs-6 fw-bold nota_biaya_layanan">Biaya Layanan (5%)</p>

                                                </div>
                                                

                                                <div class="col-md-3 d-flex justify-content-end">

                                                    <div class="col-md-4">

                                                        <p class="font-monospace fs-6 fw-bold">Rp.</p>

                                                    </div>
                                                    
                                                    <div class="col-md-8 d-flex justify-content-end">

                                                        <p class="font-monospace fs-6 fw-bold nota_biaya_layanan"><?= $biaya_layanan_3_hari ?></p>

                                                    </div>

                                                </div>

                                            </div>

                                            <div class="row mt-2 mb-2">

                                                <div class="col-md-9">

                                                    <p class="font-monospace fs-6 fw-bold nota_biaya_layanan">PPN (11%)</p>

                                                </div>
                                                

                                                <div class="col-md-3 d-flex justify-content-end">

                                                    <div class="col-md-4">

                                                        <p class="font-monospace fs-6 fw-bold">Rp.</p>

                                                    </div>
                                                    
                                                    <div class="col-md-8 d-flex justify-content-end">

                                                        <p class="font-monospace fs-6 fw-bold nota_biaya_layanan"><?= $ppn_3_hari ?></p>

                                                    </div>

                                                </div>

                                            </div>
                                            
                                            <div class="row mt-2 mb-2">

                                                <div class="col-md-9">

                                                    <p class="font-monospace fs-6 fw-bold nota_biaya_layanan">Diskon</p>

                                                </div>
                                                

                                                <div class="col-md-3 d-flex justify-content-end">

                                                    <div class="col-md-4">

                                                        <p class="font-monospace fs-6 fw-bold">Rp.</p>

                                                    </div>
                                                    
                                                    <div class="col-md-8 d-flex justify-content-end">

                                                        <p class="font-monospace fs-6 fw-bold nota_biaya_layanan">- 0</p>

                                                    </div>

                                                </div>

                                            </div>
                                    
                                        </div>

                                        <hr style="border-top: 1px dashed black;">

                                        <div class="total_3_hari">

                                            <div class="row mt-2 mb-2">

                                                <div class="col-md-9">

                                                    <p class="font-monospace fs-6 fw-bolder nota_total">Total Pembayaran</p>

                                                </div>
                                                

                                                <div class="col-md-3 d-flex justify-content-end">

                                                    <div class="col-md-4">

                                                        <p class="font-monospace fs-6 fw-bold">Rp.</p>

                                                    </div>
                                                    
                                                    <div class="col-md-8 d-flex justify-content-end">

                                                        <p class="font-monospace fs-6 fw-bold nota_biaya_total"><?= $total_3_hari; ?></p>

                                                    </div>

                                                </div>

                                            </div>

                                        </div>

                                    </div>

                                    <div class="footer_nota mt-5">

                                        <p class="font-monospace f-6 text-center">

                                            Terima kasih telah menggunakan WA! JU! sebagai platform sewa busana pertama di Indonesia!

                                        </p>

                                        <p class="font-monospace f-6 text-center">

                                            Saran dan Kritik : 0896-6891-4466, Instagram : @waajuu

                                        </p>

                                        <p class="font-monospace f-6 text-center">

                                            sewawaju.my.id

                                        </p>

                                    </div>

                                    <img src="../img/icon/logo2.png" class="mb-3 m-auto" alt="logo" style="filter: brightness(0) saturate(100%) invert(59%) sepia(0%) saturate(52%) hue-rotate(245deg) brightness(101%) contrast(91%); width: 150px; height: auto; opacity: 0.8;">

                                </div>
                            </div>
                        </div>

                    </div>
                
                    <!-- Tombol untuk Membuat Pesanan -->

                        <div class="container d-flex alert bg-danger text-white alert-info mt-4 lengkapi_data" style="display: none;">
                            <div class="col-10 d-flex justify-content-start">
                                <div class="col-auto alert-icon d-flex">
                                    <i class="material-icons">info_outline</i>
                                </div>
                                <div class="col-auto d-flex"><p><span class="fw-bold">Lengkapi Data Anda Terlebih Dahulu Sebelum Menyewa.</span></p></div>
                            </div>
                            <div class="col-2 d-flex justify-content-end">
                                <div class="col-2 d-flex justify-content-center">
                                <button class="d-flex justify-content-end bg-transparent border-0" type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true"><i class="material-icons text-white">clear</i></span>
                                </button>
                                </div>
                            </div>
                        </div>

                        <div class="text-center mt-3 m-auto">
                            <a
                            <?php 
                            
                            if (($data_pengguna['nomor_telepon'] == NULL) OR 
                                ($data_pengguna['nik_pengguna'] == NULL) OR
                                ($data_pengguna['alamat_pengguna'] == NULL)) {
                                    echo "disabled";
                                }
                                        
                            ?>
                            class="btn btn-primary flex-nowrap btn-lg tombol_pesanan m-auto" style="display: none;" data-bs-toggle="modal" data-bs-target="#modal_pesan">Buat Pesanan</a>

                            <?php
                            
                                if (($data_pengguna['nomor_telepon'] == NULL) OR 
                                    ($data_pengguna['nik_pengguna'] == NULL) OR
                                    ($data_pengguna['alamat_pengguna'] == NULL)) {
                                    echo "<style> .lengkapi_data {display: flex !important;}</style>";
                                }
                            
                            ?>
                        </div>

                    <!-- Tombol untuk Membuat Pesanan Selesai -->

                </div>

            <!-- Isi Website Selesai -->

            <!-- Modal Pesanan -->

                <!-- Modal -->

                <div class="modal fade" id="modal_pesan" tabindex="-1" aria-labelledby="modal_pesanLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">Pesanan Anda</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <p>Dengan menekan tombol <b>"Buat Pesanan"</b>, Anda telah <b>menyetujui <a href="" class="link-underline-primary" data-bs-toggle="modal" data-bs-target="#modal_syarat">syarat & ketentuan berlaku</a></b>. Dan jika terdapat pelanggaran anda dapat dikenakan <b>denda</b>.</p>
                            <p>Pesanan yang telah dibuat tidak dapat dibatalkan, maka bijaklah dalam membuat pesanan.</p>
                        </div>
                        <div class="modal-footer">

                                <!--    List untuk invoice

                                        1. Nama Penyewa             4. Alamat Penyewa           7. Nama Pemilik
                                        2. NIK Penyewa (Sensor)     5. ID Pemesanan             8. Alamat Pemilik
                                        3. No Telepon Penyewa       6. Tanggal Pemesanan        9. No Telepon Pemilik

                                        10. Nama Produk
                                        11. jumlah hari penyewaan
                                        12. tanggal penyewaan, bulan penyewaan, tahun penyewaan
                                        13. tanggal pengembalian

                                        14. harga produk

                                        15. id databaju
                                        16. id dataakun
                                        17. datatoko

                                        Terdapat Mekanisme memberika data jumlah hari penyewaan berupa int,

                                -->

                                <!-- Fungsi mensensor NIK -->

                                    <?php

                                    // Mengubah NIK menjadi string
                                    $nik_string = (string)$data_pengguna['nik_pengguna'];

                                    // Mengambil bagian awal dan akhir dari NIK
                                    $awal = substr($nik_string, 0, 3); // 3 digit pertama
                                    $akhir = substr($nik_string, -4);   // 4 digit terakhir

                                    // Menghitung jumlah digit yang perlu disensor
                                    $jumlah_x = strlen($nik_string) - strlen($awal) - strlen($akhir);

                                    // Membuat string sensor
                                    $sensor = str_repeat('x', $jumlah_x);

                                    // Menggabungkan bagian awal, string sensor, dan bagian akhir
                                    $nik_tersensor = $awal . $sensor . $akhir;

                                    ?>

                                <!-- Fungsi mensensor NIK Selesai -->

                                <input type="hidden" name="id_dataakun" value="<?= $data_pengguna['id'] ?>">
                                <input type="hidden" name="nama_penyewa" value="<?= $data_pengguna['nama_pengguna'] ?>">
                                <input type="hidden" name="nik_penyewa" value="<?= $nik_tersensor ?>">
                                <input type="hidden" name="kontak_penyewa" value="<?= $data_pengguna['nomor_telepon'] ?>">
                                <input type="hidden" name="alamat_penyewa" value="<?= $data_pengguna['alamat_pengguna'] ?>">
                                <input type="hidden" name="id_pemesanan" value="<?= $id_pemesanan ?>">
                                <input type="hidden" name="tanggal_pemesanan" value="<?= $tanggal_pemesanan ?>">
                                <input type="hidden" name="tanggal_sewa" value="<?= $data_baju_khusus['tanggal_sewa'] ?>">
                                <input type="hidden" name="bulan_sewa" value="<?= $data_baju_khusus['bulan_sewa'] ?>">
                                <input type="hidden" name="tahun_sewa" value="<?= $data_baju_khusus['tahun_sewa'] ?>">
                                <input type="hidden" name="tanggal_pengembalian_1_hari" value="<?= $tanggal_penyewaan_1_hari; ?>">
                                <input type="hidden" name="tanggal_pengembalian_2_hari" value="<?= $tanggal_penyewaan_2_hari; ?>">
                                <input type="hidden" name="tanggal_pengembalian_3_hari" value="<?= $tanggal_penyewaan_3_hari; ?>">
                                <input type="hidden" name="nama_pemilik" value="<?= $data_baju['pemilik_baju'] ?>">
                                <input type="hidden" name="alamat_pemilik" value="<?= $data_baju['alamat_toko'] ?>">
                                <input type="hidden" name="kontak_pemilik" value="<?= $data_baju['kontak_pemilik'] ?>">
                                <input type="hidden" name="nama_baju" value="<?= $data_baju_khusus['nama_baju'] ?>">
                                <input type="hidden" name="harga_baju" value="<?= $data_baju_khusus['harga_baju'] ?>">
                                <input type="hidden" name="foto_baju" value="<?= $data_baju_khusus['foto_baju'] ?>">
                                <input type="hidden" name="ukuran_baju" value="<?= $data_baju_khusus['ukuran_baju'] ?>">
                                <input type="hidden" name="id_datatoko" value="<?= $data_baju_khusus['id_toko'] ?>">
                                <input type="hidden" name="id_databaju" value="<?= $data_baju['id'] ?>">

                                <button type="submit" class="btn btn-primary" id="pindah" onclick="pindahHalaman()">Buat Pesanan</button>
                            </form>
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">batal</button>
                        </div>
                        </div>
                    </div>
                </div>

            <!-- Modal Syarat Ketentuan Selesai -->

        </div>

    <!-- Isi Website Selesai -->

    <!-- Footer Website -->
                        
        <link rel="stylesheet" href="..\footer\footer.css">

        <?php

            // Koneksi ke database
            $con = mysqli_connect("localhost", "root", "", "waju");

            // Cek koneksi
            if (!$con) {
                die("Koneksi gagal: " . mysqli_connect_error());
            }

            $query = "SELECT * FROM footer"; // Menggunakan nama_baju
            $result = mysqli_query($con, $query);

            $footer = mysqli_fetch_assoc($result);
            
            echo $footer['footer'];

        ?>

    <!-- Footer Website Selesai -->

    <!-- Script Section -->

        <!-- Skrip JS Eksternal -->
            <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
            <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
            <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
            <script src="..\bootstrap\js\bootstrap.min.js"></script>
            <script src="https://unpkg.com/bootstrap-material-design@4.1.1/dist/js/bootstrap-material-design.js" integrity="sha384-CauSuKpEqAFajSpkdjv3z9t8E7RlpJ1UP0lKM/+NdtSarroVKu069AlsRPKkFBz9" crossorigin="anonymous"></script>

            <script>

                function hideShowDiv(val) {
                    // Sembunyikan semua elemen dengan kelas 'hari'
                    var hariElements = document.getElementsByClassName('hari');
                    
                    for (var i = 0; i < hariElements.length; i++) {
                        hariElements[i].style.display = 'none'; // Sembunyikan semua
                    }

                    // Tampilkan elemen yang sesuai
                    if (val >= 1 && val <= 3) {
                        document.getElementsByClassName('hari_' + val)[0].style.display = 'block';

                        var tombolPesanan = document.getElementsByClassName('tombol_pesanan');
                        if (tombolPesanan.length > 0) {
                            tombolPesanan[0].style.display = 'flex'; // Tampilkan tombol pesanan
                        }
                    }

                    if (val == 1) {
                        document.getElementById('hari1').style.display = 'block';
                        document.getElementByClassName('hari').style.display = 'block';
                    }

                }

            </script>

        <!-- Skrip JS Eksternal Selesai -->

    <!-- Script Section Selesai -->

    <!-- PHP Akhir -->

        <?php

        }else{
            header("Location: ../halaman_utama/halaman_utama.html");
            exit();
        }

        ?>

    <!-- PHP Akhir Selesai -->

  </body>
</html>