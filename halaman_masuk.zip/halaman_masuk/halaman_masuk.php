<!DOCTYPE html>

<html lang="en">

    <head>

        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Halaman Masuk</title>
        <link rel="stylesheet" href="halaman_masuk.css">

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

        <!-- Icon & Bootstrap -->

        <link href="..\bootstrap\css\bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

        <!-- Bootstrap JS dari file lokal -->
        <script src="..\bootstrap\js\bootstrap.min.js"></script>

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

        <!-- Logo Tab -->

        <link rel="icon" type="image/x-icon" href="../img/icon/logo_atas.svg">

        <style>

            .navbar {
            background-image: url(../img/icon/navbar.png);
            background-size: cover;
            width: 104%;
            height: 100px;
            display: block;
            justify-content: space-between;
            align-items: center;
            position: fixed;
            border-bottom-left-radius: 20em 28em;
            border-bottom-right-radius: 20em 28em;
            margin-left: -2%;
            margin-right: 0;
            padding: 1rem 0;
            top: 0;
            left: 0;
            box-shadow: 0 0 100px rgba(0, 0, 0, 0.325);
            z-index: 100;
            }
            
            .navbar .container {
                display: flex;
                justify-content: space-between; 
                align-items: center;
                max-width: 100%;
            }
            
            .navbar .container a {
                margin-left: 50px ;
            }
            
            .logo {
                width: 200px ;
                height: 75px ;
                margin-top: -1.5%;
                margin-left: 0;
                margin-right: 5%;
                object-fit: cover;
                display: block;
                transition: 0.3s;
                padding-right: 10px;
            }
            
            .slogan {
                text-decoration: none;
                margin-top: auto;
                margin-top: 0;
                width: 3000px;
                text-align: left;
                margin-left: 0 auto;
                margin-right: 0 auto;
                padding-left: 20px;
                letter-spacing: 3px;
                color: white;
                
            }
            
            .navbar .container .logo:hover {
                filter:invert(100%) !important;
                opacity: 0.7;
            }
            
            .navbar .masuk-daftar {
                margin-top: 0;
                margin-right: 5%;
            }
            
            .masuk {
                    background-color: #f2f2f2; 
                    color: #a6a6a6;
                    padding: 10px 20px;
                    text-decoration: none;
                    border-radius: 30px;
                    font-size: 1.1rem;
                    /*margin-right: 5%;*/
                    /*margin-top: -2%;*/
                    transition: 0.3s;
            }
            
            .masuk:hover {
                filter:invert(100%) !important;
                opacity: 0.7;
            }
            
            .daftar {
                background-color: none;
                border: 2px #f2f2f2 solid; 
                color: #f2f2f2;
                padding: 10px 20px;
                text-decoration: none;
                border-radius: 30px;
                font-size: 1.1rem;
                /*margin-right: 20%;*/
                /*margin-top: -4%;*/
                transition: 0.3s;
            }
            
            .daftar:hover {
            filter:invert(100%) !important;
            opacity: 0.7;
            }

        </style>

    </head>

    <body style="flex-direction: column !important;">

    <!-- Navigation Bar --> <!------------------------------------------------------------------------------->

        <nav class="navbar">
            <div class="container d-flex ">

            <div class="col-md-3 d-flex">

            <!-- Logo -->

               <a href="..\halaman_utama\halaman_utama.html"> 
                 <img src="../img/icon/logo.svg" alt="logo" class="logo">
                </a>

            <!------------------------------------------------>

            </div>

            <div class="col-md-6 d-flex justify-content-center-start">

            <!-- Slogan -->

                <p class="slogan">
                    Jadi bintang itu pakai yang keren
                </p>

                <style>

                    @media (max-width: 792px) {
                            .slogan {
                                display: none !important;
                            }
                        }

                </style>

            </div>
            <!------------------------------------------------>

            <div class="col-md-3">

            <!-- Tombol Daftar & Masuk -->

                <div class="masuk-daftar"> 
                    <table>
                        <tr>
                            <td style="padding-left: 10%;"><a href="..\halaman_registrasi\registrasi.php" class="daftar" style="font-weight: bold;">DAFTAR</a></td>
                            <td><a href="..\halaman_masuk\halaman_masuk.php" class="masuk" style="font-weight: bold;">MASUK</a></td>
                        </tr>
                     </table>   

                </div>
            </div>
            
            </div>
             <!------------------------------------------------>
             
        </nav>

    <!-- Navigation Bar Selesai --> <!------------------------------------------------------------------------------->

        <!-- Isi Website -->

        <div class="isi" style="padding-top: 60px; padding-bottom: 100px;">

            <div class="login-box">
                <div class="login-header">
                    <header>Masuk</header>
                    <br>
                </div>

                <form action="../mysql_database/login.php" method="post">

                    <?php if (isset($_GET['error'])) {
                        echo <<<GFG
                        <div class="alert">
                            <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span>
                            <p style="font-size: 14px;">Nama Pengguna atau Kata Sandi Salah</p>
                        </div>

                        <style>
                        /* The alert message box */
                        .alert {
                        padding: 20px;
                        background-color: #f44336; /* Red */
                        color: white;
                        margin-bottom: 15px;
                        }

                        /* The close button */
                        .closebtn {
                        margin-left: 15px;
                        color: white;
                        font-weight: bold;
                        float: right;
                        font-size: 22px;
                        line-height: 20px;
                        cursor: pointer;
                        transition: 0.3s;
                        }

                        /* When moving the mouse over the close button */
                        .closebtn:hover {
                        color: black;
                        }
                        </style>

                        <style>
                        .alert {
                        opacity: 1;
                        transition: opacity 0.6s; /* 600ms to fade out */
                        }
                        </style>

                        <script>
                        // Get all elements with class="closebtn"
                        var close = document.getElementsByClassName("closebtn");
                        var i;

                        // Loop through all close buttons
                        for (i = 0; i < close.length; i++) {
                        // When someone clicks on a close button
                        close[i].onclick = function(){

                            // Get the parent of <span class="closebtn"> (<div class="alert">)
                            var div = this.parentElement;

                            // Set the opacity of div to 0 (transparent)
                            div.style.opacity = "0";

                            // Hide the div after 600ms (the same amount of milliseconds it takes to fade out)
                            setTimeout(function(){ div.style.display = "none"; }, 600);
                        }
                        }
                        </script>
                        GFG;
                    } ?>

                    <div class="input-box">
                        <input type="text" name="nama_pengguna" id="nama_pengguna" class="input-field" placeholder="Nama Pengguna" autocomplete="off" required>
                    </div>

                    <div type="input-box"> 
                        <input type="password" name="kata_sandi" id="kata_sandi" class="input-field" placeholder="Kata Sandi" required>
                    </div>

                    <div class="Input-Submit">
                        <button type="submit" class="submit-btn">
                            Masuk
                        </button>
                    </div>
                    
                </form>


                <div class="forgot">
                    <section>
                    <span style="padding-top: 20px;"><a href="../halaman_masuk_admin/halaman_masuk_admin.php">Dashboard Admin</a></span>
                    </section>
                </div>
                <div class="Input-submit">
                    <p> 
                        belum punya akun?
                        <span style="padding-left: 135px;"><a href="..\halaman_registrasi\registrasi.php"> Buat Akun</a></span>
                    </p>
                </div>

            </div>

        </div>

        <!-- Isi Website Selesai -->

        <!-- Script -->

        <script>

        document.addEventListener('DOMContentLoaded', function() {
        var usernameInput = document.getElementById('nama_pengguna');

        usernameInput.addEventListener('input', function(e) {
            var start = this.selectionStart;
            var end = this.selectionEnd;

            // Convert text to lowercase
            this.value = this.value.toLowerCase();

            // Restore the selection range
            this.setSelectionRange(start, end);
        });
        });

        </script>

        <!-- Script Selesai -->
 

            <link rel="stylesheet" href="..\footer\footer.css">

            <?php

                    // Koneksi ke database
                    $con = mysqli_connect("localhost", "root", "", "waju");

                    // Cek koneksi
                    if (!$con) {
                        die("Koneksi gagal: " . mysqli_connect_error());
                    }

                    $query = "SELECT * FROM footer"; 
                    $result = mysqli_query($con, $query);

                    $footer = mysqli_fetch_assoc($result);
                    
                    echo $footer['footer'];

            ?>

</body>

</html>

