<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Kelola Busana</title>

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
  
  <!-- Font Awesome -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script src="..\bootstrap\js\bootstrap.min.js"></script>
  <script src="https://unpkg.com/bootstrap-material-design@4.1.1/dist/js/bootstrap-material-design.js" integrity="sha384-CauSuKpEqAFajSpkdjv3z9t8E7RlpJ1UP0lKM/+NdtSarroVKu069AlsRPKkFBz9" crossorigin="anonymous"></script>

  <!-- PHP -->

  <?php

    session_start();

    if (isset($_SESSION['id']) && 
        isset($_SESSION['nama_toko']) &&
        isset($_SESSION['email_toko'])) {

      $id = $_SESSION['id'];

      $con = mysqli_connect("localhost", "root", "", "waju");

      // Cek koneksi
      if (!$con) {
          die("Koneksi gagal: " . mysqli_connect_error());
      }

      $kueri = "SELECT * FROM datatoko WHERE id = '$id'";
      $hasil = mysqli_query($con, $kueri);

      // Cek apakah query berhasil
      if (!$hasil) {
        die("Query gagal: " . mysqli_error($con));
      }

      if (mysqli_num_rows($hasil) > 0) {
        $data = mysqli_fetch_assoc($hasil);
      } else {
        echo "<p>Data Tidak Ditemukan</p>";
        exit();
      }

      if ($data['status_update'] = 1) {
        $_SESSION['id'] = $data['id'];
        $_SESSION['nama_toko'] = $data['nama_toko'];
        $_SESSION['email_toko'] = $data['email_toko'];

        $kueri_status_update = "UPDATE datatoko SET status_update = 0 WHERE id = '$id'";
        $hasil_status_update = mysqli_query($con, $kueri_status_update);
      }
      
  ?>

  <!-- PHP Selesai -->

  <style>

      * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: "Poppins", sans-serif;
      }
      
      /* Gaya background halaman */
      body {
          background: rgb(217,233,233);
          background: radial-gradient(circle, rgba(217,233,233,1) 3%, rgba(224,237,227,1) 100%);
      }

      /* CSS : Navagation Bar */
      .navbar {
        background-image: url(../img/icon/navbar.png);
        background-size: cover;
        border-bottom-left-radius: 20em 28em;
        border-bottom-right-radius: 20em 28em;
        height: 80px;
        box-shadow: 0 0 100px rgba(0, 0, 0, 0.325);
        z-index: 1000;
      }

      /* Styling untuk brand navbar */
      .navbar-brand {
        display: flex;
        justify-content: center;
        padding: 0px 0px 0% 0px !important;
        margin: 0px 5px 0px 0px !important;
        transition: 0.5s;
      }

      .navbar-brand:hover {
        filter:invert(100%) !important;
        opacity: 0.7;
      }

      /* Tombol Pencarian */
      .tombol_pencarian {
        display: block;
        width: 50px;
        height: auto;
        margin: 0 0 0 0;
        border: 1px solid rgba(14, 89, 129, 0.178);
        border-radius: 20px;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.05); 
        background: rgb(166, 214, 239) url(../img/icon/icon_cari.svg) no-repeat center / 25% !important; /* Menggabungkan properti background */
        transition: 0.1s;
      }
   
      .tombol_pencarian:hover{
        border: none !important;
        filter:invert(20%) !important;
      }

      .tombol_pencarian:active{
        background-size: 50% !important;
      }

      .bar_pencarian {
        color: rgba(91, 91, 91, 0.57);            
        border: 1px solid rgba(14, 89, 129, 0.178);
        border-radius: 20px;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.05); 
        text-indent: 12px;
        letter-spacing: 1px;
        transition: 0.3s;
      }

      .bar_pencarian input:focus,
      .bar_pencarian input:hover {
        color: #00282b;
        border: 1.5px solid #00282b;
      }

      /* Gaya untuk tombol keranjang */
      .base_keranjang, .keranjang {
        margin: auto;
        width: 30px ;
        height: 30px ;
        display: block;
        transition: 0.3s;
        transition: 0.3s;
        justify-content: center; 
        align-items: center; 
      }
    
      .keranjang:hover {
        transform: scale(1.2);
      }

      .keranjang:active {
        animation: beat 0.3s alternate;
        transform-origin: center;
      } 
    
      @keyframes beat{
        to { transform: scale(1.4); }
      }

      /* Gaya untuk nama pengguna */
      .base_username {
        margin: auto;
        width: auto;
        display: inline-flex; 
        justify-content: center; 
        align-items: center; 
        border: 1.5px solid #f2f2f2;
        border-radius: 25px;
        color: #ffffff;
        font-family: "Poppins", sans-serif;
        letter-spacing: 1px;
        padding: 5px 12px;
        font-weight: 600;
        text-decoration: none;
        transition: 0.3s; 
      }

      .tulisan {
        overflow: hidden; 
        white-space: nowrap !important; 
        text-overflow: ellipsis !important; 
        max-width: calc(8vw) !important; 
        width: auto;
        text-align: center;
      }


      .base_username:hover {
        background-color: #f2f2f2;
        color: rgb(39, 74, 94);
        text-decoration :none;
      }
        
      /* Profil dan pengaturan gaya flex */
      .base_profil, .profil {
        margin: auto;
        width: auto ;
        height: 30px ;
        display: flex;
        z-index: 110;
        transition: 0.3s;
        padding-right: 30;
        transition: 0.3s;
        right: 0;   
      }

      .profil:active {
        animation: beat 0.3s alternate;
        transform-origin: center;
      } 

      /* Container dan pengaturan lebar */
      .container-fluid {
        max-width: 95% !important;
      }

      /* Responsif untuk ukuran layar */
        @media (max-width: 1245px) {
      .kolom_profil {
        display: none !important;
        }

      .kolom_logo,
      .kolom_pencarian {
        margin-left: 30px;
        }
      }

        @media (max-width: 992px) {
      .kolom_logo {
        margin: 0 0 0 50px;
        }
      .kolom_pencarian {
        margin: auto;
        max-width: 60vw;
        }
      .kolom_keranjang {
        display: none !important;
        }
      .kolom_nama {
        display: none;
        }
      .kolom_profil {
        display: flex !important;
        }
      .kolom_konten {
        width: auto !important;
        margin: 0 0 0 30px;
        }
      }

        @media (max-width: 741px) {
      .kolom_konten {
        display: none !important;
        }
      .kolom_logo {
        width: 20vw !important;
        }
      .kolom_pencarian {
        width: 60vw !important;
        }
      }

        @media (max-width: 540.98px) {
      .kolom_pencarian {
        display: none;
        }
      .kolom_logo {
        margin: 0 0 0 0 !important;
        width: 100% !important;
        align-items: center;
        justify-content: center;
        display: block !important;
        }
      .navbar-brand {
        align-items: center !important;
        justify-content: center !important;
          }
      }
       /* CSS : Navagation Bar Selesai */

    body {
      font-family: 'poppins';
      background: radial-gradient(circle, #e2fffe, #c8fffe);
    }
    .sidebar {
      height: 100vh;
      position: fixed;
      left: 0;
      top: 0;
      background-color: #6be6ff;
      padding-top: 70px;
      border-right: 1px solid #ddd;
      font-family: 'poppins';
    }
    .sidebar ul {
      list-style-type: none;
      padding: 0;
    }
    .sidebar ul li a {
      display: block;
      padding: 10px 20px;
      color: #333;
      text-decoration: none;
    }
    .sidebar ul li a:hover, .sidebar ul li a.active {
      background-color: #2bc1c1;
      color: #fff;
    }
    .content {
      margin-left: 250px;
      padding: 20px;
      font-family: 'poppins';
    }
    .table thead {
      background-color: #a7f2ff;
      color: #0c5460;
    }
    .sidebar {
      z-index: 10;
    }
    .navbar {
      z-index: 100;
      position: fixed;
      width: 100%
    }
  </style>
</head>
<body>

  <!-- Navagation Bar -->

    <nav class="navbar navbar-expand-lg">

    <div class="container-fluid">

    <div class="col-2 kolom_logo d-flex justify-content-start">
        <a class="navbar-brand" href="../halaman_beranda/halaman_beranda.php">
            <img src="../img/icon/logo_tokowaju.svg" alt="logo" width="200" height="auto">
        </a>
    </div>

    <div class="col-10 row d-flex justify-content-end kolom_konten">

      
      <div class="col-md-auto kolom_nama d-flex justify-content-end">
        <!-- Nama Pengguna -->
        
        <td>
          <a href="../halaman_list/list_sewa.php" class="base_username" id="username">
            <div class="tulisan">
              <?php echo $data['nama_toko']; ?>
            </div>
          </a>
        </td>
        
      </div>

      <div class="col-md-auto d-flex kolom_keranjang ms-3 p-0">
          <!-- Logo Keranjang -->

          <td>
              <form action="../mysql_database/logout.php" method="post" name="tombol_keranjang">
                  <button style="border: none; background: transparent;" class="base_keranjang" type="submit">
                    <a class="nav-link hover-overlay" href="#"><i class="fas fa-sign-out-alt fs-3 mt-1" style="color: #fff;"></i></a>
                  </button>
              </form>
          </td>

      </div>
      
        <div class="col-md-auto d-flex kolom_profil ms-5">
            <!-- Foto profil -->

            <td>
                <a href="../halaman_list/list_sewa.php" class="base_profil">
                <img src="<?php if($data['foto_toko'] == NULL) {echo "..\img\icon\profile.jpg";} else{echo $data['foto_toko'];} ?>" style="transform: scale(1.3); aspect-ratio: 1/1; object-fit: cover;" alt="photo_profil" class="profil rounded-circle border border-success border-opacity-25 shadow">
                </a>
            </td>
            <style>
              .base_profil:hover, .profil:hover {
                transform: scale(1.3);
                }
            </style>
        </div>

    </div>

    </div>

    </nav>

  <!-- Navagation Bar Selesai -->

  <!-- Sidebar -->
  <div class="sidebar">
    <ul>
      <li><a href="dashboard.php" id="menuDashboard"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
      <li><a href="kelola_busana.php" class="active" id="menuKelolaBusana"><i class="fas fa-box"></i> Kelola Busana</a></li>
      <li><a href="pesanan.html" id="menuPesanan"><i class="fas fa-shopping-cart"></i> Pesanan</a></li>
      <li><a href="pelanggan.html" id="menuPelanggan"><i class="fas fa-users"></i> Pelanggan</a></li>
      <li><a href="pengaturan.php" id="menuPengaturan"><i class="fas fa-cogs"></i> Pengaturan</a></li>
    </ul>
  </div>

  <!-- Main Content -->
  <div class="content" style="padding-top: 100px;">
    <h4><i class="fas fa-box" id="pageTitle" class="mb-4"> Kelola Busana</i></h4><hr>

    <!-- Tambah Busana -->
    <button type="button" class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#modal_tambah_busana">
      Tambah Busana
    </button>

    <!-- Tabel Busana -->
    <div class="table-responsive">
      <table class="table table-bordered">
        <thead>
          <tr>
            <th>No</th>
            <th>Nama Busana</th>
            <th>Kategori</th>
            <th>Harga Sewa</th>
            <th>Stok</th>
            <th>Ukuran</th>
            <th>Foto</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>1</td>
            <td>Kebaya Modern</td>
            <td>Formal</td>
            <td>Rp 150,000</td>
            <td>10</td>
            <td>S, L, M</td>
            <td><img src="uploads/foto1.jpg" alt="Foto" width="100"></td>
            <td>
              <button class="btn btn-warning btn-sm edit-btn" data-id="1">Edit</button>
              <button class="btn btn-danger btn-sm delete-btn" data-id="1">Hapus</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- Modal Tambah Busana -->
    <div class="modal fade" id="modal_tambah_busana" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="modal_tambah_busanaLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h1 class="modal-title fs-5" id="staticBackdropLabel">Tambah Busana</h1>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="model-body">
            <div class="form-container pb-3 pt-5">
              <form class="d-flex justify-content-center" method="post" action="../mysql_database/kelola_busana.php" enctype="multipart/form-data">
                
                <div class="col-md-10">
                  
                  <div class="col d-flex justify-content-center align-item-center p-0">
                    <!-- Gambar Profil -->
                    <img class="mb-3 shadow-lg" alt="Foto Profil" height="400" width="300" id="profile-image" src="../img/icon/preview_img.svg" width="100" style="aspect-ratio: 3/4; object-fit: cover;">
                  </div>
                  
                  <div class="col d-flex justify-content-center align-item-center p-0">
                    <!-- Tombol Pilih Gambar -->
                    <button class="btn btn-outline-secondary mt-2" onclick="document.getElementById('upload_pp_pengguna').click();" type="button">
                      Pilih Gambar
                    </button>
                  </div>
                  
                  <div class="col d-flex justify-content-center align-item-center p-0">
                    <!-- Input file yang disembunyikan -->
                    <input name="foto_baju" accept=".jpg, .jpeg, .png" id="upload_pp_pengguna" onchange="previewImage(event)" style="display: none;" type="file" required/>
                  </div>
                  
                  <div class="col d-flex justify-content-center align-item-center text-center p-0 mb-2">
                    <!-- Keterangan Gambar -->
                    <p class="mt-2" style="font-size: 12px; color: #6c757d;">
                      Rasio Foto 1:1
                      <br/>
                      Ukuran gambar: maks. 1 MB
                      <br/>
                      Format gambar: JPG, JPEG, PNG.
                    </p>
                  </div>
                  
                  <!-- Input Nama Baju -->
                  <div class="mb-3">
                    <div class="container row d-flex p-0">
                      <div class="col-md-3 p-0">
                        <label class="form-label text-wrap lh-base" for="nama_baju">Nama baju</label>
                      </div>
                      <div class="col-md-9 p-0">
                        <textarea class="form-control" name="nama_baju" id="nama_baju" maxlength="100" placeholder="50 karakter nama baju anda..." style="font-style: italic;" required value=""></textarea>
                      </div>
                    </div>
                  </div>
                  
                  <!-- Input Deskripsi Baju -->
                  <div class="mb-3">
                    <div class="container row d-flex p-0">
                      <div class="col-md-3 p-0">
                        <label class="form-label text-wrap lh-base" for="deskripsi_toko">Deskripsi baju</label>
                      </div>
                      <div class="col-md-9 p-0">
                        <textarea class="form-control" name="deskripsi_baju" id="deskripsi_baju" maxlength="500" placeholder="500 Karakter deskripsi baju..." style="font-style: italic;" required></textarea>
                      </div>
                    </div>
                  </div>                
                  
                  <!-- Input Kategori Baju -->
                    <div class="mb-3">
                      <div class="container row d-flex p-0">
                        <div class="col-md-3 p-0">
                          <label class="form-label" for="kategori_baju">Kategori Baju</label>
                        </div>
                        <div class="col-md-9 p-0">
                          <input class="form-control" name="kategori_baju" id="kategori_baju" type="text" maxlength="50" placeholder="Kategori baju Anda..." style="font-style: italic;" required/>
                        </div>
                      </div>  
                    </div>

                  <!-- Input harga Baju -->
                  <div class="mb-3">
                      <div class="container row d-flex p-0">
                        <div class="col-md-3 p-0">
                          <label class="form-label" for="harga_baju">Harga Baju</label>
                        </div>
                        <div class="col-md-9 p-0">
                          <input class="form-control" name="harga_baju" id="harga_baju" type="numeric" onkeypress="return numbersonly(this, event)" maxlength="50" placeholder="Harga baju Anda..." style="font-style: italic;" required/>
                        </div>
                      </div>  
                    </div>

                  <!-- Input Ukuran S -->
                  <div class="mb-3">
                      <div class="container row d-flex p-0">
                        <div class="col-md-3 p-0">
                          <label class="form-label" for="ukuran_s">Jumlah Ukuran S</label>
                        </div>
                        <div class="col-md-9 p-0">
                          <input class="form-control" name="ukuran_s" id="ukuran_s" maxlength="50" type="numeric" onkeypress="return numbersonly(this, event)" placeholder="jika tidak ada bisa tulis 0" style="font-style: italic;" required/>
                        </div>
                      </div>  
                    </div>                  
                  
                  <!-- Input Ukuran m -->
                  <div class="mb-3">
                      <div class="container row d-flex p-0">
                        <div class="col-md-3 p-0">
                          <label class="form-label" for="ukuran_m">Jumlah Ukuran M</label>
                        </div>
                        <div class="col-md-9 p-0">
                          <input class="form-control" name="ukuran_m" id="ukuran_m" maxlength="50" type="numeric" onkeypress="return numbersonly(this, event)" placeholder="jika tidak ada bisa tulis 0" style="font-style: italic;" required/>
                        </div>
                      </div>  
                    </div>
                    
                  <!-- Input Ukuran l -->
                  <div class="mb-3">
                    <div class="container row d-flex p-0">
                      <div class="col-md-3 p-0">
                        <label class="form-label" for="ukuran_l">Jumlah Ukuran L</label>
                      </div>
                      <div class="col-md-9 p-0">
                        <input class="form-control" name="ukuran_l" id="ukuran_l" maxlength="50" type="numeric" onkeypress="return numbersonly(this, event)" placeholder="jika tidak ada bisa tulis 0" style="font-style: italic;" required/>
                      </div>
                    </div>  
                  </div>


                </div>
              </div>
            </div>
            <div class="modal-footer">

              <input type="hidden" name="id_toko" value="<?= $data['id'] ?>" />
              <input type="hidden" name="nama_toko" value="<?= $data['nama_toko'] ?>" />
              <input type="hidden" name="foto_toko" value="<?= $data['foto_toko'] ?>" />
              <input type="hidden" name="deskripsi_toko" value="<?= $data['deskripsi_toko'] ?>" />
              <input type="hidden" name="alamat_toko" value="<?= $data['alamat_toko'] ?>" />
              <input type="hidden" name="kontak_pemilik" value="<?= $data['kontak_toko'] ?>" />                                                   
              
              <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Tutup</button>
              <button type="submit" class="btn btn-success">Simpan</button>
            </div>
          </form>
        </div>
      </div>
    </div>

    <!-- Modal Edit Busana -->
    <div class="modal fade" id="editBusanaModal" tabindex="-1" aria-labelledby="editBusanaModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="editBusanaModalLabel">Edit Busana</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <form>
              <div class="mb-3">
                <label for="editNamaBusana" class="form-label">Nama Busana</label>
                <input type="text" class="form-control" id="editNamaBusana">
              </div>
              <div class="mb-3">
                <label for="editKategoriBusana" class="form-label">Kategori</label>
                <input type="text" class="form-control" id="editKategoriBusana">
              </div>
              <div class="mb-3">
                <label for="editHargaSewa" class="form-label">Harga Sewa</label>
                <input type="number" class="form-control" id="editHargaSewa">
              </div>
              <div class="mb-3">
                <label for="editStok" class="form-label">Stok</label>
                <input type="number" class="form-control" id="editStok">
              </div>
            </form>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
            <button type="button" class="btn btn-primary">Simpan Perubahan</button>
          </div>
        </div>
      </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>

  <!-- JS Script -->

    <script>
      // Fungsi untuk menampilkan gambar yang dipilih
          function previewImage(event) {
              const reader = new FileReader();
              reader.onload = function(){
                  const output = document.getElementById('profile-image');
                  const sidebarOutput = document.getElementById('sidebar-profile-image');
                  output.src = reader.result;
                  sidebarOutput.src = reader.result;
              };
              reader.readAsDataURL(event.target.files[0]);
          }
    </script>

    <script>

      function numbersonly(myfield, e)
        {
            var key;
            var keychar;

            if (window.event)
                key = window.event.keyCode;
            else if (e)
                key = e.which;
            else
                return true;

            keychar = String.fromCharCode(key);

            // control keys
            if ((key==null) || (key==0) || (key==8) || (key==9) || (key==13) || (key==27) )
                return true;

            // numbers
            else if ((("0123456789").indexOf(keychar) > -1))
                return true;

            // only one decimal point
            else if ((keychar == "."))
            {
                if (myfield.value.indexOf(keychar) > -1)
                    return false;
            }
            else
                return false;
        }

    </script>


  <?php

  }

  else {
  header('Location: ../halaman_masuk_admin/halaman_masuk_admin.php');
  exit();
  }

  ?>

</body>
</html>
