<!DOCTYPE html>
<html lang="en">
<head>

  <?php

    session_start();

    if (isset($_SESSION['id']) && 
        isset($_SESSION['nama_toko']) &&
        isset($_SESSION['email_toko'])) {

      $id = $_SESSION['id'];

      $con = mysqli_connect("localhost", "root", "", "waju");

      // Cek koneksi
      if (!$con) {
          die("Koneksi gagal: " . mysqli_connect_error());
      }

      $kueri = "SELECT * FROM datatoko WHERE id = '$id'";
      $hasil = mysqli_query($con, $kueri);

      // Cek apakah query berhasil
      if (!$hasil) {
        die("Query gagal: " . mysqli_error($con));
      }

      if (mysqli_num_rows($hasil) > 0) {
        $data = mysqli_fetch_assoc($hasil);
      } else {
        echo "<p>Data Tidak Ditemukan</p>";
        exit();
      }

      if ($data['status_update'] = 1) {
        $_SESSION['id'] = $data['id'];
        $_SESSION['nama_toko'] = $data['nama_toko'];
        $_SESSION['email_toko'] = $data['email_toko'];

        $kueri_status_update = "UPDATE datatoko SET status_update = 0 WHERE id = '$id'";
        $hasil_status_update = mysqli_query($con, $kueri_status_update);
      }
      
  ?>
  
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= $data['nama_toko']; ?> - Pengaturan</title>
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link crossorigin="anonymous" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" rel="stylesheet"/>

  <!-- Custom Font "Poppins" -->

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0&icon_names=check" />

  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Material+Icons">
  <link rel="stylesheet" href="https://unpkg.com/bootstrap-material-design@4.1.1/dist/css/bootstrap-material-design.min.css" integrity="sha384-wXznGJNEXNG1NFsbm0ugrLFMQPWswR3lds2VeinahP8N0zJw9VWSopbjv2x7WCvX" crossorigin="anonymous">
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons">    

  <!-- Menggunakan Bootstrap CSS dari file lokal -->
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <script src="https://code.iconify.design/3/3.1.0/iconify.min.js"></script>

  <!-- Penyertaan skrip Bootstrap untuk interaktivitas -->
  <script src="./Product Page_files/popper.min.js.download"></script>
  <script src="./Product Page_files/bootstrap.min.js.download"></script>

  <script src="..\bootstrap\js\bootstrap.min.js"></script>
  
  <!-- Logo Tab -->

  <link rel="icon" type="image/x-icon" href="../img/icon/logo_atas.svg">
  
  <!-- Custom CSS -->
  <style>

* {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: "Poppins", sans-serif;
      }
      
      /* Gaya background halaman */
      body {
          background: rgb(217,233,233);
          background: radial-gradient(circle, rgba(217,233,233,1) 3%, rgba(224,237,227,1) 100%);
      }

      /* CSS : Navagation Bar */
      .navbar {
        background-image: url(../img/icon/navbar.png);
        background-size: cover;
        border-bottom-left-radius: 20em 28em;
        border-bottom-right-radius: 20em 28em;
        height: 80px;
        box-shadow: 0 0 100px rgba(0, 0, 0, 0.325);
        z-index: 1000;
      }

      /* Styling untuk brand navbar */
      .navbar-brand {
        display: flex;
        justify-content: center;
        padding: 0px 0px 0% 0px !important;
        margin: 0px 5px 0px 0px !important;
        transition: 0.5s;
      }

      .navbar-brand:hover {
        filter:invert(100%) !important;
        opacity: 0.7;
      }

      /* Tombol Pencarian */
      .tombol_pencarian {
        display: block;
        width: 50px;
        height: auto;
        margin: 0 0 0 0;
        border: 1px solid rgba(14, 89, 129, 0.178);
        border-radius: 20px;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.05); 
        background: rgb(166, 214, 239) url(../img/icon/icon_cari.svg) no-repeat center / 25% !important; /* Menggabungkan properti background */
        transition: 0.1s;
      }
   
      .tombol_pencarian:hover{
        border: none !important;
        filter:invert(20%) !important;
      }

      .tombol_pencarian:active{
        background-size: 50% !important;
      }

      .bar_pencarian {
        color: rgba(91, 91, 91, 0.57);            
        border: 1px solid rgba(14, 89, 129, 0.178);
        border-radius: 20px;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.05); 
        text-indent: 12px;
        letter-spacing: 1px;
        transition: 0.3s;
      }

      .bar_pencarian input:focus,
      .bar_pencarian input:hover {
        color: #00282b;
        border: 1.5px solid #00282b;
      }

      /* Gaya untuk tombol keranjang */
      .base_keranjang, .keranjang {
        margin: auto;
        width: 30px ;
        height: 30px ;
        display: block;
        transition: 0.3s;
        transition: 0.3s;
        justify-content: center; 
        align-items: center; 
      }
    
      .keranjang:hover {
        transform: scale(1.2);
      }

      .keranjang:active {
        animation: beat 0.3s alternate;
        transform-origin: center;
      } 
    
      @keyframes beat{
        to { transform: scale(1.4); }
      }

      /* Gaya untuk nama pengguna */
      .base_username {
        margin: auto;
        width: auto;
        display: inline-flex; 
        justify-content: center; 
        align-items: center; 
        border: 1.5px solid #f2f2f2;
        border-radius: 25px;
        color: #ffffff;
        font-family: "Poppins", sans-serif;
        letter-spacing: 1px;
        padding: 5px 12px;
        font-weight: 600;
        text-decoration: none;
        transition: 0.3s; 
      }

      .tulisan {
        overflow: hidden; 
        white-space: nowrap !important; 
        text-overflow: ellipsis !important; 
        max-width: calc(8vw) !important; 
        width: auto;
        text-align: center;
      }


      .base_username:hover {
        background-color: #f2f2f2;
        color: rgb(39, 74, 94);
        text-decoration :none;
      }
        
      /* Profil dan pengaturan gaya flex */
      .base_profil, .profil {
        margin: auto;
        width: auto ;
        height: 30px ;
        display: flex;
        z-index: 110;
        transition: 0.3s;
        padding-right: 30;
        transition: 0.3s;
        right: 0;   
      }

      .profil:active {
        animation: beat 0.3s alternate;
        transform-origin: center;
      } 

      /* Container dan pengaturan lebar */
      .container-fluid {
        max-width: 95% !important;
      }

      /* Responsif untuk ukuran layar */
        @media (max-width: 1245px) {
      .kolom_profil {
        display: none !important;
        }

      .kolom_logo,
      .kolom_pencarian {
        margin-left: 30px;
        }
      }

        @media (max-width: 992px) {
      .kolom_logo {
        margin: 0 0 0 50px;
        }
      .kolom_pencarian {
        margin: auto;
        max-width: 60vw;
        }
      .kolom_keranjang {
        display: none !important;
        }
      .kolom_nama {
        display: none;
        }
      .kolom_profil {
        display: flex !important;
        }
      .kolom_konten {
        width: auto !important;
        margin: 0 0 0 30px;
        }
      }

        @media (max-width: 741px) {
      .kolom_konten {
        display: none !important;
        }
      .kolom_logo {
        width: 20vw !important;
        }
      .kolom_pencarian {
        width: 60vw !important;
        }
      }

        @media (max-width: 540.98px) {
      .kolom_pencarian {
        display: none;
        }
      .kolom_logo {
        margin: 0 0 0 0 !important;
        width: 100% !important;
        align-items: center;
        justify-content: center;
        display: block !important;
        }
      .navbar-brand {
        align-items: center !important;
        justify-content: center !important;
          }
      }
       /* CSS : Navagation Bar Selesai */

    body {
      font-family: 'poppins';
      background: radial-gradient(circle, #e2fffe, #c8fffe);
    }
    .sidebar {
      height: 100vh;
      position: fixed;
      left: 0;
      top: 0;
      background-color: #6be6ff;
      padding-top: 70px;
      border-right: 1px solid #ddd;
      font-family: 'poppins';
    }
    .sidebar ul {
      list-style-type: none;
      padding: 0;
    }
    .sidebar ul li a {
      display: block;
      padding: 10px 20px;
      color: #333;
      text-decoration: none;
    }
    .sidebar ul li a:hover, .sidebar ul li a.active {
      background-color: #2bc1c1;
      color: #fff;
    }
    .content {
      margin-left: 250px;
      padding: 20px;
      font-family: 'poppins';
    }
    .form-section {
      margin-top: 30px;
    }
    .form-section h2 {
      margin-bottom: 20px;
    }
    .btn-primary {
      background-color: #2bc1c1;
      border: none;
    }
    .btn-primary:hover {
      background-color: #15d0ca;
    }
    .sidebar {
        z-index: 10;
      }

    .hover-overlay {
      transition: 0.3s;
    }

    .hover-overlay:hover{
      transform: scale(1.2);
    }

          /* CSS : isi */

      /* Gaya untuk kontainer form */
      .form-container {
        background-color: white;
        border-radius: 10px;
        padding: 60px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      }

      /* Gaya untuk gambar dalam kontainer form (ikon) */
      .form-container img {
        border-radius: 50%;
        width: 100px;
        height: 100px;
      }

      /* Gaya untuk tombol khusus dalam form */
      .form-container .btn-custom {
        background-color: #a5dfbc;
        color: black;
        font-weight: bold;
      }

      /* Gaya untuk tombol sekunder khusus dalam form */
      .form-container .btn-secondary-custom {
        background-color: #a5dfbc;
        color: black;
        border: none;
        font-weight: bold;
      }

      /* Gaya untuk label form */
      .form-container .form-label {
        width: 100px;
      }

      .hover-overlay{
        transition: 0.3s;
      }
      .hover-overlay:hover {
        transform: scale(1.1);
      }

      /* Input telepon */

      .input-telepon {
          /* Anda bisa menambahkan gaya untuk .input-telepon di sini jika diperlukan */
      }

      .input-telepon .select-box {
          position: relative;
      }

      .input-telepon .select-box input {
          width: 100%;
          padding: 1rem .6rem;
          font-size: 1.1rem;
          
          border: 0.5px solid rgba(0, 0, 0, 0 .4);
          outline: none;
      }

      .input-telepon input[type="tel"] {
          border-radius: 0 .5rem .5rem 0;
      }

      .input-telepon .select-box input:focus {
          border: .1rem solid var(--primary);
      }

      .input-telepon .selected-option {
          background-color: #eee;
          border-radius: .5rem;
          overflow: hidden;

          display: flex;
          justify-content: space-between;
          align-items: center;
      }

      .input-telepon .selected-option div {
          position: relative;

          width: 6rem;
          padding: 0 2.8rem 0 .5rem;
          text-align: center;
          cursor: pointer;
      }

      .input-telepon .selected-option div::after {
          position: absolute;
          content: "";
          right: .8rem;
          top: 50%;
          transform: translateY(-50%) rotate(45deg);
          
          width: .8rem;
          height: .8rem;
          border-right: .12rem solid var(--primary);
          border-bottom: .12rem solid var(--primary);

          transition: .2s;
      }

      .input-telepon .selected-option div.active::after {
          transform: translateY(-50%) rotate(225deg);
      }

      .input-telepon .select-box .options {
          position: absolute;
          top: 4rem;
          
          width: 100%;
          background-color: #fff;
          border-radius: .5rem;

          display: none;
      }

      .input-telepon .select-box .options.active {
          display: block;
          z-index: 100;
      }

      .input-telepon .select-box .options::before {
          position: absolute;
          content: "";
          left: 1rem;
          top: -1.2rem;
          display: none;
          width: 0;
          height: 0;
          border: .6rem solid transparent;
          border-bottom-color: var(--primary);
      }

      .input-telepon input.search-box {
          background: rgb(16,181,212); 
          background: linear-gradient(90deg, rgba(16,181,212,1) 0%, rgba(110,227,202,1) 100%);
          color: #eee;
          border-radius: .5rem .5rem 0 0;
          padding: 1.4rem 1rem;
          border: none;
          font-weight: bold;
      }

      .input-telepon input.search-box::placeholder {
        color : #eee;
        opacity: 70%;
      }

      .input-telepon .select-box ol {
          list-style: none;
          max-height: 23rem;
          overflow: overlay;
      }

      .input-telepon .select-box ol::-webkit-scrollbar {
          width: 0.6rem;
      }

      .input-telepon .select-box ol::-webkit-scrollbar-thumb {
          width: 0.4rem;
          height: 3rem;
          background-color: #ccc;
          border-radius: .4rem;
      }

      .input-telepon .select-box ol li {
          padding: 1rem;
          display: flex;
          justify-content: space-between;
          cursor: pointer;
      }

      .input-telepon .select-box ol li.hide {
          display: none;
      }

      .input-telepon .select-box ol li:not(:last-child) {
          border-bottom: .1rem solid #eee;
      }

      .input-telepon .select-box ol li:hover {
          background-color: lightcyan;
      }

      .input-telepon .select-box ol li .country-name {
          margin-left: .4rem;
      }

      /* Modal styles */
      .modal {
        display: none; 
        position: fixed;
        z-index: 1;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        overflow: auto;
        background-color: rgba(0, 0, 0, 0.4);
        padding-top: 60px;
      }
      .modal-content {
        background-color: #f2f2f2;
        margin: 5% auto;
        padding: 20px;
        border: 1px solid #888;
        width: 80%;
        max-width: 300px;
        text-align: center;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      }

      /* Gaya untuk tombol close (X) di bawah teks */
      .close {
        position: absolute;
        bottom: -30px; 
        left: 50%;
        transform: translateX(-50%); 
        font-size: 40px;
        color: white; 
        background-color: black; 
        width: 40px;
        height: 40px; 
        border-radius: 50%; 
        display: flex;
        justify-content: center; 
        align-items: center; 
        cursor: pointer;
    }
    .close {
        color: #aaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
    }
    .close:hover,
    .close:focus {S
        color: black;
        text-decoration: none;
        cursor: pointer;
    }

  </style>
</head>
<body>

    <!-- Navagation Bar -->

    <nav class="navbar navbar-expand-lg">

    <div class="container-fluid">

    <div class="col-2 kolom_logo d-flex justify-content-start">
        <a class="navbar-brand" href="../halaman_beranda/halaman_beranda.php">
            <img src="../img/icon/logo_tokowaju.svg" alt="logo" width="200" height="auto">
        </a>
    </div>

    <div class="col-10 row d-flex justify-content-end kolom_konten">

      
      <div class="col-md-auto kolom_nama d-flex justify-content-end">
        <!-- Nama Pengguna -->
        
        <td>
          <a href="../halaman_list/list_sewa.php" class="base_username" id="username">
            <div class="tulisan">
              <?php echo $data['nama_toko']; ?>
            </div>
          </a>
        </td>
        
      </div>

      <div class="col-md-auto d-flex kolom_keranjang ms-3 p-0">
          <!-- Logo Keranjang -->

          <td>
              <form action="#" method="post" name="tombol_keranjang">
                  <button style="border: none; background: transparent;" class="base_keranjang" type="submit">
                    <a class="nav-link hover-overlay" href="#"><i class="fas fa-sign-out-alt fs-3 mt-1" style="color: #fff;"></i></a>
                  </button>
              </form>
          </td>

      </div>
      
        <div class="col-md-auto d-flex kolom_profil ms-5">
            <!-- Foto profil -->

            <td>
                <a href="../halaman_list/list_sewa.php" class="base_profil">
                <img src="<?php if($data['foto_toko'] == NULL) {echo "..\img\icon\profile.jpg";} else{echo $data['foto_toko'];} ?>" style="transform: scale(1.3); aspect-ratio: 1/1; object-fit: cover;" alt="photo_profil" class="profil rounded-circle border border-success border-opacity-25 shadow">
                </a>
            </td>
            <style>
              .base_profil:hover, .profil:hover {
                transform: scale(1.3);
                }
            </style>
        </div>

    </div>

    </div>

    </nav>

    <!-- Navagation Bar Selesai -->

  <!-- Sidebar -->
  <div class="sidebar">
    <ul class="list-group list-group-flush pt-4">
      <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
      <li><a href="kelola_busana.html"><i class="fas fa-box"></i> Kelola Busana</a></li>
      <li><a href="pesanan.html"><i class="fas fa-shopping-cart"></i> Pesanan</a></li>
      <li><a href="pelanggan.html"><i class="fas fa-users"></i> Pelanggan</a></li>
      <li><a href="pengaturan.html" class="active"><i class="fas fa-cogs"></i> Pengaturan</a></li>
    </ul>
  </div>

  <!-- Main Content -->

  <div class="container ps-5 ms-5 row d-flex justify-content-end mt-5 align-items-start m-0 p-0" style="width: 100% !important;">

      <!-- Form Pengguna -->

      <div class="col-10 row d-flex p-8 align-items-start ms-7">
        <div class="form-container pb-3 pt-5">
          <form class="d-flex" method="post" action="../mysql_database/update_data_admin.php" enctype="multipart/form-data">
            <input type="hidden" name="id_toko" value="<?php echo $_SESSION['id']; ?>">
            <input type="hidden" name="nama_toko_lama" value="<?php echo $_SESSION['nama_toko']; ?>">
            <div class="col-md-8">
              <!-- Input Nama -->
              <div class="mb-3">
                <div class="container row d-flex p-0">
                  <div class="col-md-3 p-0">
                    <label class="form-label" for="nama_toko">Nama Toko</label>
                  </div>
                  <div class="col-md-9 p-0">
                    <input class="form-control" name="nama_toko" id="nama_toko" type="text" placeholder="Nama Anda..." style="font-style: italic;" value="<?= $data['nama_toko'] ?>" required/>
                  </div>
                </div>
              </div>

              <!-- Input Deskripsi Toko -->
              <div class="mb-3">
                <div class="container row d-flex p-0">
                  <div class="col-md-3 p-0">
                    <label class="form-label text-wrap lh-base" for="deskripsi_toko">Deskripsi Toko</label>
                  </div>
                  <div class="col-md-9 p-0">
                    <textarea class="form-control" name="deskripsi_toko" id="deskripsi_toko" maxlength="100" placeholder="100 Karakter deskripsi toko..." style="font-style: italic;" required value="<?= $data['deskripsi_toko'] ?>"><?= $data['deskripsi_toko'] ?></textarea>
                  </div>
                </div>
              </div>                

              <!-- Input Email -->
              <div class="mb-3">
                <div class="container row d-flex p-0">
                  <div class="col-md-3 p-0">
                    <label class="form-label" for="email_toko">Email</label>
                  </div>
                  <div class="col-md-9 p-0">
                    <input class="form-control" name="email_toko" id="email_toko" type="email" placeholder="Email Anda..." style="font-style: italic;" value="<?= $data['email_toko'] ?>" required/>
                  </div>
                </div>  
              </div>

              <!-- Input No. Telepon -->
              <div class="mb-3">
                <div class="container row d-flex p-0">
                  <div class="col-md-3 p-0 d-flex align-items-center">
                    <label class="form-label" for="kontak_toko">No. Telepon</label>
                  </div>
                  <div class="col-md-9 p-0 input-telepon">                 
                    <div class="select-box">
                      <div class="selected-option">
                          <div class="d-flex align-items-center" style="width: 150px; gap: 5px;">
                              <span class="iconify" data-icon="flag:id-4x3"></span>
                              <strong>+62</strong>
                          </div>
                          <input class="shadow-lg" type="tel" inputmode="numeric" minlength="12" maxlength="17" onkeypress="return numbersonly(this, event)" name="kontak_toko" placeholder="Nomor Telepon Anda.." value="<?php if ($data['kontak_toko'] == NULL) {echo "+62";} else {echo $data['kontak_toko'];}   ?>">
                      </div>
                      <div class="options">
                          <input type="text" class="search-box" placeholder="Kode Telepon Negara...">
                          <ol class="shadow-lg">

                          </ol>
                      </div>
                    </div>
                    <script src="script.js"></script>
                  </div>
                </div>  
              </div>

              <!-- Input Alamat -->
              <div class="mb-3">
                <div class="container row d-flex p-0">
                  <div class="col-md-3 p-0">
                    <label class="form-label" for="alamat_toko">Alamat</label>
                  </div>
                  <div class="col-md-9 p-0">
                    <input class="form-control" name="alamat_toko" id="alamat" type="text" placeholder="Alamat Toko Anda..." style="font-style: italic;" value="<?= $data['alamat_toko'] ?>" required/>
                  </div>
                </div>  
              </div>

              <!-- Input Jam Buka -->
              <div class="mb-3">
                <div class="container row d-flex p-0">
                  <div class="col-md-3 ps-0">
                    <label class="form-label" for="jam_buka">Jam Buka</label>
                  </div>
                  <div class="col-md-3 ps-0">
                    <input class="form-control" name="jam_buka" id="jam_buka" type="numeric" onkeypress="return numbersonly(this, event)" placeholder="00" style="font-style: italic;" value="<?= $data['jam_buka'] ?>" maxlength="2" min="0" max="24" min-length="1" required/>
                  </div>
                  <div class="col-md-3 pe-0">
                    <label class="form-label" for="jam_buka">Jam Tutup</label>
                  </div>
                  <div class="col-md-3 pe-0">
                    <input class="form-control" name="jam_tutup" id="jam_buka" type="numeric" onkeypress="return numbersonly(this, event)" placeholder="00" style="font-style: italic;" value="<?= $data['jam_tutup'] ?>" maxlength="2" min="0" max="24" min-length="1" required/>
                  </div>  
                </div>  
              </div>

              <div class="mb-n1">
                <div class="container row d-flex p-0">
                  <div class="col-md-3 ps-0">
                  </div>
                  <div class="col-md-9 ps-0">
                    <p class="fs-6 fst-italic fw-light">*Format Waktu 24-Jam dan Zona Waktu WIB</p>
                  </div>  
                </div>  
              </div>

              <div class="d-flex justify-content-end mt-3 mr-2">
                <button class="btn btn-custom" type="submit">SIMPAN</button>
              </div>

            </div>

            <div class="col-md-4 text-center">

              <div class="col d-flex justify-content-center align-item-center p-0">
                <!-- Gambar Profil -->
                <img class="mb-3 shadow-lg" alt="Foto Profil" height="100" id="profile-image" src="<?php if($data['foto_toko'] == NULL) {echo "..\img\icon\profile.jpg";} else{echo $data['foto_toko'];}?>" width="100" style="aspect-ratio: 1/1; object-fit: cover;">
              </div>

              <div class="col d-flex justify-content-center align-item-center p-0">
                <!-- Tombol Pilih Gambar -->
                <button class="btn btn-outline-secondary mt-2" onclick="document.getElementById('upload_pp_pengguna').click();" type="button">
                  Pilih Gambar
                </button>
              </div>

              <div class="col d-flex justify-content-center align-item-center p-0">
                <!-- Input file yang disembunyikan -->
                <input name="foto_toko" accept=".jpg, .jpeg, .png" id="upload_pp_pengguna" name="upload_pp_pengguna" onchange="previewImage(event)" style="display: none;" type="file"/>
              </div>

              <div class="col d-flex justify-content-center align-item-center p-0">
                <!-- Keterangan Gambar -->
                <p class="mt-2" style="font-size: 12px; color: #6c757d;">
                  Rasio Foto 1:1
                <br/>
                  Ukuran gambar: maks. 1 MB
                <br/>
                  Format gambar: JPG, JPEG, PNG.
                </p>
              </div>

            </div>
          </form>
        </div>

        <div class="container d-flex alert alert-info mt-4">
          <div class="col-10 d-flex justify-content-start">
            <div class="col-auto alert-icon d-flex">
                <i class="material-icons">info_outline</i>
            </div>
            <div class="col-auto d-flex" style="padding-bottom: 10px"><b>Lengkapi Data Anda Terlebih Dahulu</b></div>
          </div>
          <div class="col-2 d-flex justify-content-end">
            <div class="col-2 d-flex justify-content-center">
            <button class="d-flex justify-content-end bg-transparent border-0" type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true"><i class="material-icons">clear</i></span>
            </button>
            </div>
          </div>
        </div>
      </div>


  </div>

  <script src="..\bootstrap\js\bootstrap.min.js"></script>

  <script src="https://unpkg.com/bootstrap-material-design@4.1.1/dist/js/bootstrap-material-design.js" integrity="sha384-CauSuKpEqAFajSpkdjv3z9t8E7RlpJ1UP0lKM/+NdtSarroVKu069AlsRPKkFBz9" crossorigin="anonymous"></script>

  <!-- Penyertaan skrip Bootstrap untuk interaktivitas -->
  <script src="./Product Page_files/popper.min.js.download"></script>
  <script src="./Product Page_files/bootstrap.min.js.download"></script>

  <script>

      function numbersonly(myfield, e)
        {
            var key;
            var keychar;

            if (window.event)
                key = window.event.keyCode;
            else if (e)
                key = e.which;
            else
                return true;

            keychar = String.fromCharCode(key);

            // control keys
            if ((key==null) || (key==0) || (key==8) || (key==9) || (key==13) || (key==27) )
                return true;

            // numbers
            else if ((("0123456789").indexOf(keychar) > -1))
                return true;

            // only one decimal point
            else if ((keychar == "."))
            {
                if (myfield.value.indexOf(keychar) > -1)
                    return false;
            }
            else
                return false;
        }

</script>

<script>
  // Fungsi untuk menampilkan gambar yang dipilih
        function previewImage(event) {
            const reader = new FileReader();
            reader.onload = function(){
                const output = document.getElementById('profile-image');
                const sidebarOutput = document.getElementById('sidebar-profile-image');
                output.src = reader.result;
                sidebarOutput.src = reader.result;
            };
            reader.readAsDataURL(event.target.files[0]);
        }
</script>

<script>

document.addEventListener('DOMContentLoaded', function() {
  var usernameInput = document.getElementById('nama_toko');

  usernameInput.addEventListener('input', function(e) {
    var start = this.selectionStart;
    var end = this.selectionEnd;

    // Convert text to lowercase
    this.value = this.value.toLowerCase();

    // Restore the selection range
    this.setSelectionRange(start, end);
  });
});

</script>

  <?php

      }

    else {
      header('Location: ../halaman_masuk_admin/halaman_masuk_admin.php');
      exit();
    }

  ?>

</body>
</html>
