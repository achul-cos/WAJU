<head>

  <!-- PHP -->

  <?php 

  session_start();

  // Memeriksa apakah sesi tidak ada
  if (isset($_SESSION['id']) &&
      isset($_SESSION['nama_toko']) &&
      isset($_SESSION['email_toko'])) {
        
        $id = $_SESSION['id'];

        $con = mysqli_connect("localhost", "root", "", "waju");

        // Cek koneksi
          if (!$con) {
            die("Koneksi gagal: " . mysqli_connect_error());
        }

        $kueri_dashboard = "SELECT * FROM datatoko WHERE id = '$id'";
        $hasil = mysqli_query($con, $kueri_dashboard);

        // Cek apakah query berhasil
        if (!$hasil) {
          die("Query gagal: " . mysqli_error($con));
        }

        if (mysqli_num_rows($hasil) > 0) {
          $data = mysqli_fetch_assoc($hasil);
        } else {
          echo "<p>Data Tidak Ditemukan</p>";
          exit();
        }

        if (($data['kontak_toko'] == NULL) or
            ($data['alamat_toko'] == NULL) or
            ($data['deskripsi_toko'] == NULL) or
            ($data['jam_buka'] == NULL)) {
            
              header("Location: ../halaman_admin/pengaturan.php");
              exit();
        }

        elseif (($data['kontak_toko'] =! NULL) and
                ($data['alamat_toko'] =! NULL) and
                ($data['deskripsi_toko'] =! NULL) and
                ($data['jam_buka'] =! NULL)) {
                  
          
  ?>
  
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard</title>
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link crossorigin="anonymous" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" rel="stylesheet"/>

  <!-- Custom Font "Poppins" -->

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0&icon_names=check" />

  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Material+Icons">
  <link rel="stylesheet" href="https://unpkg.com/bootstrap-material-design@4.1.1/dist/css/bootstrap-material-design.min.css" integrity="sha384-wXznGJNEXNG1NFsbm0ugrLFMQPWswR3lds2VeinahP8N0zJw9VWSopbjv2x7WCvX" crossorigin="anonymous">
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons">    

  <!-- Menggunakan Bootstrap CSS dari file lokal -->
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <script src="https://code.iconify.design/3/3.1.0/iconify.min.js"></script>

  <!-- Penyertaan skrip Bootstrap untuk interaktivitas -->
  <script src="./Product Page_files/popper.min.js.download"></script>
  <script src="./Product Page_files/bootstrap.min.js.download"></script>

  <script src="..\bootstrap\js\bootstrap.min.js"></script>
  
  <!-- Logo Tab -->

  <link rel="icon" type="image/x-icon" href="../img/icon/logo_atas.svg">
  
  <!-- Custom CSS -->
  <style>

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: "Poppins", sans-serif;
      }
      
      /* Gaya background halaman */
      body {
          background: rgb(217,233,233);
          background: radial-gradient(circle, rgba(217,233,233,1) 3%, rgba(224,237,227,1) 100%);
      }

      /* CSS : Navagation Bar */
      .navbar {
        background-image: url(../img/icon/navbar.png);
        background-size: cover;
        border-bottom-left-radius: 20em 28em;
        border-bottom-right-radius: 20em 28em;
        height: 80px;
        box-shadow: 0 0 100px rgba(0, 0, 0, 0.325);
        z-index: 1000;
      }

      /* Styling untuk brand navbar */
      .navbar-brand {
        display: flex;
        justify-content: center;
        padding: 0px 0px 0% 0px !important;
        margin: 0px 5px 0px 0px !important;
        transition: 0.5s;
      }

      .navbar-brand:hover {
        filter:invert(100%) !important;
        opacity: 0.7;
      }

      /* Tombol Pencarian */
      .tombol_pencarian {
        display: block;
        width: 50px;
        height: auto;
        margin: 0 0 0 0;
        border: 1px solid rgba(14, 89, 129, 0.178);
        border-radius: 20px;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.05); 
        background: rgb(166, 214, 239) url(../img/icon/icon_cari.svg) no-repeat center / 25% !important; /* Menggabungkan properti background */
        transition: 0.1s;
      }
   
      .tombol_pencarian:hover{
        border: none !important;
        filter:invert(20%) !important;
      }

      .tombol_pencarian:active{
        background-size: 50% !important;
      }

      .bar_pencarian {
        color: rgba(91, 91, 91, 0.57);            
        border: 1px solid rgba(14, 89, 129, 0.178);
        border-radius: 20px;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.05); 
        text-indent: 12px;
        letter-spacing: 1px;
        transition: 0.3s;
      }

      .bar_pencarian input:focus,
      .bar_pencarian input:hover {
        color: #00282b;
        border: 1.5px solid #00282b;
      }

      /* Gaya untuk tombol keranjang */
      .base_keranjang, .keranjang {
        margin: auto;
        width: 30px ;
        height: 30px ;
        display: block;
        transition: 0.3s;
        transition: 0.3s;
        justify-content: center; 
        align-items: center; 
      }
    
      .keranjang:hover {
        transform: scale(1.2);
      }

      .keranjang:active {
        animation: beat 0.3s alternate;
        transform-origin: center;
      } 
    
      @keyframes beat{
        to { transform: scale(1.4); }
      }

      /* Gaya untuk nama pengguna */
      .base_username {
        margin: auto;
        width: auto;
        display: inline-flex; 
        justify-content: center; 
        align-items: center; 
        border: 1.5px solid #f2f2f2;
        border-radius: 25px;
        color: #ffffff;
        font-family: "Poppins", sans-serif;
        letter-spacing: 1px;
        padding: 5px 12px;
        font-weight: 600;
        text-decoration: none;
        transition: 0.3s; 
      }

      .tulisan {
        overflow: hidden; 
        white-space: nowrap !important; 
        text-overflow: ellipsis !important; 
        max-width: calc(8vw) !important; 
        width: auto;
        text-align: center;
      }


      .base_username:hover {
        background-color: #f2f2f2;
        color: rgb(39, 74, 94);
        text-decoration :none;
      }
        
      /* Profil dan pengaturan gaya flex */
      .base_profil, .profil {
        margin: auto;
        width: auto ;
        height: 30px;
        display: flex;
        z-index: 110;
        transition: 0.3s;
        padding-right: 30;
        transition: 0.3s;
        right: 0;   
      }

      .profil:active {
        animation: beat 0.3s alternate;
        transform-origin: center;
      } 

      /* Container dan pengaturan lebar */
      .container-fluid {
        max-width: 95% !important;
      }

      /* Responsif untuk ukuran layar */
        @media (max-width: 1245px) {
      .kolom_profil {
        display: none !important;
        }

      .kolom_logo,
      .kolom_pencarian {
        margin-left: 30px;
        }
      }

        @media (max-width: 992px) {
      .kolom_logo {
        margin: 0 0 0 50px;
        }
      .kolom_pencarian {
        margin: auto;
        max-width: 60vw;
        }
      .kolom_keranjang {
        display: none !important;
        }
      .kolom_nama {
        display: none;
        }
      .kolom_profil {
        display: flex !important;
        }
      .kolom_konten {
        width: auto !important;
        margin: 0 0 0 30px;
        }
      }

        @media (max-width: 741px) {
      .kolom_konten {
        display: none !important;
        }
      .kolom_logo {
        width: 20vw !important;
        }
      .kolom_pencarian {
        width: 60vw !important;
        }
      }

        @media (max-width: 540.98px) {
      .kolom_pencarian {
        display: none;
        }
      .kolom_logo {
        margin: 0 0 0 0 !important;
        width: 100% !important;
        align-items: center;
        justify-content: center;
        display: block !important;
        }
      .navbar-brand {
        align-items: center !important;
        justify-content: center !important;
          }
      }
       /* CSS : Navagation Bar Selesai */
    .sidebar {
      height: 100vh;
      position: fixed;
      left: 0;
      top: 0;
      background-color: #6be6ff;
      padding-top: 70px;
      border-right: 1px solid #ddd;
      font-family: 'poppins';
    }
    .sidebar ul {
      list-style-type: none;
      padding: 0;
    }
    .sidebar ul li a {
      display: block;
      padding: 10px 20px;
      color: #333;
      text-decoration: none;
    }
    .sidebar ul li a:hover, .sidebar ul li a.active {
      background-color: #2bc1c1;
      color: #fff;
    }
    .content {
      margin-left: 250px;
      padding: 20px;
      font-family: 'poppins';
      
    }
    .welcome-message {
      background-color: #a7f2ff;
      color: #0c5460;
      padding: 15px;
      border-radius: 5px;
      margin-bottom: 20px;
      font-weight: bold;
      text-align: center;
      display: flex;
      align-items: center;
      justify-content: center;
      height: 80px;
      font-family: 'poppins';
    }
    .card:hover {
      transform: scale(1.05);
      transition: all 0.3s ease-in-out;
    }
    .table thead {
      background-color: #a7f2ff;
      color: #0c5460;

    }
    .sidebar {
      z-index: 10;
    }
    .navbar {
      z-index: 50;
      
    }
    .navbar-toggler {
      z-index: 100;
    }
    
  </style>
</head>
<body>

    <!-- Navagation Bar -->

    <nav class="navbar navbar-expand-lg">

    <div class="container-fluid">

    <div class="col-2 kolom_logo d-flex justify-content-start">
        <a class="navbar-brand" href="../halaman_beranda/halaman_beranda.php">
            <img src="../img/icon/logo_tokowaju.svg" alt="logo" width="200" height="auto">
        </a>
    </div>

    <div class="col-10 row d-flex justify-content-end kolom_konten">

      
      <div class="col-md-auto kolom_nama d-flex justify-content-end">
        <!-- Nama Pengguna -->
        
        <td>
          <a href="../halaman_list/list_sewa.php" class="base_username" id="username">
            <div class="tulisan">
              <?php echo $data['nama_toko']; ?>
            </div>
          </a>
        </td>
        
      </div>

      <div class="col-md-auto d-flex kolom_keranjang ms-3 p-0">
          <!-- Logo Keranjang -->

          <td>
              <form action="../mysql_database/logout.php" method="post" name="tombol_keranjang">
                  <button style="border: none; background: transparent;" class="base_keranjang" type="submit">
                    <a class="nav-link hover-overlay" href="../mysql_database/logout.php"><i class="fas fa-sign-out-alt fs-3 mt-1" style="color: #fff;"></i></a>
                  </button>
              </form>
          </td>

      </div>
      
        <div class="col-md-auto d-flex kolom_profil ms-5">
            <!-- Foto profil -->

            <td>
                <a href="../halaman_admin/pengaturan.php" class="base_profil">
                  <img src="<?php echo $data['foto_toko']; ?>" style="transform: scale(1.3); aspect-ratio: 1/1; object-fit: cover;" alt="photo_profil" class=" rounded-circle border border-success border-opacity-25 shadow">
                </a>
            </td>
            <style>
              .base_profil:hover, .profil:hover {
                transform: scale(1.3);
                }
            </style>
        </div>

    </div>

    </div>

    </nav>

    <!-- Navagation Bar Selesai -->
  

  <!-- Sidebar -->
  <div class="sidebar">
    <ul class="nav nav-pills flex-column mt-4">
      <li><a href="dashboard.php" class="active" id="menuDashboard"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
      <li><a href="kelola_busana.php" class="active" id="menuKelolaBusana"><i class="fas fa-box"></i> Kelola Busana</a></li>
      <li><a href="pesanan.html" class="active" id="menuPesanan"><i class="fas fa-shopping-cart"></i> Pesanan</a></li>
      <li><a href="pelanggan.html" class="active" id="menuPelanggan"><i class="fas fa-users"></i> Pelanggan</a></li>
      <li><a href="pengaturan.php" class="active" id="menuPengaturan"><i class="fas fa-cogs"></i> Pengaturan</a></li>
    </ul>
  </div>

  <!-- Main Content -->
  <div class="content" padding-top="100px;">
    <!-- Tanda Halaman -->
    <h4><i class="fas fa-tachometer-alt" id="pageTitle" class="mb-4"></i></h4><hr>

    <!-- Pesan Penyambutan -->
    <div class="welcome-message">
      <h3>Selamat Datang <b><?= $data['nama_toko'] ?></b> di Halaman Admin Resmi Kami!</h3>
    </div>

    <!-- Statistik -->
    <div class="row">
      <div class="col-md-3">
        <div class="card bg-info text-white mb-3 stat-card" data-category="Total Busana">
          <div class="card-body">
            <h5 class="card-title">Total Busana</h5>
            <p class="card-text" id="totalBusana"><i class="bi bi-handbag-fill me-2"></i><?= $data['jumlah_produk'] ?></p>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card bg-success text-white mb-3 stat-card" data-category="Pesanan Hari Ini">
          <div class="card-body">
            <h5 class="card-title">Bergabung</h5>
            <p class="card-text" id="pesananHariIni"><i class="bi bi-calendar-heart-fill me-2"></i><?= $data['tanggal_daftar'] ?>, <?= $data['bulan_daftar'] ?> <?= $data['tahun_daftar'] ?></p>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card bg-warning text-white mb-3 stat-card" data-category="Pelanggan Aktif">
          <div class="card-body">
            <h5 class="card-title">Busana Tersewa</h5>
            <p class="card-text" id="pelangganAktif"><i class="bi bi-currency-dollar me-2 "></i></p>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card bg-danger text-white mb-3 stat-card" data-category="Pendapatan Bulan Ini">
          <div class="card-body">
            <h5 class="card-title">Rating Toko</h5>
            <p class="card-text" id="pendapatanBulanIni"><i class="bi bi-star-fill me-2"></i><?= $data['rating_toko'] ?></p>
          </div>
        </div>
      </div>
    </div>

    <?php /* 

    <!-- Tabel Pesanan -->
    <h4>Pesanan Terbaru</h4>
    <div class="table-responsive">
      <table class="table table-bordered">
        <thead>
          <tr>
            <th>No</th>
            <th>Nama Pelanggan</th>
            <th>Nama Busana</th>
            <th>Gambar</th>
            <th>Detail Pesanan</th>
            <th>Tanggal Sewa</th>
            <th>Tanggal Pengembalian</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody id="pesananTable">
          <tr>
            <td>1</td>
            <td>Ani</td>
            <td>Kebaya Modern</td>
            <td><img src="uploads/<?= $data['foto']; ?>" alt="Foto" width="100"></td>
            <td><button class="btn btn-primary btn-sm detail-btn" data-bs-toggle="modal" data-bs-target="#detailModal">Detail</button></td>
            <td>2024-12-20</td>
            <td>2024-12-27</td>
            <td><span class="badge bg-success">Selesai</span></td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Modal for Detail -->
  <div class="modal fade" id="detailModal" tabindex="-1" aria-labelledby="detailModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="detailModalLabel">Detail Pesanan</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <p><strong>Nama Pelanggan:</strong> Ani</p>
          <p><strong>Nama Busana:</strong> Kebaya Modern</p>
          <p><strong>Tanggal Sewa:</strong> 2024-12-20</p>
          <p><strong>Tanggal Pengembalian:</strong> 2024-12-27</p>
          <p><strong>Status:</strong> Selesai</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
        </div>
      </div>
    </div>
  </div>

  */ ?>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>

  <!-- Custom JS -->
  <script>
    // Fungsi untuk mengubah judul halaman berdasarkan menu yang diakses
    const pageTitles = {
      Dashboard: "Dashboard",
      KelolaBusana: "Kelola Busana",
      Pesanan: "Pesanan",
      Pelanggan: "Pelanggan",
      Pengaturan: "Pengaturan"
    };

    const menuActions = {
      Dashboard: () => setPage("Dashboard"),
      KelolaBusana: () => setPage("KelolaBusana"),
      Pesanan: () => setPage("Pesanan"),
      Pelanggan: () => setPage("Pelanggan"),
      Pengaturan: () => setPage("Pengaturan")
    };

    function setPage(menuName) {
      document.getElementById("pageTitle").textContent = pageTitles[menuName];
      document.querySelectorAll('.sidebar ul li a').forEach(link => link.classList.remove('active'));
      document.getElementById(`menu${menuName}`).classList.add('active');
    }

    // Tambahkan event listener pada sidebar menu
    document.getElementById('menuDashboard').addEventListener('click', () => menuActions.Dashboard());
    document.getElementById('menuKelolaBusana').addEventListener('click', () => menuActions.KelolaBusana());
    document.getElementById('menuPesanan').addEventListener('click', () => menuActions.Pesanan());
    document.getElementById('menuPelanggan').addEventListener('click', () => menuActions.Pelanggan());
    document.getElementById('menuPengaturan').addEventListener('click', () => menuActions.Pengaturan());

    // Set halaman default
    setPage("Dashboard");
  </script>
  <?php

    }
          
  }

  else {
    header("Location: ../halaman_masuk_admin/halaman_masuk_admin.php");
  }
      

  ?>
</body>
</html>
 