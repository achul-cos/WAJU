<!DOCTYPE html>

<html lang="en">

<head>

    <!-- PHP -->

      <?php 

      session_start();

      if (isset($_SESSION['id']) && 
          isset($_SESSION['nama_pengguna']) &&
          isset($_SESSION['foto_pengguna'])) {

            $con = mysqli_connect("localhost", "root", "", "waju");

            // Cek koneksi
            if (!$con) {
                die("Koneksi gagal: " . mysqli_connect_error());
            }

            $id = $_SESSION['id'];

            $kueri_update = "SELECT * FROM dataakun WHERE id = '$id'";
            $hasil_kueri_update = mysqli_query($con, $kueri_update);

            // Cek apakah query berhasil
            if (!$hasil_kueri_update) {
              die("Query gagal: " . mysqli_error($con));
            }

            if (mysqli_num_rows($hasil_kueri_update) > 0) {
              $data = mysqli_fetch_assoc($hasil_kueri_update);
            } else {
              echo "<p>Data Tidak Ditemukan</p>";
              exit();
            }
            
            if ($data['status_update'] = 1) {
              $_SESSION['nama_pengguna'] = $data['nama_pengguna'];
              $_SESSION['foto_pengguna'] = $data['foto_pengguna'];
              $esqiuel = "UPDATE dataakun SET status_update = 0 WHERE id = '$id' AND status_update = 1";
              $query = mysqli_query($con, $esqiuel);
            }
    
            // Ambil nama_baju dari URL
            if (isset($_SESSION['id'])) 
              {
                $id_pengguna = $_SESSION['id'];
    
                // Query untuk mengambil data produk berdasarkan nama_baju
                $kueri_pengguna = "SELECT * FROM dataakun WHERE id = '$id_pengguna'"; 
                $hasil_kueri = mysqli_query($con, $kueri_pengguna);
    
                // Cek apakah query berhasil
                if (!$hasil_kueri) {
                    die("Query gagal: " . mysqli_error($con));
                }
    
                $data_pengguna = mysqli_fetch_assoc($hasil_kueri);    
    
              } else {
                  echo "<p>Pengguna Tidak Di Temukan</p>";
                  exit();
                }

          if ($_SERVER['REQUEST_METHOD'] == 'POST') {
              // Proses data form di sini
              // Misalnya, simpan data ke database atau lakukan tindakan lain
      
              // Setelah memproses, alihkan ke halaman yang sama
              header("Location: " . $_SERVER['PHP_SELF']);
              exit(); // Pastikan untuk keluar setelah mengalihkan
          }
      ?>

    <!-- PHP Selesai -->

    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?= $_SESSION['nama_pengguna'] ?> - Pengaturan</title>
    <link crossorigin="anonymous" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" rel="stylesheet"/>
  
    <!-- Custom Font "Poppins" -->

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0&icon_names=check" />

    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Material+Icons">
    <link rel="stylesheet" href="https://unpkg.com/bootstrap-material-design@4.1.1/dist/css/bootstrap-material-design.min.css" integrity="sha384-wXznGJNEXNG1NFsbm0ugrLFMQPWswR3lds2VeinahP8N0zJw9VWSopbjv2x7WCvX" crossorigin="anonymous">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons">    

    <!-- Menggunakan Bootstrap CSS dari file lokal -->
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://code.iconify.design/3/3.1.0/iconify.min.js"></script>
    
    <!-- Logo Tab -->

    <link rel="icon" type="image/x-icon" href="../img/icon/logo_atas.svg">

</head>

<body>

  <!-- Internal CSS -->

    <style>

      /* Reset standar untuk semua elemen */

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: "Poppins", sans-serif;
        }
      
      /* Gaya background halaman */
        body {
          background: rgb(217,233,233);
          background: radial-gradient(circle, rgba(217,233,233,1) 3%, rgba(224,237,227,1) 100%);
        }

      /* CSS : Navagation Bar */
        .navbar {
          background-image: url(../img/icon/navbar.png);
          background-size: cover;
          border-bottom-left-radius: 20em 28em;
          border-bottom-right-radius: 20em 28em;
          height: 80px;
          box-shadow: 0 0 100px rgba(0, 0, 0, 0.325);
        }

        /* Styling untuk brand navbar */
        .navbar-brand {
          display: flex;
          justify-content: center;
          padding: 0px 0px 0% 0px !important;
          margin: 0px 5px 0px 0px !important;
          transition: 0.5s;
        }

        .navbar-brand:hover {
          filter:invert(100%) !important;
          opacity: 0.7;
        }

        /* Tombol Pencarian */
        .tombol_pencarian {
          display: block;
          width: 50px;
          height: auto;
          margin: 0 0 0 0;
          border: 1px solid rgba(14, 89, 129, 0.178);
          border-radius: 20px;
          box-shadow: 0 0 20px rgba(0, 0, 0, 0.05); 
          background: rgb(166, 214, 239) url(../img/icon/icon_cari.svg) no-repeat center / 25% !important; /* Menggabungkan properti background */
          transition: 0.1s;
        }
   
        .tombol_pencarian:hover{
          border: none !important;
          filter:invert(20%) !important;
        }

        .tombol_pencarian:active{
          background-size: 50% !important;
        }

        .bar_pencarian {
          color: rgba(91, 91, 91, 0.57);            
          border: 1px solid rgba(14, 89, 129, 0.178);
          border-radius: 20px;
          box-shadow: 0 0 20px rgba(0, 0, 0, 0.05); 
          text-indent: 12px;
          letter-spacing: 1px;
          transition: 0.3s;
        }

        .bar_pencarian input:focus,
        .bar_pencarian input:hover {
          color: #00282b;
          border: 1.5px solid #00282b;
        }

        /* Gaya untuk tombol keranjang */
        .base_keranjang, .keranjang {
          margin: auto;
          width: 30px ;
          height: 30px ;
          display: block;
          transition: 0.3s;
          transition: 0.3s;
          justify-content: center; 
          align-items: center; 
        }
      
        .keranjang:hover {
          transform: scale(1.2);
        }

        .keranjang:active {
          animation: beat 0.3s alternate;
          transform-origin: center;
        } 
      
        @keyframes beat{
          to { transform: scale(1.4); }
        }

        /* Gaya untuk nama pengguna */
        .base_username {
          margin: auto;
          width: auto;
          display: inline-flex; 
          justify-content: center; 
          align-items: center; 
          border: 1.5px solid #f2f2f2;
          border-radius: 25px;
          color: #ffffff;
          font-family: "Poppins", sans-serif;
          letter-spacing: 1px;
          padding: 5px 12px;
          font-weight: 600;
          text-decoration: none;
          transition: 0.3s; 
        }

        .tulisan {
          overflow: hidden; 
          white-space: nowrap !important; 
          text-overflow: ellipsis !important; 
          max-width: calc(8vw) !important; 
          width: auto;
          text-align: center;
        }


        .base_username:hover {
          background-color: #f2f2f2;
          color: rgb(39, 74, 94);
          text-decoration :none;
        }
          
        /* Profil dan pengaturan gaya flex */
        .base_profil, .profil {
          margin: auto;
          width: auto ;
          height: 30px ;
          display: flex;
          z-index: 110;
          transition: 0.3s;
          padding-right: 30;
          transition: 0.3s;
          right: 0;   
        }

        .profil:active {
          animation: beat 0.3s alternate;
          transform-origin: center;
        } 

        /* Container dan pengaturan lebar */
        .container-fluid {
          max-width: 95% !important;
        }

        /* Responsif untuk ukuran layar */
          @media (max-width: 1245px) {
        .kolom_profil {
          display: none !important;
          }

        .kolom_logo,
        .kolom_pencarian {
          margin-left: 30px;
          }
        }

          @media (max-width: 992px) {
        .kolom_logo {
          margin: 0 0 0 50px;
          }
        .kolom_pencarian {
          margin: auto;
          max-width: 60vw;
          }
        .kolom_keranjang {
          display: none !important;
          }
        .kolom_nama {
          display: none;
          }
        .kolom_profil {
          display: flex !important;
          }
        .kolom_konten {
          width: auto !important;
          margin: 0 0 0 30px;
          }
        }

          @media (max-width: 741px) {
        .kolom_konten {
          display: none !important;
          }
        .kolom_logo {
          width: 20vw !important;
          }
        .kolom_pencarian {
          width: 60vw !important;
          }
        }

          @media (max-width: 540.98px) {
        .kolom_pencarian {
          display: none;
          }
        .kolom_logo {
          margin: 0 0 0 0 !important;
          width: 100% !important;
          align-items: center;
          justify-content: center;
          display: block !important;
          }
        .navbar-brand {
          align-items: center !important;
          justify-content: center !important;
            }
        }
      /* CSS : Navagation Bar Selesai */
      /* CSS : Sidebar */

        .card {
          border: 1px solid #ddd;
          box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
          border-radius: 14px; /* Border-radius set to 12px */
          cursor: pointer; /* Makes the cursor a pointer */
          transition: all 0.2s ease; /* Smooth transition for hover effects */
        }

        .list-group {
          border-radius: 12px; 
        }

        .card-body img {
          border-radius: 50%;
          width: 100px;
          height: 100px;
        }

        .username {
          font-size: 18px; /* Adjust the font size as needed */
          color: #333; /* Text color (dark gray or black) */
          font-weight: bold; /* Make the username bold by default */
          cursor: pointer; /* Makes the username look clickable */
          transition: color 0.3s, font-weight 0.3s; /* Smooth transition for color and boldness */
        }

        /* Gaya ketika nama pengguna diklik */
        .username.tapped {
          color: #007bff; /* Change text color to blue when tapped */
          font-weight: normal; /* Remove bold when tapped */
        }

        /* Gaya saat item dalam grup daftar di-hover */
        .list-group-item:hover {
          box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
          border: none;
          background-color: #e9ecef; /* Latar berubah saat di-hover */
        }

        /* Menghapus border pada item grup list dengan class 'no-border' */
        .no-border .list-group-item {
          border: none;
        }

        /* Menghapus pointer untuk item tertentu (Profil Saya dan Informasi Sewaan) */
        .list-group-item.no-pointer {
          pointer-events: none;
          cursor: default; 
        }

        /* Opsional: Menghapus efek hover */
        .list-group-item.no-pointer:hover {
          background-color: transparent; 
        }

        /* Gaya saat item grup daftar ditekan (active state) */
        .list-group-item:active {
          background-color: #007bff; 
          color: #fff; 
          box-shadow: 0 0 10px #007bff; 
          transform: scale(0.95); 
        }
          
      /* CSS : Sidebar Selesai */
      /* CSS : isi */

        /* Gaya untuk kontainer form */
        .form-container {
          background-color: white;
          border-radius: 10px;
          padding: 60px;
          box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        /* Gaya untuk gambar dalam kontainer form (ikon) */
        .form-container img {
          border-radius: 50%;
          width: 100px;
          height: 100px;
        }

        /* Gaya untuk tombol khusus dalam form */
        .form-container .btn-custom {
          background-color: #a5dfbc;
          color: black;
          font-weight: bold;
        }

        /* Gaya untuk tombol sekunder khusus dalam form */
        .form-container .btn-secondary-custom {
          background-color: #a5dfbc;
          color: black;
          border: none;
          font-weight: bold;
        }

        /* Gaya untuk label form */
        .form-container .form-label {
          width: 100px;
        }

        .hover-overlay{
          transition: 0.3s;
        }
        .hover-overlay:hover {
          transform: scale(1.1);
        }

        /* Input telepon */

          .input-telepon {
              /* Anda bisa menambahkan gaya untuk .input-telepon di sini jika diperlukan */
          }

          .input-telepon .select-box {
              position: relative;
          }

          .input-telepon .select-box input {
              width: 100%;
              padding: 1rem .6rem;
              font-size: 1.1rem;
              
              border: 0.5px solid rgba(0, 0, 0, 0 .4);
              outline: none;
          }

          .input-telepon input[type="tel"] {
              border-radius: 0 .5rem .5rem 0;
          }

          .input-telepon .select-box input:focus {
              border: .1rem solid var(--primary);
          }

          .input-telepon .selected-option {
              background-color: #eee;
              border-radius: .5rem;
              overflow: hidden;

              display: flex;
              justify-content: space-between;
              align-items: center;
          }

          .input-telepon .selected-option div {
              position: relative;

              width: 6rem;
              padding: 0 2.8rem 0 .5rem;
              text-align: center;
              cursor: pointer;
          }

          .input-telepon .selected-option div::after {
              position: absolute;
              content: "";
              right: .8rem;
              top: 50%;
              transform: translateY(-50%) rotate(45deg);
              
              width: .8rem;
              height: .8rem;
              border-right: .12rem solid var(--primary);
              border-bottom: .12rem solid var(--primary);

              transition: .2s;
          }

          .input-telepon .selected-option div.active::after {
              transform: translateY(-50%) rotate(225deg);
          }

          .input-telepon .select-box .options {
              position: absolute;
              top: 4rem;
              
              width: 100%;
              background-color: #fff;
              border-radius: .5rem;

              display: none;
          }

          .input-telepon .select-box .options.active {
              display: block;
              z-index: 100;
          }

          .input-telepon .select-box .options::before {
              position: absolute;
              content: "";
              left: 1rem;
              top: -1.2rem;
              display: none;
              width: 0;
              height: 0;
              border: .6rem solid transparent;
              border-bottom-color: var(--primary);
          }

          .input-telepon input.search-box {
              background: rgb(16,181,212); 
              background: linear-gradient(90deg, rgba(16,181,212,1) 0%, rgba(110,227,202,1) 100%);
              color: #eee;
              border-radius: .5rem .5rem 0 0;
              padding: 1.4rem 1rem;
              border: none;
              font-weight: bold;
          }

          .input-telepon input.search-box::placeholder {
            color : #eee;
            opacity: 70%;
          }

          .input-telepon .select-box ol {
              list-style: none;
              max-height: 23rem;
              overflow: overlay;
          }

          .input-telepon .select-box ol::-webkit-scrollbar {
              width: 0.6rem;
          }

          .input-telepon .select-box ol::-webkit-scrollbar-thumb {
              width: 0.4rem;
              height: 3rem;
              background-color: #ccc;
              border-radius: .4rem;
          }

          .input-telepon .select-box ol li {
              padding: 1rem;
              display: flex;
              justify-content: space-between;
              cursor: pointer;
          }

          .input-telepon .select-box ol li.hide {
              display: none;
          }

          .input-telepon .select-box ol li:not(:last-child) {
              border-bottom: .1rem solid #eee;
          }

          .input-telepon .select-box ol li:hover {
              background-color: lightcyan;
          }

          .input-telepon .select-box ol li .country-name {
              margin-left: .4rem;
          }

        /* Css Input Telepon Selesai */

        /* Modal styles */
        .modal {
          display: none; 
          position: fixed;
          z-index: 1;
          left: 0;
          top: 0;
          width: 100%;
          height: 100%;
          overflow: auto;
          background-color: rgba(0, 0, 0, 0.4);
          padding-top: 60px;
        }
        .modal-content {
          background-color: #f2f2f2;
          margin: 5% auto;
          padding: 20px;
          border: 1px solid #888;
          width: 80%;
          max-width: 300px;
          text-align: center;
          border-radius: 10px;
          box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        /* Gaya untuk tombol close (X) di bawah teks */
        .close {
          position: absolute;
          bottom: -30px; 
          left: 50%;
          transform: translateX(-50%); 
          font-size: 40px;
          color: white; 
          background-color: black; 
          width: 40px;
          height: 40px; 
          border-radius: 50%; 
          display: flex;
          justify-content: center; 
          align-items: center; 
          cursor: pointer;
        }
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }
        .close:hover,
        .close:focus {S
            color: black;
            text-decoration: none;
            cursor: pointer;
        }
      
        /* CSS : isi */

    </style>

  <!-- Internal CSS Selesai -->

  <!--------------------------------------------------------------------------------------------->

  <!-- Navagation Bar -->

    <nav class="navbar navbar-expand-lg">

    <div class="container-fluid">

    <div class="col-2 kolom_logo">
        <a class="navbar-brand" href="../halaman_beranda/halaman_beranda.php">
            <img src="../img/icon/logo2.png" alt="logo" width="auto" height="auto">
        </a>
    </div>

    <div class="col-7 kolom_pencarian">
        <!-- Bar Pencarian -->
        <form class="d-flex" style="padding-left: 20px;" action="../halaman_pencarian/halaman_pencarian.php" method="get">
            <input class="bar_pencarian form-control me-2" name="pencarian" value="<?php if(isset($_GET['pencarian'])){echo $_GET['pencarian'];} ?>" type="search" placeholder="Hari ini mau keren yang mana?" aria-label="Search" required maxlength="60" oninvalid="this.setCustomValidity('Isi dong, mau nyari apa kalau kosong.')" oninput="setCustomValidity('')">
            <button class="tombol_pencarian btn btn-outline-success" type="submit"></button>
        </form>
    </div>

    <div class="col-3 row d-flex justify-content-center kolom_konten">

        <div class="col-auto d-flex kolom_keranjang">
            <!-- Logo Keranjang -->

            <td>
                <form action="../halaman_keranjang/halaman_keranjang.php" method="post" name="tombol_keranjang">
                    <button style="border: none; background: transparent;" class="base_keranjang" type="submit">
                        <img src="..\img\icon\icon_keranjang.svg" alt="keranjang" class="keranjang">
                    </button>
                </form>
            </td>

        </div>

        <div class="col-md-6 kolom_nama d-flex">
            <!-- Nama Pengguna -->

            <td>
                <a href="../halaman_list/list_sewa.php" class="base_username" id="username">
                    <div class="tulisan">
                        <?php echo $_SESSION['nama_pengguna']; ?>
                    </div>
                </a>
            </td>

        </div>

        <div class="col-auto d-flex kolom_profil">
            <!-- Foto profil -->

            <td>
                <a href="../halaman_list/list_sewa.php" class="base_profil">
                <img src="<?php if($_SESSION['foto_pengguna'] == NULL) {echo "..\img\icon\profile.jpg";} else{echo $_SESSION['foto_pengguna'];}?>" style="transform: scale(1.3); aspect-ratio: 1/1; object-fit: cover;" alt="photo_profil" class="profil rounded-circle border border-success border-opacity-25 shadow">
                </a>
            </td>
            <style>
              .base_profil:hover, .profil:hover {
                transform: scale(1.3);
                }
            </style>
        </div>

    </div>

    </div>

    </nav>

  <!-- Navagation Bar Selesai -->
  
  <!--------------------------------------------------------------------------------------------->
  
  <!-- Isi Website -->

    <div class="isi" style="padding-bottom: 160px;">

        <div class="container-fluid row d-flex justify-content-center align-items-start m-0 p-0" style="width: 100% !important;">

          <!-- Sidebar -->

          <div class="col-lg-3 mt-5">

            <!-- Card untuk profil pengguna -->
            <div class="card">
              <div class="card-body text-center p-1">
                <img alt="Foto Profil" class="rounded-circle my-3 shadow-lg" height="100" id="sidebar-profile-image" src="<?php if($data_pengguna['foto_pengguna'] == NULL) {echo "..\img\icon\profile.jpg";} else{echo $data_pengguna['foto_pengguna'];}?>" width="100" style="aspect-ratio: 1/1; object-fit: cover;"/>
                <p class="username"><?= $_SESSION['nama_pengguna'] ?></p>
              </div>
            </div>

            <!-- Daftar menu di sidebar -->

            <div class="card mt-3">
              <div class="card-body">
                <div class="container row d-flex"> <!-- Profil Saya -->
                  <div class="col-2 d-flex align-items-start mr-2 py-2">
                    <i class="fas fa-user hover-overlay fs-6 mb-1 mt-1 ml-1"></i>
                  </div>
                  <div class="col-8 list-group">
                      <a href="../halaman_pengaturan_user/halaman_pengaturan_user.php" class="text-decoration-none text-dark fw-bold fs-6 hover-overlay mb-1">Profil Saya</a>
                      <a href="../halaman_pengaturan_user/halaman_pengaturan_user.php" class="text-decoration-none text-dark fw-normal fs-6 hover-overlay mb-1">Pengaturan Akun</a>
                      <a href="../halaman_pengaturan_user/halaman_pengaturan_user.php" class="text-decoration-none text-dark fw-normal fs-6 hover-overlay mb-1">Ganti Password</a>
                  </div>
                </div>

                <div class="container row d-flex mt-2"> <!-- Informasi Sewaan -->
                  <div class="col-2 d-flex align-items-start py-2 mr-2">
                    <img class="hover-overlay" src="..\img\icon\info.png" alt="Info" style="width: 20px; height: 20px; object-fit: cover;">
                  </div>
                  <div class="col-8 list-group">
                      <a href="../halaman_list/list_sewa.php" class="text-decoration-none text-dark fw-bold fs-6 hover-overlay mb-1">Informasi Sewaan</a>
                      <a href="../halaman_list/list_sewa.php" class="text-decoration-none text-dark fw-normal fs-6 hover-overlay mb-1">List Sewa</a>
                      <a href="../halaman_list/waktu_penyewaan.php" class="text-decoration-none text-dark fw-normal fs-6 hover-overlay mb-1">Waktu Penyewaan</a>
                      <a href="../halaman_list/riwayat_penyewaan.php" class="text-decoration-none text-dark fw-normal fs-6 hover-overlay mb-1">Riwayat Penyewaan</a>
                      <a href="../halaman_list/denda.php" class="text-decoration-none text-dark fw-normal fs-6 hover-overlay mb-1">Denda</a>
                  </div>
                </div>
              </div>

            </div>
                
          </div> 

          <!---- Sidebar selesai ------>

          <!-- Form Pengguna -->

          <div class="col-lg-8 mt-5">

            <div class="form-container container row d-flex p-8">
              <form class="d-flex" method="post" action="../mysql_database/update_data_pengguna.php" enctype="multipart/form-data">
                <input type="hidden" name="id_pengguna" value="<?php echo $data_pengguna['id']; ?>">
                <input type="hidden" name="nama_pengguna_lama" value="<?php echo $_SESSION['nama_pengguna']; ?>">
                <div class="col-md-8">
                  <!-- Input Nama -->
                  <div class="mb-3">
                    <div class="container row d-flex p-0">
                      <div class="col-md-3 p-0">
                        <label class="form-label" for="nama">Nama</label>
                      </div>
                      <div class="col-md-9 p-0">
                        <input class="form-control" name="nama_pengguna" id="nama_pengguna" type="text" placeholder="Nama Anda..." style="font-style: italic;" value="<?= $data_pengguna['nama_pengguna'] ?>" autocapitalize="none" required/>
                      </div>
                    </div>
                  </div>

                  <!-- Input NIK -->
                  <div class="mb-3">
                    <div class="container row d-flex p-0">
                      <div class="col-md-3 p-0">
                        <label class="form-label" for="nik">NIK</label>
                      </div>
                      <div class="col-md-9 p-0">
                        <input class="form-control" name="nik_pengguna" id="nik" type="text" minlength="16" maxlength="16" inputmode="numeric" placeholder="16-Digit NIK..." style="font-style: italic;" value="<?= $data_pengguna['nik_pengguna'] ?>" required />
                      </div>
                    </div>
                  </div>                

                  <!-- Input Email -->
                  <div class="mb-3">
                    <div class="container row d-flex p-0">
                      <div class="col-md-3 p-0">
                        <label class="form-label" for="email">Email</label>
                      </div>
                      <div class="col-md-9 p-0">
                        <input class="form-control" name="email_pengguna" id="email" type="email" placeholder="Email Anda..." style="font-style: italic;" value="<?= $data_pengguna['email'] ?>" required/>
                      </div>
                    </div>  
                  </div>

                  <!-- Input No. Telepon -->
                  <div class="mb-3">
                    <div class="container row d-flex p-0">
                      <div class="col-md-3 p-0 d-flex align-items-center">
                        <label class="form-label" for="telepon">No. Telepon</label>
                      </div>
                      <div class="col-md-9 p-0 input-telepon">
                        <!-- <input class="form-control" id="telepon" type="text" style="font-style: italic;" placeholder="Nomor Telepon Anda..." style="font-style: italic;" value="" required/> -->
                      
                        <div class="select-box">
                          <div class="selected-option">
                              <div class="d-flex align-items-center" style="width: 150px; gap: 5px;">
                                  <span class="iconify" data-icon="flag:id-4x3"></span>
                                  <strong>+62</strong>
                              </div>
                              <input class="shadow-lg" type="tel" inputmode="numeric" minlength="12" maxlength="17" onkeypress="return numbersonly(this, event)" name="nomor_telepon" placeholder="Nomor Telepon Anda.." value="<?php if ($data_pengguna['nomor_telepon'] == NULL) {echo "+62";} else {echo $data_pengguna['nomor_telepon'];}   ?>">
                          </div>
                          <div class="options">
                              <input type="text" class="search-box" placeholder="Kode Telepon Negara...">
                              <ol class="shadow-lg">

                              </ol>
                          </div>
                        </div>
                        <script src="script.js"></script>
                      </div>
                    </div>  
                  </div>

                  <!-- Input Alamat -->
                  <div class="mb-3">
                    <div class="container row d-flex p-0">
                      <div class="col-md-3 p-0">
                        <label class="form-label" for="alamat">Alamat</label>
                      </div>
                      <div class="col-md-9 p-0">
                        <input class="form-control" name="alamat_pengguna" id="alamat" type="text" placeholder="Alamat Anda..." style="font-style: italic;" value="<?= $data_pengguna['alamat_pengguna'] ?>" required/>
                      </div>
                    </div>  
                  </div>

                  <div class="d-flex justify-content-end mt-5 mr-2">
                    <button class="btn btn-secondary-custom me-2" type="button">GANTI PASSWORD</button>
                    <button class="btn btn-custom" type="submit">SIMPAN</button>
                  </div>

                </div>

                <div class="col-md-4 text-center">

                  <div class="col d-flex justify-content-center align-item-center p-0">
                    <!-- Gambar Profil -->
                    <img class="mb-3 shadow-lg" alt="Foto Profil" height="100" id="profile-image" src="<?php if($data_pengguna['foto_pengguna'] == NULL) {echo "..\img\icon\profile.jpg";} else{echo $data_pengguna['foto_pengguna'];}?>" width="100" style="aspect-ratio: 1/1; object-fit: cover;">
                  </div>

                  <div class="col d-flex justify-content-center align-item-center p-0">
                    <!-- Tombol Pilih Gambar -->
                    <button class="btn btn-outline-secondary mt-2" onclick="document.getElementById('upload_pp_pengguna').click();" type="button">
                      Pilih Gambar
                    </button>
                  </div>

                  <div class="col d-flex justify-content-center align-item-center p-0">
                    <!-- Input file yang disembunyikan -->
                    <input name="foto_pengguna" accept=".jpg, .jpeg, .png, <?php if($data_pengguna['status_admin'] == 1){echo ".gif";} ?>" id="upload_pp_pengguna" name="upload_pp_pengguna" onchange="previewImage(event)" style="display: none;" type="file"/>
                  </div>

                  <div class="col d-flex justify-content-center align-item-center p-0">
                    <!-- Keterangan Gambar -->
                    <p class="mt-2" style="font-size: 12px; color: #6c757d;">
                      Rasio Foto 1:1
                    <br/>
                      Ukuran gambar: maks. 1 MB
                    <br/>
                      Format gambar: JPG, JPEG, PNG<?php if($data_pengguna['status_admin'] == 1){echo ", GIF";} ?>.
                    </p>
                  </div>

                </div>

                
              </form>
            </div>
          </div> 
        </div>

    </div>  
  
  <!-- Isi Website Selesai -->

  <!--------------------------------------------------------------------------------------------->

  <!-- Footer -->

    <link rel="stylesheet" href="..\footer\footer.css">

    <?php

      // Koneksi ke database
      $con = mysqli_connect("localhost", "root", "", "waju");

      // Cek koneksi
      if (!$con) {
          die("Koneksi gagal: " . mysqli_connect_error());
      }

      $query = "SELECT * FROM footer"; // Menggunakan nama_baju
      $result = mysqli_query($con, $query);

      $footer = mysqli_fetch_assoc($result);
      
      echo $footer['footer'];

    ?>

  <!-- Footer Selesai -->

  <!--------------------------------------------------------------------------------------------->

  <!-- Script Session -->

    <script>
      // Fungsi untuk menampilkan gambar yang dipilih
            function previewImage(event) {
                const reader = new FileReader();
                reader.onload = function(){
                    const output = document.getElementById('profile-image');
                    const sidebarOutput = document.getElementById('sidebar-profile-image');
                    output.src = reader.result;
                    sidebarOutput.src = reader.result;
                };
                reader.readAsDataURL(event.target.files[0]);
            }
    </script>

    <!-- Penyertaan skrip Bootstrap untuk interaktivitas -->

      <script src="./Product Page_files/popper.min.js.download"></script>
      <script src="./Product Page_files/bootstrap.min.js.download"></script>

    <!-- Penyertaan skrip Bootstrap untuk interaktivitas Selesai -->

    <script>
      function numbersonly(myfield, e)
            {
                var key;
                var keychar;

                if (window.event)
                    key = window.event.keyCode;
                else if (e)
                    key = e.which;
                else
                    return true;

                keychar = String.fromCharCode(key);

                // control keys
                if ((key==null) || (key==0) || (key==8) || (key==9) || (key==13) || (key==27) )
                    return true;

                // numbers
                else if ((("0123456789").indexOf(keychar) > -1))
                    return true;

                // only one decimal point
                else if ((keychar == "."))
                {
                    if (myfield.value.indexOf(keychar) > -1)
                        return false;
                }
                else
                    return false;
            }


    </script>

    <script>

      document.addEventListener('DOMContentLoaded', function() {
        var usernameInput = document.getElementById('nama_pengguna');

        usernameInput.addEventListener('input', function(e) {
          var start = this.selectionStart;
          var end = this.selectionEnd;

          // Convert text to lowercase
          this.value = this.value.toLowerCase();

          // Restore the selection range
          this.setSelectionRange(start, end);
        });
      });

    </script>

    <script src="..\bootstrap\js\bootstrap.min.js"></script>

  <!-- Script Session Selesai -->

  <!-- PHP Akhir -->

    <?php 
        

      }
        
        else{
            header("Location: ../halaman_utama/halaman_utama.html");
            exit();
        }

        ?>

  <!--  PHP Selesai -->

</body>
</html>