<!DOCTYPE html>

<html lang="en">

    <head>

        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Daftar Admin WA! JU!</title>
        <link rel="stylesheet" href="halaman_daftar_admin.css">

        <!-- Custom font "Poppins" -->

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

        <!-- Icon & Bootstrap -->

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

        <!-- Logo Tab -->

        <link rel="icon" type="image/x-icon" href="../img/icon/logo_atas.svg">

        <style>

        *	{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: "Poppins", sans-serif;
            line-height: 1.6;
            padding-top: 70px;
            caret-color: transparent;
            background-image: url(../img/foto/bg_baru.svg);
            background-size: cover;
            background-repeat: no-repeat;
        }


        br {
            -webkit-user-select: none;
            /* Chrome, Opera */
            -webkit-touch-callout: none;
            /* Safari */
            -moz-user-select: none;
            /* Firefox */
            -ms-user-select: none;
            /* Internet Explorer/Edge */
            user-select: none;
            /* Standard property */
        }

        .navbar {
            background-image: url(../img/icon/navbar.png);
            background-size: cover;
            width: 104%;
            height: 100px;
            display: block;
            justify-content: space-between;
            align-items: center;
            position: fixed;
            border-bottom-left-radius: 20em 28em;
            border-bottom-right-radius: 20em 28em;
            margin-left: -2%;
            margin-right: 0;
            padding: 1rem 0;
            top: 0;
            left: 0;
            box-shadow: 0 0 100px rgba(0, 0, 0, 0.325);
            z-index: 100;
        }

        .navbar .container {
            display: flex;
            justify-content: space-between; 
            align-items: center;
            max-width: 100%;
        }

        .navbar .container a {
            margin-left: 50px ;
        }

        .logo {
            width: 250px;
            margin: none;
            object-fit: cover;
            display: block;
            transition: 0.3s;
            padding-right: 10px;
        }

        .slogan {
            text-decoration: none;
            margin: auto;
            width: 3000px;
            padding-left: 20px;
            letter-spacing: 3px;
            color: white;
        }

        .navbar .container .logo:hover {
            filter:invert(100%) !important;
            opacity: 0.7;
        }

        .navbar .masuk-daftar {
            margin-top: 0;
            margin-right: 5%;
        }

        .masuk {
                background-color: #f2f2f2; 
                color: #a6a6a6;
                padding: 10px 20px;
                text-decoration: none;
                border-radius: 30px;
                font-size: 1.1rem;
                /*margin-right: 5%;*/
                /*margin-top: -2%;*/
                transition: 0.3s;
        }

        .masuk:hover {
            filter:invert(100%) !important;
            opacity: 0.7;
        }

        .daftar {
            background-color: none;
            border: 2px #f2f2f2 solid; 
            color: #f2f2f2;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 30px;
            font-size: 1.1rem;
            /*margin-right: 20%;*/
            /*margin-top: -4%;*/
            transition: 0.3s;
        }

        .daftar:hover {
        filter:invert(100%) !important;
        opacity: 0.7;
        }

        @media (max-width: 792px) {
            .slogan {
                display: none;
            }
        }

        /* Container utama */
        .isi {
            display: flex;
            justify-content: center;
            align-items: center;

        }

        body {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            /* background: radial-gradient(circle, rgba(180,214,184,1) 0%, rgba(166,214,239,1) 100%); */
            background-image: url(../img/foto/bg_baru.svg);
            background-size: cover;
            background-repeat: no-repeat;
        }

        /* Kotak login */
        .registrasi-box {
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 350px;
            text-align: center;
        }

        /* Header bagian login */
        .registrasi-header header {
            font-size: 40px;
            font-weight: 600;
            color: #ffffff;
        }

        /* Kotak input */
        .input-box {
            margin-bottom: 10px;
        }

        .input-field {
            border-radius: 30px;
            padding: 10px;
            height: 60px;
            width: 100%;
            background: #f2f2f2;
            border: 2px solid #437894;
            text-indent: 6px;
            margin-top: 10px;
            box-sizing: border-box;
            transition: 0.3s;
        }

        .input-field:focus {
            outline: none;
            transform: scale(120%);
            border-color: #8fa9b8;
        }

        ::placeholder {
            font-weight: 500;
            color: #3c3a3a;
            font-family: "Poppins", sans-serif;
        }

        /* Tombol submit */
        .Input-submit {
            font-weight: bold;
            color: black;
        }
        .submit-btn {
            border-radius: 30px;
            height: 60px;
            width: 100%;
            border: 2px solid #437894;
            background:  radial-gradient(circle, rgba(166,193,223,1) 43%, rgba(207,219,211,1) 100%);
            font-weight: bold;
            font-size: 16px;
            cursor: pointer;
            transition: .3s;
            text-align: center;
            font-size: 19px;

        }

        .submit-btn:hover {
            background: #190ee3;
            transform: scale(1.05,1);
        }


        /* Pembuatan Akun */
        .Input-submit p {
            margin-top: 20px;
            font-size: 14px;
            color: #3a3838;
        }

        a:hover{
            text-decoration: underline;
            color: #4000ff;
        }


        </style>

    </head>

    <body>
        
    <!-- Navigation Bar --> <!------------------------------------------------------------------------------->

        <nav class="navbar">
            <div class="container">

            <!-- Logo -->

               <a href="..\halaman_utama\halaman_utama.html"> 
                 <img src="../img/icon/logo_tokowaju.svg" alt="logo" class="logo">
                </a>

            <!------------------------------------------------>

            <!-- Slogan -->

                <p class="slogan">
                    Gabung Toko WA!JU! Sekarang Juga!
                </p>

                <style>

                    @media (max-width: 792px) {
                            .slogan {
                                display: none !important;
                            }
                        }

                </style>

            <!------------------------------------------------>

            <!-- Tombol Daftar & Masuk -->

                <div class="masuk-daftar"> 
                    <table>
                        <tr>
                            <td style="padding-left: 10%;"><a href="..\halaman_daftar_admin\halaman_daftar_admin.php" class="daftar" style="font-weight: bold;">DAFTAR</a></td>
                            <td><a href="..\halaman_masuk_admin\halaman_masuk_admin.php" class="masuk" style="font-weight: bold;">MASUK</a></td>
                        </tr>
                     </table>   

                </div>
            </div>

             <!------------------------------------------------>
             
        </nav>

    <!-- Navigation Bar Selesai --> <!------------------------------------------------------------------------------->

        <!-- Isi Website -->

        <div class="isi" style="padding-top: 70px; margin: 0; vertical-align: middle; width: 100%; text-align: center;">

            <!--- Judul -->

            <div class="Registrasi-box">
                <div class="registrasi-header">
                    <header>Daftar Toko WA!JU!</header>
            
                    <!-- Slogan -->

                    <p>
                        Gabung dengan Komunitas Penyewaan Busana Terbesar.
                    </p>
                    
                </div>

                     <!-- Data diri -->

                <form method="post" action="../mysql_database/signup_admin.php">

                    <?php if (isset($_GET['error'])) {
                        
                        echo <<<GFG
                        <div class="alert">
                            <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span>
                            <p style="font-size: 12px;">
                            Nama Toko telah digunakan, silahkan gunakan Nama Toko lain.
                            </p>
                        </div>

                        <style>
                        /* The alert message box */
                        .alert {
                        padding: 12px;
                        background-color: #f44336; /* Red */
                        color: white;
                        margin-bottom: 15px;
                        }

                        /* The close button */
                        .closebtn {
                        margin-left: 15px;
                        color: white;
                        font-weight: bold;
                        float: right;
                        font-size: 22px;
                        line-height: 20px;
                        cursor: pointer;
                        transition: 0.3s;
                        }

                        /* When moving the mouse over the close button */
                        .closebtn:hover {
                        color: black;
                        }
                        </style>

                        <style>
                        .alert {
                        opacity: 1;
                        transition: opacity 0.6s; /* 600ms to fade out */
                        }
                        </style>

                        <script>
                        // Get all elements with class="closebtn"
                        var close = document.getElementsByClassName("closebtn");
                        var i;

                        // Loop through all close buttons
                        for (i = 0; i < close.length; i++) {
                        // When someone clicks on a close button
                        close[i].onclick = function(){

                            // Get the parent of <span class="closebtn"> (<div class="alert">)
                            var div = this.parentElement;

                            // Set the opacity of div to 0 (transparent)
                            div.style.opacity = "0";

                            // Hide the div after 600ms (the same amount of milliseconds it takes to fade out)
                            setTimeout(function(){ div.style.display = "none"; }, 600);
                        }
                        }
                        </script>
                        GFG;

                    } ?>

                    <?php if (isset($_GET['success'])) {
                        
                        echo <<<GFG
                        <div class="alert">
                            <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span>
                            <p style="font-size: 14px;">Akun Toko telah berhasil dibuat.</p>
                        </div>

                        <style>
                        /* The alert message box */
                        .alert {
                        padding: 20px;
                        background-color: #00d876; /* Green */
                        color: white;
                        margin-bottom: 15px;
                        }

                        /* The close button */
                        .closebtn {
                        margin-left: 15px;
                        color: white;
                        font-weight: bold;
                        float: right;
                        font-size: 22px;
                        line-height: 20px;
                        cursor: pointer;
                        transition: 0.3s;
                        }

                        /* When moving the mouse over the close button */
                        .closebtn:hover {
                        color: black;
                        }
                        </style>

                        <style>
                        .alert {
                        opacity: 1;
                        transition: opacity 0.6s; /* 600ms to fade out */
                        }
                        </style>

                        <script>
                        // Get all elements with class="closebtn"
                        var close = document.getElementsByClassName("closebtn");
                        var i;

                        // Loop through all close buttons
                        for (i = 0; i < close.length; i++) {
                        // When someone clicks on a close button
                        close[i].onclick = function(){

                            // Get the parent of <span class="closebtn"> (<div class="alert">)
                            var div = this.parentElement;

                            // Set the opacity of div to 0 (transparent)
                            div.style.opacity = "0";

                            // Hide the div after 600ms (the same amount of milliseconds it takes to fade out)
                            setTimeout(function(){ div.style.display = "none"; }, 600);
                        }
                        }
                        </script>
                        GFG;

                    } ?>


                    <div class="input-box">
                        <?php if (isset($_GET['nama_toko'])) { ?>
                            <div class="input-box">
                                <input type="text"
                                class="input-field"
                                id="nama_toko"
                                    name="nama_toko" 
                                    placeholder="Nama Toko"
                                    required
                                    value="<?php echo $_GET['nama_pengguna']; ?>">
                            </div>
                        <?php }else{ ?>
                            <input type="text"
                                class="input-field"
                                id="nama_toko"
                                name="nama_toko" 
                                placeholder="Nama Toko"
                                required>
                        <?php }?>
                   </div>

                    <div class="input-box">
                        <input type="email" name="email_toko" class="input-field" placeholder="Email" required>
                    </div>

                    <div class="input-box">
                        <input type="password" name="kata_sandi" class="input-field" placeholder="Kata Sandi" required>
                    </div>

                    <!-- Sumbit -->

                    <br>

                    <div class="Input-Submit">
                        <button type="submit" class="submit-btn">
                            Buat Toko
                        </button>
                    </div>

                    <br>
            
                </form>
            
                    <!-- Sumbit -->
            
                <p>Sudah mempunyai Toko? <a href="..\halaman_masuk_admin\halaman_masuk_admin.php">Masuk</a></p>

            </div>

        </div>

        <!-- Isi website selesai -->

        <!-- Script -->

        <script>

        document.addEventListener('DOMContentLoaded', function() {
        var usernameInput = document.getElementById('nama_toko');

        usernameInput.addEventListener('input', function(e) {
            var start = this.selectionStart;
            var end = this.selectionEnd;

            // Convert text to lowercase
            this.value = this.value.toLowerCase();

            // Restore the selection range
            this.setSelectionRange(start, end);
        });
        });

        </script>

        <!-- Script Selesai -->

    </body>

</html>