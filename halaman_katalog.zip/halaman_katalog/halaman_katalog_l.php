<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $_GET['tombol_baju'];?></title>
    
    <!-- Menggunakan Bootstrap CSS dari file lokal -->
    <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

    <!-- Custom Font "Poppins" -->

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

    

    <!-- Logo Tab -->

    <link rel="icon" type="image/x-icon" href="../img/icon/logo_atas.svg">

    <!-- PHP -->

    <?php 

    session_start();

    if (isset($_SESSION['id']) && 
    isset($_SESSION['nama_pengguna']) &&
    isset($_SESSION['foto_pengguna'])) {

        // Koneksi ke database
        $con = mysqli_connect("localhost", "root", "", "waju");

        // Cek koneksi
        if (!$con) {
            die("Koneksi gagal: " . mysqli_connect_error());
        }

        // Ambil nama_baju dari URL
        if (isset($_GET['tombol_baju'])) {
            $nama_baju = $_GET['tombol_baju'];
        
            // Sanitasi input untuk menghindari SQL injection
            $nama_baju = mysqli_real_escape_string($con, $nama_baju);
        
            // Query untuk mengambil data produk berdasarkan nama_baju
            $query = "SELECT * FROM databaju WHERE nama_baju = '$nama_baju'";
            $result = mysqli_query($con, $query);
        
            // Cek apakah query berhasil
            if (!$result) {
                die("Query gagal: " . mysqli_error($con));
            }
        
            if (mysqli_num_rows($result) > 0) {
                $produk = mysqli_fetch_assoc($result);    
                
            } else {
                echo "<p>Produk tidak ditemukan.</p>";
                exit();
            }
        } else {
            echo "<p>Nama produk tidak diberikan.</p>";
            exit();
        }

    ?>
    
    <!-- PHP Selesai -->


</head>

<body>

    <!-- Internal CSS -->

    <style>

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: "Poppins", sans-serif;
        }

        /* CSS : Navagation Bar */

        .navbar {
            background-image: url(../img/icon/navbar.png);
            background-size: cover;
            border-bottom-left-radius: 20em 28em;
            border-bottom-right-radius: 20em 28em;
            height: 80px;
            box-shadow: 0 0 100px rgba(0, 0, 0, 0.325);
        }

        .navbar-brand {
            display: flex;
            justify-content: center;
            padding: 0px 0px 0% 0px !important;
            margin: 0px 5px 0px 0px !important;
            transition: 0.5s;
        }

        .navbar-brand:hover {
            filter:invert(100%) !important;
            opacity: 0.7;
        }

        .tombol_pencarian {
            display: block;
            width: 50px;
            height: auto;
            margin: 0 0 0 0; /* Menggabungkan margin */
            border: 1px solid rgba(14, 89, 129, 0.178);
            border-radius: 20px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.05); 
            background: rgb(166, 214, 239) url(../img/icon/icon_cari.svg) no-repeat center / 25% !important; /* Menggabungkan properti background */
            transition: 0.1s;
        }
   
        .tombol_pencarian:hover{
            border: none !important;
            filter:invert(20%) !important;
        }

        .tombol_pencarian:active{
            background-size: 50% !important;
        }

        .bar_pencarian {
            color: rgba(91, 91, 91, 0.57);            
            border: 1px solid rgba(14, 89, 129, 0.178);
            border-radius: 20px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.05); 
            text-indent: 12px;
            letter-spacing: 1px;
            transition: 0.3s;
        }

        .bar_pencarian input:focus,
        .bar_pencarian input:hover {
            color: #00282b;
            border: 1.5px solid #00282b;
        }

        .base_keranjang, .keranjang {
            margin: auto;
            width: 30px ;
            height: 30px ;
            display: block;
            transition: 0.3s;
            transition: 0.3s;
            justify-content: center; /* Mengatur konten secara horizontal ke tengah */
            align-items: center; /* Mengatur konten secara vertikal ke tengah */
        }
    
        .keranjang:hover {
            transform: scale(1.2);
        }

        .keranjang:active {
            animation: beat 0.3s alternate;
            transform-origin: center;
        } 
    
        @keyframes beat{
            to { transform: scale(1.4); }
        }

        .base_username {
            margin: auto;
            width: auto;
            display: inline-flex; /* Menggunakan inline-flex untuk menyesuaikan lebar dengan konten */
            justify-content: center; /* Mengatur konten secara horizontal ke tengah */
            align-items: center; /* Mengatur konten secara vertikal ke tengah */
            border: 1.5px solid #f2f2f2;
            border-radius: 25px;
            color: #ffffff;
            font-family: "Poppins", sans-serif;
            letter-spacing: 1px;
            padding: 5px 12px; /* Padding untuk memberikan ruang di sekitar teks */
            font-weight: 600;
            text-decoration: none;
            transition: 0.3s; /* Hanya perlu ditulis sekali */
        }

        .tulisan {
            overflow: hidden; /* Sembunyikan teks yang melampaui batas */
            white-space: nowrap !important; /* Mencegah teks membungkus ke baris baru */
            text-overflow: ellipsis !important; /* Tambahkan ellipsis (...) */
            max-width: calc(8vw) !important; 
            width: auto;
            text-align: center;
        }


        .base_username:hover {
            background-color: #f2f2f2;
            color: rgb(39, 74, 94);
        }
        
        .base_profil, .profil {
            margin: auto;
            width: auto ;
            height: 30px ;
            display: flex;
            z-index: 110;
            transition: 0.3s;
            padding-right: 30;
            transition: 0.3s;
            right: 0;   
        }
        
        .profil:hover {
            transform: scale(1.2);
        }

        .profil:active {
            animation: beat 0.3s alternate;
            transform-origin: center;
        } 

        .container-fluid {
            max-width: 95% !important;
        }

        @media (max-width: 1245px) {
            .kolom_profil {
                display: none !important;
            }

            .kolom_logo,
            .kolom_pencarian {
                margin-left: 30px;
            }
        }

        @media (max-width: 992px) {
            .kolom_logo {
                margin: 0 0 0 50px;
            }
            .kolom_pencarian {
                margin: auto;
                max-width: 60vw;
            }
            .kolom_keranjang {
                display: none !important;
            }
            .kolom_nama {
                display: none;
            }
            .kolom_profil {
                display: flex !important;
            }
            .kolom_konten {
                width: auto !important;
                margin: 0 0 0 30px;
            }
        }

        @media (max-width: 741px) {
            .kolom_konten {
                display: none !important;
            }
            .kolom_logo {
                width: 20vw !important;
            }
            .kolom_pencarian {
                width: 60vw !important;
            }
        }

        @media (max-width: 540.98px) {
            .kolom_pencarian {
                display: none;
            }
            .kolom_logo {
                margin: 0 0 0 0 !important;
                width: 100% !important;
                align-items: center;
                justify-content: center;
                display: block !important;
            }
            .navbar-brand {
                align-items: center !important;
                justify-content: center !important;
            }
        }

        /* CSS : Navagation Bar Selesai */

        .isi{
            max-width: 100%;
            padding-top: 0px;
            margin: 0;
            overflow-x: hidden;
        }

        /* Isi Website (halaman katalog)*/

        .isi {
            padding-top: 50px;
        }

        /* Calender */

        .calendar table {
            width: 20%;
            margin-left: 25px;
            border-collapse: collapse;
        }

        .calendar th, .calendar td {
            padding: 10px;
            text-align: center;
            border: none;
        }
        .calendar .month{
            background-color: #437894;
            color: #FFFFFF;
        }
        .calendar .available {
            background-color: #7ED957;
        }
        .calendar .limited {
            background-color: #9FA8AC;
        }
        .calendar .full {
            background-color: #FF5757;
        }

        .status {
            display: flex;
            align-items: center;
            margin-top: 20px;
            margin-left: 25px;
        }
        .color-box {
            width: 20px;
            height: 20px;
            margin-right: 10px;
        }
        .green {
            background-color: #7ED957;
        }
        .gray {
            background-color: #9FA8AC;
        }
        .red {
            background-color: #FF5757;
        }

        /* Gaya untuk produk */

        .product-image {
            width: 400px;
            height: auto;
            border-radius: 10px;
            border-style: solid:
            border-color: ;
        }
        .product-info {
            background-color: #deebee;
            border-radius: 10px;
            padding: 0.5rem;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .product-price {
            background-color: #1E3A8A;
            color: #FFFFFF;
            padding: 0.25rem 0.5rem;
            border-radius: 5px;
            font-weight: bold;
            display: inline-block;
            margin-bottom: 0.5rem;
            font-size: 1rem;
        }
        .product-details .like {
            display: flex;
            align-items: center;
            font-size: 16px;
            color: #e74c3c;
            margin-top: 10px;
        }
        .product-details .like i {
            font-size: 18px;
            color: #e74c3c;
        }
        .product-details .like span {
            margin-left: 5px;
            font-size: 14px;
            color: #ff0000;
        }
        .btn-custom {
            background-color: #5BC0BE;
            color: #FFFFFF;
            border: none;
            padding: 0.25rem 1rem;
            border-radius: 5px;
            font-weight: bold;
            font-size: 1rem;
        }
        .btn-custom:hover {
            background-color: #3A9A9F;
        }

        /* Gaya untuk form */
        .form-label {
            font-size: 1rem;
            font-weight: bold;
        }
        .form-control, .form-select {
            font-size: 1rem;
            padding: 0.25rem;
        }
        .fa-heart {
            font-size: 1.25rem;
            color: #E63946;
        }
        .like-count {
            font-size: 1rem;
            font-weight: bold;
            margin-left: 0.25rem;
        }
        
        /* Modal styles */
        .modal {
            display: none; 
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.4);
            padding-top: 60px;
        }
        .modal-content {
            background-color: #f2f2f2;
            margin: 5% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
            max-width: 300px;
            text-align: center;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        /* Gaya untuk tombol close (X) di bawah teks */
        .close {
            position: absolute;
            bottom: -30px; 
            left: 50%;
            transform: translateX(-50%); 
            font-size: 40px;
            color: white; 
            background-color: black; 
            width: 40px;
            height: 40px; 
            border-radius: 50%; 
            display: flex;
            justify-content: center; 
            align-items: center; 
            cursor: pointer;
        }
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }
        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        /* Tentang */

        .about {
            padding: 50px 0;
            background-color: #fff;
            text-align: center;
            }
            .about h2 {
            margin-bottom: 20px;
            font-size: 2rem;
            }
            .about p {
            margin: 10px 0;
            font-size: 1.1rem;
            }
            
        /* Footer */
        .footer {
            background: #333;
            color: white;
            text-align: center;
            padding: 10px;
            position: relative;
            width: 100%;
            bottom: 0;
        }
        .footer .social-links {
            list-style: none;
            display: flex;
            justify-content: center;
            margin: 15px 0;
        }
        .footer .social-links li {
            margin: 0 10px;
        }
        .footer .social-links a {
            color: white;
            text-decoration: none;
            font-size: 1.2rem;
        }
        .footer .social-links a:hover {
            color: #ff6347
        }
        
    </style>

    <!-- Navagation Bar -->

    <nav class="navbar navbar-expand-lg">

    <div class="container-fluid">

    <div class="col-2 kolom_logo">
        <a class="navbar-brand" href="../halaman_beranda/halaman_beranda.php">
            <img src="../img/icon/logo2.png" alt="logo" width="auto" height="auto">
        </a>
    </div>

    <div class="col-7 kolom_pencarian">
        <!-- Bar Pencarian -->
        <form class="d-flex" style="padding-left: 20px;" action="../halaman_pencarian/halaman_pencarian.php" method="get">
            <input class="bar_pencarian form-control me-2" name="pencarian" value="<?php if(isset($_GET['pencarian'])){echo $_GET['pencarian'];} ?>" type="search" placeholder="Hari ini mau keren yang mana?" aria-label="Search" required maxlength="60" oninvalid="this.setCustomValidity('Isi dong, mau nyari apa kalau kosong.')" oninput="setCustomValidity('')">
            <button class="tombol_pencarian btn btn-outline-success" type="submit"></button>
        </form>
    </div>

    <div class="col-3 row d-flex justify-content-center kolom_konten">

        <div class="col-auto d-flex kolom_keranjang">
            <!-- Logo Keranjang -->

            <td>
                <form action="../halaman_keranjang/halaman_keranjang.php" method="post" name="tombol_keranjang">
                    <button style="border: none; background: transparent;" class="base_keranjang" type="submit">
                        <img src="..\img\icon\icon_keranjang.svg" alt="keranjang" class="keranjang">
                    </button>
                </form>
            </td>

        </div>

        <div class="col-md-6 kolom_nama d-flex">
            <!-- Nama Pengguna -->

            <td>
                <a href="../halaman_list/list_sewa.php" class="base_username" id="username">
                    <div class="tulisan">
                        <?php echo $_SESSION['nama_pengguna']; ?>
                    </div>
                </a>
            </td>

        </div>

        <div class="col-auto d-flex kolom_profil">
            <!-- Foto profil -->

            <td>
            <a href="../halaman_list/list_sewa.php" class="base_profil">
                <img src="<?php if($_SESSION['foto_pengguna'] == NULL) {echo "..\img\icon\profile.jpg";} else{echo $_SESSION['foto_pengguna'];}?>" style="transform: scale(1.3); aspect-ratio: 1/1; object-fit: cover;" alt="photo_profil" class="profil rounded-circle border border-success border-opacity-25 shadow">
                </a>

            <style>
              .base_profil:hover, .profil:hover {
                transform: scale(1.3);
                }
            </style>
            </td>
        </div>

    </div>

    </div>

    </nav>

    <!-- Navagation Bar Selesai -->

    <!-- Isi Website --> <!-------------------------------------------------------------------------------->

    <div class="isi" style="padding-bottom: 120px;">

        <div class="container mt-3">

            <!-- Informasi Produk -->
            <div class="row">

                <div class="col-md-5">

                        <div class="card shadow-lg p-3 mb-5 bg-body rounded-3 d-flex justify-content-center">

                            <div class="card-body d-flex justify-content-center align-items-center">
                                <img alt="foto kostum" class="rounded-3" src="<?= $produk['foto_baju']; ?>" style="
                                aspect-ration: 4/4;
                                height: 500px;
                                width: 500px;
                                object-fit: cover;
                                ">
                            </div>

                        </div>

                </div>
                
                <div class="col-md-1">


                </div>

                <div class="col-md-6">

                    <div class="product-info" style="padding:25px 25px 30px 25px;">

                    <h3 class="p-1 font-weight-bold"><?= $produk['nama_baju']; ?></h3>

                        <div class="product-info" style="padding: 25px;">

                            <!-- Ikon suka ditempatkan di atas harga -->
                            <div class="product-details" style="padding: 5px 0 15px 0;">
                                
                                <div class="">
                                    <table>
                                        <tr style="padding-bottom: 10px">
                                            <td style="padding-right:10px;">Tersewa <span style="font-weight: 750;"><?= $produk['tersewa_baju']; ?></span> Kali</td>
                                            <td>|</td>
                                            <td style="padding-left:10px;">Rating <span style="font-weight: 750;"><?= $produk['rating_baju']; ?></span> <i class="fa-solid fa-star" style="color: #FFD43B;"></i></td>
                                        </tr>
                                    </table>
                                </div>

                            </div> 

                            <div class="product-price">
                                RP. <?= $produk['harga_baju']; ?>/hari
                            </div>

                            <form method="post" id="masukkan_keranjang" action="../mysql_database/masukkan_keranjang.php">

                                <div class="mb-2 py-2">
                                    <label class="form-label" for="date">Pilih Tanggal</label>
                                    <select class="form-select" id="date" name="tanggal_sewa_keranjang" required>
                                        <option value="" disabled selected>Pilih Tanggal</option>
                                        <option value="1" <?php if(date('d') > 1) {echo 'style="display: none;"';} ?> <?php if($produk['tanggal_1'] == 0){echo "disabled";} ?>>1 <?php if($produk['tanggal_1'] == 0){echo "(Sudah Habis Disewa)";} ?></option>
                                        <option value="2" <?php if(date('d') > 2) {echo 'style="display: none;"';} ?> <?php if($produk['tanggal_2'] == 0){echo "disabled";} ?>>2 <?php if($produk['tanggal_2'] == 0){echo "(Sudah Habis Disewa)";} ?></option>
                                        <option value="3" <?php if(date('d') > 3) {echo 'style="display: none;"';} ?> <?php if($produk['tanggal_3'] == 0){echo "disabled";} ?>>3 <?php if($produk['tanggal_3'] == 0){echo "(Sudah Habis Disewa)";} ?></option>
                                        <option value="4" <?php if(date('d') > 4) {echo 'style="display: none;"';} ?> <?php if($produk['tanggal_4'] == 0){echo "disabled";} ?>>4 <?php if($produk['tanggal_4'] == 0){echo "(Sudah Habis Disewa)";} ?></option>
                                        <option value="5" <?php if(date('d') > 5) {echo 'style="display: none;"';} ?> <?php if($produk['tanggal_5'] == 0){echo "disabled";} ?>>5 <?php if($produk['tanggal_5'] == 0){echo "(Sudah Habis Disewa)";} ?></option>
                                        <option value="6" <?php if(date('d') > 6) {echo 'style="display: none;"';} ?> <?php if($produk['tanggal_6'] == 0){echo "disabled";} ?>>6 <?php if($produk['tanggal_6'] == 0){echo "(Sudah Habis Disewa)";} ?></option>
                                        <option value="7" <?php if(date('d') > 7) {echo 'style="display: none;"';} ?> <?php if($produk['tanggal_7'] == 0){echo "disabled";} ?>>7 <?php if($produk['tanggal_7'] == 0){echo "(Sudah Habis Disewa)";} ?></option>
                                        <option value="8" <?php if(date('d') > 8) {echo 'style="display: none;"';} ?> <?php if($produk['tanggal_8'] == 0){echo "disabled";} ?>>8 <?php if($produk['tanggal_8'] == 0){echo "(Sudah Habis Disewa)";} ?></option>
                                        <option value="9" <?php if(date('d') > 9) {echo 'style="display: none;"';} ?> <?php if($produk['tanggal_9'] == 0){echo "disabled";} ?>>9 <?php if($produk['tanggal_9'] == 0){echo "(Sudah Habis Disewa)";} ?></option>
                                        <option value="10" <?php if(date('d') > 10) {echo 'style="display: none;"';} ?> <?php if($produk['tanggal_10'] == 0){echo "disabled";} ?>>10 <?php if($produk['tanggal_10'] == 0){echo "(Sudah Habis Disewa)";} ?></option>
                                        <option value="11" <?php if(date('d') > 11) {echo 'style="display: none;"';} ?> <?php if($produk['tanggal_11'] == 0){echo "disabled";} ?>>11 <?php if($produk['tanggal_11'] == 0){echo "(Sudah Habis Disewa)";} ?></option>
                                        <option value="12" <?php if(date('d') > 12) {echo 'style="display: none;"';} ?> <?php if($produk['tanggal_12'] == 0){echo "disabled";} ?>>12 <?php if($produk['tanggal_12'] == 0){echo "(Sudah Habis Disewa)";} ?></option>
                                        <option value="13" <?php if(date('d') > 13) {echo 'style="display: none;"';} ?> <?php if($produk['tanggal_13'] == 0){echo "disabled";} ?>>13 <?php if($produk['tanggal_13'] == 0){echo "(Sudah Habis Disewa)";} ?></option>
                                        <option value="14" <?php if(date('d') > 14) {echo 'style="display: none;"';} ?> <?php if($produk['tanggal_14'] == 0){echo "disabled";} ?>>14 <?php if($produk['tanggal_14'] == 0){echo "(Sudah Habis Disewa)";} ?></option>
                                        <option value="15" <?php if(date('d') > 15) {echo 'style="display: none;"';} ?> <?php if($produk['tanggal_15'] == 0){echo "disabled";} ?>>15 <?php if($produk['tanggal_15'] == 0){echo "(Sudah Habis Disewa)";} ?></option>
                                        <option value="16" <?php if(date('d') > 16) {echo 'style="display: none;"';} ?> <?php if($produk['tanggal_16'] == 0){echo "disabled";} ?>>16 <?php if($produk['tanggal_16'] == 0){echo "(Sudah Habis Disewa)";} ?></option>
                                        <option value="17" <?php if(date('d') > 17) {echo 'style="display: none;"';} ?> <?php if($produk['tanggal_17'] == 0){echo "disabled";} ?>>17 <?php if($produk['tanggal_17'] == 0){echo "(Sudah Habis Disewa)";} ?></option>
                                        <option value="18" <?php if(date('d') > 18) {echo 'style="display: none;"';} ?> <?php if($produk['tanggal_18'] == 0){echo "disabled";} ?>>18 <?php if($produk['tanggal_18'] == 0){echo "(Sudah Habis Disewa)";} ?></option>
                                        <option value="19" <?php if(date('d') > 19) {echo 'style="display: none;"';} ?> <?php if($produk['tanggal_19'] == 0){echo "disabled";} ?>>19 <?php if($produk['tanggal_19'] == 0){echo "(Sudah Habis Disewa)";} ?></option>
                                        <option value="20" <?php if(date('d') > 20) {echo 'style="display: none;"';} ?> <?php if($produk['tanggal_20'] == 0){echo "disabled";} ?>>20 <?php if($produk['tanggal_20'] == 0){echo "(Sudah Habis Disewa)";} ?></option>
                                        <option value="21" <?php if(date('d') > 21) {echo 'style="display: none;"';} ?> <?php if($produk['tanggal_21'] == 0){echo "disabled";} ?>>21 <?php if($produk['tanggal_21'] == 0){echo "(Sudah Habis Disewa)";} ?></option>
                                        <option value="22" <?php if(date('d') > 22) {echo 'style="display: none;"';} ?> <?php if($produk['tanggal_22'] == 0){echo "disabled";} ?>>22 <?php if($produk['tanggal_22'] == 0){echo "(Sudah Habis Disewa)";} ?></option>
                                        <option value="23" <?php if(date('d') > 23) {echo 'style="display: none;"';} ?> <?php if($produk['tanggal_23'] == 0){echo "disabled";} ?>>23 <?php if($produk['tanggal_23'] == 0){echo "(Sudah Habis Disewa)";} ?></option>
                                        <option value="24" <?php if(date('d') > 24) {echo 'style="display: none;"';} ?> <?php if($produk['tanggal_24'] == 0){echo "disabled";} ?>>24 <?php if($produk['tanggal_24'] == 0){echo "(Sudah Habis Disewa)";} ?></option>
                                        <option value="25" <?php if(date('d') > 25) {echo 'style="display: none;"';} ?> <?php if($produk['tanggal_25'] == 0){echo "disabled";} ?>>25 <?php if($produk['tanggal_25'] == 0){echo "(Sudah Habis Disewa)";} ?></option>
                                        <option value="26" <?php if(date('d') > 26) {echo 'style="display: none;"';} ?> <?php if($produk['tanggal_26'] == 0){echo "disabled";} ?>>26 <?php if($produk['tanggal_26'] == 0){echo "(Sudah Habis Disewa)";} ?></option>
                                        <option value="27" <?php if(date('d') > 27 or date('t') < 27) {echo 'style="display: none;"';} ?> <?php if($produk['tanggal_27'] == 0){echo "disabled";} ?>>27 <?php if($produk['tanggal_27'] == 0){echo "(Sudah Habis Disewa)";} ?></option>
                                        <option value="28" <?php if(date('d') > 28 or date('t') < 28) {echo 'style="display: none;"';} ?> <?php if($produk['tanggal_28'] == 0){echo "disabled";} ?>>28 <?php if($produk['tanggal_28'] == 0){echo "(Sudah Habis Disewa)";} ?></option>
                                        <option value="29" <?php if(date('d') > 29 or date('t') < 29) {echo 'style="display: none;"';} ?> <?php if($produk['tanggal_29'] == 0){echo "disabled";} ?>>29 <?php if($produk['tanggal_29'] == 0){echo "(Sudah Habis Disewa)";} ?></option>
                                        <option value="30" <?php if(date('d') > 30 or date('t') < 30) {echo 'style="display: none;"';} ?> <?php if($produk['tanggal_30'] == 0){echo "disabled";} ?>>30 <?php if($produk['tanggal_30'] == 0){echo "(Sudah Habis Disewa)";} ?></option>
                                        <option value="31" <?php if(date('d') > 31 or date('t') < 31) {echo 'style="display: none;"';} ?> <?php if($produk['tanggal_31'] == 0){echo "disabled";} ?>>31 <?php if($produk['tanggal_31'] == 0){echo "(Sudah Habis Disewa)";} ?></option>
                                        </select> 
                                </div>

                                <div class="mb-2 py-1">
                                    <label class="form-label" for="size">Pilih Ukuran</label><br>

                                    <!--
                                    <input type="radio" class="btn-check" name="options" id="option1" autocomplete="off">
                                    <label class="btn btn-secondary" for="option1">S</label>

                                    <input type="radio" class="btn-check" name="options" id="option2" autocomplete="off">
                                    <label class="btn btn-secondary" for="option2">M</label>

                                    <input type="radio" class="btn-check" name="options" id="option3" autocomplete="off">
                                    <label class="btn btn-secondary" for="option3">L</label>
                                    -->

                                    <table>
                                    <tr>
                                        <td class="px-1" style="display: none;">
                                            <form method="get" action="../halaman_katalog/halaman_katalog_s.php">
                                                <input type="hidden" name="tombol_baju" value="<?= $produk['nama_baju']; ?>"> 
                                                <button type="submit" class="btn btn-outline-primary">S</button>
                                            </form>
                                        </td>
                                        
                                        <td class="px-1">
                                            <form method="get" action="../halaman_katalog/halaman_katalog_s.php">
                                                <input type="hidden" name="tombol_baju" value="<?= $produk['nama_baju']; ?>"> 
                                                <button type="submit" class="btn btn-outline-primary">S</button>
                                            </form>
                                        </td>

                                        <td class="px-1">
                                            <form method="get" action="../halaman_katalog/halaman_katalog_m.php">
                                                <input type="hidden" name="tombol_baju" value="<?= $produk['nama_baju']; ?>"> <!-- Mengirimkan nama_baju -->
                                                <button type="submit" class="btn btn-outline-primary">M</button>
                                            </form>
                                        </td>   
                                        
                                        <td class="px-1">
                                            <!--
                                            <form method="get" action="../halaman_katalog/halaman_katalog_l.php">
                                                <input type="hidden" name="tombol_baju" value="<?= $produk['nama_baju']; ?>"> 
                                                <button type="submit" class="btn btn-outline-primary">L</button>
                                            </form>
                                            -->
                                            <input type="checkbox" class="btn-check" id="btn-check-2" checked autocomplete="off" value="<?= $produk['pilih_ukuran_l']; ?>">
                                            <label class="btn btn-primary" for="btn-check-2">L</label>
                                        </td>

                                    </tr>
                                    </table>
                                
                                </div>


                                <div class="mb-2" style="padding-bottom: 20px;">
                                    <p class="form-label">Jumlah Baju Yang Tersedia (Sesuai Ukuran)</p>
                                    <div class="p-2 h5 font-weight-bold bg-info text-white">
                                    <?php echo $produk['ukuran_l']; ?>
                                    </div>
                                </div>

                                <input type="hidden" name="nama_baju_keranjang" value="<?= $produk['nama_baju']; ?>"> <!-- Mengirimkan nama_baju -->
                                <input type="hidden" name="kategori_baju_keranjang" value="<?= $produk['kategori_baju']; ?>"> <!-- Mengirimkan kategori_baju -->
                                <input type="hidden" name="harga_baju_keranjang" value="<?= $produk['harga_baju']; ?>"> <!-- Mengirimkan harga_baju -->
                                <input type="hidden" name="pemilik_baju_keranjang" value="<?= $produk['pemilik_baju']; ?>"> <!-- Mengirimkan pemilik_baju -->
                                <input type="hidden" name="alamat_toko_keranjang" value="<?= $produk['alamat_toko']; ?>"> <!-- Mengirimkan alamat_toko -->
                                <input type="hidden" name="foto_baju_keranjang" value="<?php echo htmlspecialchars(str_replace('\\', '\\\\', $produk['foto_baju']), ENT_QUOTES, 'UTF-8'); ?>"> <!-- Mengirimkan foto_baju -->                                <input type="hidden" name="id_baju_databaju" value="<?= $produk['id']; ?>"> <!-- Mengirimkan id_baju -->
                                <input type="hidden" name="ukuran_baju_keranjang" value="L"> <!-- Mengirimkan ukuran baju -->
                                <input type="hidden" name="pilih_ukuran_s" value="0"> <!-- Mengirimkan indikator_ukuran_s -->
                                <input type="hidden" name="pilih_ukuran_m" value="1"> <!-- Mengirimkan indikator_ukuran_s -->
                                <input type="hidden" name="pilih_ukuran_l" value="0"> <!-- Mengirimkan indikator_ukuran_l -->
                                <input type="hidden" name="id_toko" value="<?= $produk['id_toko']; ?>">
                                <input type="hidden" name="nama_pengguna" value="<?php echo $_SESSION['nama_pengguna']; ?>"> <!-- Mengirimkan nama_pengguna -->

                                <div class="d-flex justify-content-between">
                                    <button class="btn btn-custom" id="addToCartButton" type="submit">TAMBAHKAN KE KERANJANG</button>
                                    <a href="https://api.whatsapp.com/send?phone=<?php echo $produk['kontak_pemilik']; ?>&text=Halo WAJU Lovers! Saya Ingin Bertanya." target="_blank" class="button btn btn-custom">Chat Pemilik</a>
                                </div>

                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="container mt-5">

            <div class="col-md">

                <div class="card shadow p-3 mb-5 bg-body rounded-3">

                    <div class="card-body">

                        <div class="row">

                            <div class="col-md-auto px-3"><a href="">

                            <img src="<?php if($produk['foto_pemilik'] == ""){ echo "https://via.placeholder.com/100";} else{echo $produk['foto_pemilik'];}?>" class="rounded-circle mb-2 border border-dark shadow-sm border-success border-opacity-50 " alt="foto_pemilik" 
                                style="
                                    max-width: 100px;
                                    min-height: 100px;
                                    object-fit: cover;
                                    aspect-ratio: 1 / 1;"
                                >

                            </div></a>

                            <div class="col-md-auto px-2 d-flex">

                                <div class="vr"></div>

                            </div>

                            <div class="col px-2">

                                <a type="button" class="btn btn-primary p-1 px-2" href="#"><p class="card-title font-weight-bold"><?= $produk['pemilik_baju']; ?></p></a>

                                <div class="d-flex flex-row bd-highlight mt-3">

                                    <div class="vr" style="width: 3px; rounded"></div>

                                    <p class="card-text px-2 text-truncate" style="max-width: 80vh;"><?= $produk['deskripsi_toko']; ?></p>

                                </div>

                                <div class="d-flex flex-row bd-highlight mt-3">

                                    <i class="fa-solid fa-location-dot"></i>

                                    <p class="card-text px-2 text-truncate" style="max-width: 80vh;"><?= $produk['alamat_toko']; ?></p>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>

        </br>

        <div class="container mt-3">

            <div class="row">

                <div class="col-md-3">

                    <div class="calendar">

                        <table>

                            <thead >

                                <tr>

                                <th class="month" colspan="7">
                                    <?php echo date('F'); ?>
                                </th>
                                
                                </tr>

                                <tr>
                                    <th>    
                                    <!-- Jarak Kosong -->
                                    </th>
                                </tr>

                            </thead>

                            <tbody>

                                <tr>
                                <td>
                                </td>
                                <td>
                                </td>
                                
                                <td class="<?php if($produk['tanggal_1'] >= 2){echo "available";} elseif($produk['tanggal_1'] == 1) {echo "limited";} elseif($produk['tanggal_1'] == 0){echo "full";} ?>" <?php if(date('d') > 1) {echo 'style="display: none;"';} ?>> 1 </td>
                                <td class="<?php if($produk['tanggal_2'] >= 2){echo "available";} elseif($produk['tanggal_2'] == 1) {echo "limited";} elseif($produk['tanggal_2'] == 0){echo "full";} ?>" <?php if(date('d') > 2) {echo 'style="display: none;"';} ?>> 2 </td>
                                <td class="<?php if($produk['tanggal_3'] >= 2){echo "available";} elseif($produk['tanggal_3'] == 1) {echo "limited";} elseif($produk['tanggal_3'] == 0){echo "full";} ?>" <?php if(date('d') > 3) {echo 'style="display: none;"';} ?>> 3 </td>
                                <td class="<?php if($produk['tanggal_4'] >= 2){echo "available";} elseif($produk['tanggal_4'] == 1) {echo "limited";} elseif($produk['tanggal_4'] == 0){echo "full";} ?>" <?php if(date('d') > 4) {echo 'style="display: none;"';} ?>> 4 </td>
                                <td class="<?php if($produk['tanggal_5'] >= 2){echo "available";} elseif($produk['tanggal_5'] == 1) {echo "limited";} elseif($produk['tanggal_5'] == 0){echo "full";} ?>" <?php if(date('d') > 5) {echo 'style="display: none;"';} ?>> 5 </td></tr><tr>
                                <td class="<?php if($produk['tanggal_6'] >= 2){echo "available";} elseif($produk['tanggal_6'] == 1) {echo "limited";} elseif($produk['tanggal_6'] == 0){echo "full";} ?>" <?php if(date('d') > 6) {echo 'style="display: none;"';} ?>> 6 </td>
                                <td class="<?php if($produk['tanggal_7'] >= 2){echo "available";} elseif($produk['tanggal_7'] == 1) {echo "limited";} elseif($produk['tanggal_7'] == 0){echo "full";} ?>" <?php if(date('d') > 7) {echo 'style="display: none;"';} ?>> 7 </td>
                                <td class="<?php if($produk['tanggal_8'] >= 2){echo "available";} elseif($produk['tanggal_8'] == 1) {echo "limited";} elseif($produk['tanggal_8'] == 0){echo "full";} ?>" <?php if(date('d') > 8) {echo 'style="display: none;"';} ?>> 8 </td>
                                <td class="<?php if($produk['tanggal_9'] >= 2){echo "available";} elseif($produk['tanggal_9'] == 1) {echo "limited";} elseif($produk['tanggal_9'] == 0){echo "full";} ?>" <?php if(date('d') > 9) {echo 'style="display: none;"';} ?>> 9 </td>
                                <td class="<?php if($produk['tanggal_10'] >= 2){echo "available";} elseif($produk['tanggal_10'] == 1) {echo "limited";} elseif($produk['tanggal_10'] == 0){echo "full";} ?>" <?php if(date('d') > 10) {echo 'style="display: none;"';} ?>> 10 </td>
                                <td class="<?php if($produk['tanggal_11'] >= 2){echo "available";} elseif($produk['tanggal_11'] == 1) {echo "limited";} elseif($produk['tanggal_11'] == 0){echo "full";} ?>" <?php if(date('d') > 11) {echo 'style="display: none;"';} ?>> 11 </td>
                                <td class="<?php if($produk['tanggal_12'] >= 2){echo "available";} elseif($produk['tanggal_12'] == 1) {echo "limited";} elseif($produk ['tanggal_12'] == 0){echo "full";} ?>" <?php if(date('d') > 12) {echo 'style="display: none;"';} ?>> 12 </td></tr><tr>
                                <td class="<?php if($produk['tanggal_13'] >= 2){echo "available";} elseif($produk['tanggal_13'] == 1) {echo "limited";} elseif($produk['tanggal_13'] == 0){echo "full";} ?>" <?php if(date('d') > 13) {echo 'style="display: none;"';} ?>> 13 </td>
                                <td class="<?php if($produk['tanggal_14'] >= 2){echo "available";} elseif($produk['tanggal_14'] == 1) {echo "limited";} elseif($produk['tanggal_14'] == 0){echo "full";} ?>" <?php if(date('d') > 14) {echo 'style="display: none;"';} ?>> 14 </td>
                                <td class="<?php if($produk['tanggal_15'] >= 2){echo "available";} elseif($produk['tanggal_15'] == 1) {echo "limited";} elseif($produk['tanggal_15'] == 0){echo "full";} ?>" <?php if(date('d') > 15) {echo 'style="display: none;"';} ?>> 15 </td>
                                <td class="<?php if($produk['tanggal_16'] >= 2){echo "available";} elseif($produk['tanggal_16'] == 1) {echo "limited";} elseif($produk['tanggal_16'] == 0){echo "full";} ?>" <?php if(date('d') > 16) {echo 'style="display: none;"';} ?>> 16 </td>
                                <td class="<?php if($produk['tanggal_17'] >= 2){echo "available";} elseif($produk['tanggal_17'] == 1) {echo "limited";} elseif($produk['tanggal_17'] == 0){echo "full";} ?>" <?php if(date('d') > 17) {echo 'style="display: none;"';} ?>> 17 </td>
                                <td class="<?php if($produk['tanggal_18'] >= 2){echo "available";} elseif($produk['tanggal_18'] == 1) {echo "limited";} elseif($produk['tanggal_18'] == 0){echo "full";} ?>" <?php if(date('d') > 18) {echo 'style="display: none;"';} ?>> 18 </td>
                                <td class="<?php if($produk['tanggal_19'] >= 2){echo "available";} elseif($produk['tanggal_19'] == 1) {echo "limited";} elseif($produk['tanggal_19'] == 0){echo "full";} ?>" <?php if(date('d') > 19) {echo 'style="display: none;"';} ?>> 19 </td></tr><tr>
                                <td class="<?php if($produk['tanggal_20'] >= 2){echo "available";} elseif($produk['tanggal_20'] == 1) {echo "limited";} elseif($produk['tanggal_20'] == 0){echo "full";} ?>" <?php if(date('d') > 20) {echo 'style="display: none;"';} ?>> 20 </td>
                                <td class="<?php if($produk['tanggal_21'] >= 2){echo "available";} elseif($produk['tanggal_21'] == 1) {echo "limited";} elseif($produk['tanggal_21'] == 0){echo "full";} ?>" <?php if(date('d') > 21) {echo 'style="display: none;"';} ?>> 21 </td>
                                <td class="<?php if($produk['tanggal_22'] >= 2){echo "available";} elseif($produk['tanggal_22'] == 1) {echo "limited";} elseif($produk['tanggal_22'] == 0){echo "full";} ?>" <?php if(date('d') > 22) {echo 'style="display: none;"';} ?>> 22 </td>
                                <td class="<?php if($produk['tanggal_23'] >= 2){echo "available";} elseif($produk['tanggal_23'] == 1) {echo "limited";} elseif($produk['tanggal_23'] == 0){echo "full";} ?>" <?php if(date('d') > 23) {echo 'style="display: none;"';} ?>> 23 </td>
                                <td class="<?php if($produk['tanggal_24'] >= 2){echo "available";} elseif($produk['tanggal_24'] == 1) {echo "limited";} elseif($produk['tanggal_24'] == 0){echo "full";} ?>" <?php if(date('d') > 24) {echo 'style="display: none;"';} ?>> 24 </td>
                                <td class="<?php if($produk['tanggal_25'] >= 2){echo "available";} elseif($produk['tanggal_25'] == 1) {echo "limited";} elseif($produk['tanggal_25'] == 0){echo "full";} ?>" <?php if(date('d') > 25) {echo 'style="display: none;"';} ?>> 25 </td>
                                <td class="<?php if($produk['tanggal_26'] >= 2){echo "available";} elseif($produk['tanggal_26'] == 1) {echo "limited";} elseif($produk['tanggal_26'] == 0){echo "full";} ?>" <?php if(date('d') > 26) {echo 'style="display: none;"';} ?>> 26 </td></tr><tr>
                                <td class="<?php if($produk['tanggal_27'] >= 2){echo "available";} elseif($produk['tanggal_27'] == 1) {echo "limited";} elseif($produk['tanggal_27'] == 0){echo "full";} ?>" <?php if(date('d') > 27 || date('t') < 27) {echo 'style="display: none;"';} ?>> 27 </td>
                                <td class="<?php if($produk['tanggal_28'] >= 2){echo "available";} elseif($produk['tanggal_28'] == 1) {echo "limited";} elseif($produk['tanggal_28'] == 0){echo "full";} ?>" <?php if(date('d') > 28 || date('t') < 28) {echo 'style="display: none;"';} ?>> 28 </td>
                                <td class="<?php if($produk['tanggal_29'] >= 2){echo "available";} elseif($produk['tanggal_29'] == 1) {echo "limited";} elseif($produk['tanggal_29'] == 0){echo "full";} ?>" <?php if(date('d') > 29 || date('t') < 29) {echo 'style="display: none;"';} ?>> 29 </td>
                                <td class="<?php if($produk['tanggal_30'] >= 2){echo "available";} elseif($produk['tanggal_30'] == 1) {echo "limited";} elseif($produk['tanggal_30'] == 0){echo "full";} ?>" <?php if(date('d') > 30 || date('t') < 30) {echo 'style="display: none;"';} ?>> 30 </td>
                                <td class="<?php if($produk['tanggal_31'] >= 2){echo "available";} elseif($produk['tanggal_31'] == 1) {echo "limited";} elseif($produk['tanggal_31'] == 0){echo "full";} ?>" <?php if(date('d') > 31 || date('t') < 31) {echo 'style="display: none;"';} ?>> 31 </td>
                                <td>
                                </td>
                                <td>
                                </td>
                                </tr>
                            </tbody>

                        </table>

                    </div>
                        
                    <div class="status">
                        <div class="color-box green"></div>
                        <div>Tersedia</div>
                    </div>
                    <div class="status">
                        <div class="color-box gray"></div>
                        <div>Stok Sedikit</div>
                    </div>
                    <div class="status">
                        <div class="color-box red"></div>
                        <div>Penuh</div>
                    </div>

                </div>

                <div class="col-md-9">

                <div class="card shadow-md p-3 mb-5 bg-body rounded-3">

                    <div class="card-body">

                        <div class="p-3 h5 font-weight-bold bg-info text-white">

                            Deskripsi

                        </div>

                        <br>

                        <div class="deskripsi">

                            <p class="text-break">
                            <!-- Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed maximus et ipsum eu ultrices. Vivamus at mauris eros. Mauris vitae suscipit augue. Aenean ac mollis ante. Nullam vitae eros gravida diam interdum finibus eu ac orci. Proin luctus tellus nunc, vitae scelerisque dolor venenatis eu. Phasellus convallis a ipsum sit amet luctus. Integer eu placerat urna. Mauris ut euismod arcu. Aliquam laoreet nulla sem, at auctor ligula dapibus et. Suspendisse ultrices leo at porttitor auctor. Nam quis dolor ac tellus viverra mollis nec quis dolor.-->
                            <?php echo nl2br(htmlspecialchars($produk['deskripsi_baju'])); ?>
                            </p>

                        </div>

                    </div>

                </div>

                </div>

            </div>

        </div>

        

        <!-- Modal (Popup) -->
        <div id="cartModal" class="modal">
            <div class="modal-content">
                <span class="checkmark">&#10003;</span> <!-- Tanda centang --></br>
                <p><span style="font-weight: 700;">Produk berhasil di tambahkan ke keranjang!<span></p>

                <p><span style="font-weight: 400; font-size: 14px;">Pop up ini akan otomatis tutup</span></p>
                <span class="close">&times;</span> <!-- Tombol close (X) -->
            </div>
        </div>

    </div>

    <link rel="stylesheet" href="..\footer\footer.css">

    <?php

            // Koneksi ke database
            $con = mysqli_connect("localhost", "root", "", "waju");

            // Cek koneksi
            if (!$con) {
                die("Koneksi gagal: " . mysqli_connect_error());
            }

            $query = "SELECT * FROM footer"; // Menggunakan nama_baju
            $result = mysqli_query($con, $query);

            $footer = mysqli_fetch_assoc($result);
            
            echo $footer['footer'];

    ?>



    <!-- Bootstrap JS dari file lokal -->
    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Java script --> <!-------------------------------------------------------------------------------->

        <script src="https://kit.fontawesome.com/16c1f9d94e.js" crossorigin="anonymous"></script> 

        <script>                
            var tanggalSewaInput = document.getElementsByName("tanggal_sewa_keranjang")[0];
            var modal = document.getElementById("cartModal");
            var tombolTambahKeranjang = document.getElementById("addToCartButton");
            var tombolTutup = document.getElementsByClassName("close")[0];

                document.getElementById('masukkan_keranjang').addEventListener('submit', function(e) {
                e.preventDefault(); // Prevent the default form submission
                modal.style.display = "block";
                // Delay Submit form 
                setTimeout(() => {
                    this.submit(); // Submit the form after 5 seconds
                    }, 800); // 500 milliseconds = 0.5 seconds
            });

            // Tampilkan modal secara otomatis saat halaman dimuat
                window.onload = function() {
                    // Cek apakah input tanggal_sewa_keranjang kosong
                    if (tanggalSewaInput.value.trim() === "") {
                        // Jika kosong, batalkan proses dan tidak tampilkan modal
                        return; // Keluar dari fungsi
                    }
                }  
            
            // Ketika pengguna mengklik tombol "Tutup" (X), sembunyikan modal
            tombolTutup.onclick = function() {
            modal.style.display = "none";
            }

            // Ketika pengguna mengklik di luar modal, tutup modal
            window.onclick = function(event) {
                if (event.target == modal) {
                modal.style.display = "none";
                }
            }
        </script>

    <!-- PHP Akhir -->

    <?php 
    
    }
    
    else{
        header("Location: ../halaman_utama/halaman_utama.html");
        exit();
    }

    ?>

    <!--  PHP Selesai -->

</body>
</html>