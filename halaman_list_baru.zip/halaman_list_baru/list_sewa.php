<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>WA! JU!</title>
  
  <!-- Custom Font "Poppins" -->

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <!-- Menggunakan Bootstrap CSS dari file lokal -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

  <!-- Menggunakan Bootstrap CSS dari file lokal -->
  <link href="..\bootstrap\css\bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  
  <!-- PHP -->

    <?php 

    session_start();

    if (isset($_SESSION['id']) && isset($_SESSION['nama_pengguna'])) {

    ?>

  <!-- PHP Selesai -->

<body>

  <!-- Internal CSS -->

    <style>

      * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: "Poppins", sans-serif;
      }

      /* CSS : Navagation Bar */

      .navbar {
        background-image: url(../img/icon/navbar.png);
        background-size: cover;
        border-bottom-left-radius: 20em 28em;
        border-bottom-right-radius: 20em 28em;
        height: 80px;
      }

      .navbar-brand {
        display: flex;
        justify-content: center;
        padding: 0px 0px 0% 0px !important;
        margin: 0px 5px 0px 0px !important;
        transition: 0.5s;
      }

      .navbar-brand:hover {
        filter:invert(100%) !important;
        opacity: 0.7;
      }

      .tombol_pencarian {
        display: block;
        width: 50px;
        height: auto;
        margin: 0 0 0 0; /* Menggabungkan margin */
        border: 1px solid rgba(14, 89, 129, 0.178);
        border-radius: 20px;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.05); 
        background: rgb(166, 214, 239) url(../img/icon/icon_cari.svg) no-repeat center / 25% !important; /* Menggabungkan properti background */
        transition: 0.1s;
      }

      .tombol_pencarian:hover{
        border: none !important;
        filter:invert(20%) !important;
      }

      .tombol_pencarian:active{
        background-size: 50% !important;
      }

      .bar_pencarian {
        color: rgba(91, 91, 91, 0.57);            
        border: 1px solid rgba(14, 89, 129, 0.178);
        border-radius: 20px;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.05); 
        text-indent: 12px;
        letter-spacing: 1px;
        transition: 0.3s;
      }

      .bar_pencarian input:focus,
      .bar_pencarian input:hover {
        color: #00282b;
        border: 1.5px solid #00282b;
      }

      .base_keranjang, .keranjang {
        margin: auto;
        width: 30px ;
        height: 30px ;
        display: block;
        transition: 0.3s;
        transition: 0.3s;
        justify-content: center; /* Mengatur konten secara horizontal ke tengah */
        align-items: center; /* Mengatur konten secara vertikal ke tengah */
      }

      .keranjang:hover {
        transform: scale(1.2);
      }

      .keranjang:active {
        animation: beat 0.3s alternate;
        transform-origin: center;
      } 

      @keyframes beat{
        to { transform: scale(1.4); }
      }

      .base_username {
        margin: auto;
        width: auto;
        display: inline-flex; /* Menggunakan inline-flex untuk menyesuaikan lebar dengan konten */
        justify-content: center; /* Mengatur konten secara horizontal ke tengah */
        align-items: center; /* Mengatur konten secara vertikal ke tengah */
        border: 1.5px solid #f2f2f2;
        border-radius: 25px;
        color: #ffffff;
        font-family: "Poppins", sans-serif;
        letter-spacing: 1px;
        padding: 5px 12px; /* Padding untuk memberikan ruang di sekitar teks */
        font-weight: 600;
        text-decoration: none;
        transition: 0.3s; /* Hanya perlu ditulis sekali */
      }

      .tulisan {
        overflow: hidden; /* Sembunyikan teks yang melampaui batas */
        white-space: nowrap !important; /* Mencegah teks membungkus ke baris baru */
        text-overflow: ellipsis !important; /* Tambahkan ellipsis (...) */
        max-width: calc(8vw) !important; 
        width: auto;
        text-align: center !important;  
      }

      .base_username:hover {
        background-color: #f2f2f2;
        color: rgb(39, 74, 94);
      }
      
      .base_profil, .profil {
        margin: auto;
        width: auto ;
        height: 30px ;
        display: flex;
        z-index: 110;
        transition: 0.3s;
        padding-right: 30;
        transition: 0.3s;
        right: 0;   
      }
      
      .profil:hover {
        transform: scale(1.2);
      }

      .profil:active {
        animation: beat 0.3s alternate;
        transform-origin: center;
      } 

      .container-fluid {
        max-width: 95% !important;
      }

      @media (max-width: 1245px) {
        .kolom_profil {
          display: none !important;
        }

        .kolom_logo,
        .kolom_pencarian {
            margin-left: 30px;
        }
      }

      @media (max-width: 992px) {
        .kolom_logo {
            margin: 0 0 0 50px;
        }
        .kolom_pencarian {
            margin: auto;
            max-width: 60vw;
        }
        .kolom_keranjang {
            display: none !important;
        }
        .kolom_nama {
            display: none !important;
        }
        .kolom_profil {
            display: flex !important;
        }
        .kolom_konten {
            width: auto !important;
            margin: 0 0 0 30px;
        }
      }

      @media (max-width: 741px) {
        .kolom_konten {
            display: none !important;
        }
        .kolom_logo {
            width: 20vw !important;
        }
        .kolom_pencarian {
            width: 60vw !important;
        }
      }

      @media (max-width: 600  px) {
        .kolom_pencarian {
            display: none;
        }
        .kolom_logo {
            margin: 0 0 0 0 !important;
            width: 100% !important;
            align-items: center;
            justify-content: center;
            display: block !important;
        }
        .navbar-brand {
            align-items: center !important;
            justify-content: center !important;
        }
      }

      /* CSS : Navagation Bar Selesai */

      /* CSS : Sidebar */

      .card {
        background-color: rgb(251, 251, 251);
      }

      .list-group-item {
        background-color:rgb(251, 251, 251);
        border: 1px solid #ddd;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        cursor: pointer; /* Ubah kursor jadi pointer */
        transition: all 0.2s ease; /* Animasi transisi */
      } 

      .list-group-item:hover {
        background-color: rgb(241, 241, 241); /* Latar berubah saat di-hover */
      }

      .list-group-item:active {
        background-color: rgb(230, 231, 231); /* Warna latar saat dipencet */
        color: #fff; /* Warna teks saat dipencet */
        box-shadow: 0 0 10px rgb(198, 214, 232); /* Efek cahaya menyala */
        transform: scale(0.95); /* Efek mengecil sedikit */
      }

      .position-relative {
        width: 100px; 
        height: 100px; 
        overflow: hidden; 
        border-radius: 8px; 
        border: 1px 
        solid #ddd;
      }
          
      /* CSS : Sidebar Selesai */

      /* CSS : Gambar Item */

      .custom-img {
        max-width: 200px; /* Atur lebar maksimum sesuai kebutuhan */
        height: auto; /* Memastikan proporsi gambar tetap terjaga */
      }

      /* CSS : Gambar Item Selesai */

      /* CSS : Detail Produk */

      .product-info {
        font-weight: bold;
        color: #343a40;
      }

      .product-price {
        color: #6c757d; 
      }
      
      /* CSS : Detail Produk Selesai */
      
    </style>

  <!-- Internal CSS Selesai -->

  <!-- Navagation Bar -->

    <nav class="navbar navbar-expand-lg">

      <div class="container-fluid">

          <div class="col-2 kolom_logo">
              <a class="navbar-brand" href="../halaman_beranda/halaman_beranda.php">
                  <img src="../img/icon/logo2.png" alt="logo" width="auto" height="auto">
              </a>
          </div>

          <div class="col-7 kolom_pencarian">
              <!-- Bar Pencarian -->
              <form class="d-flex" style="padding-left: 20px;" method="get" action="../halaman_pencarian/halaman_pencarian.php">
                  <input class="bar_pencarian form-control me-2" type="search" placeholder="Hari ini mau keren yang mana?" aria-label="Search" required maxlength="60" oninvalid="this.setCustomValidity('Isi dong, mau nyari apa kalau kosong.')" oninput="setCustomValidity('')">
                  <button class="tombol_pencarian btn btn-outline-success" type="submit"></button>
              </form>
          </div>

          <div class="col-3 row d-flex justify-content-center kolom_konten">

              <div class="col-auto d-flex kolom_keranjang">
                  <!-- Logo Keranjang -->

                  <td>
                      <a href="" class="base_keranjang">
                          <img src="..\img\icon\icon_keranjang.svg" alt="keranjang" class="keranjang">
                      </a>
                  </td>

              </div>

              <div class="col-md-6 kolom_nama d-flex">
                  <!-- Nama Pengguna -->

                  <td>
                      <a href="../halaman_list/list_sewa.php" class="base_username" id="username">
                          <div class="tulisan">
                              <?php echo $_SESSION['nama_pengguna']; ?>
                          </div>
                      </a>
                  </td>

              </div>

              <div class="col-auto d-flex kolom_profil">
                  <!-- Foto profil -->

                  <td>
                      <a href="../halaman_list/list_sewa.php" class="base_profil">
                      <img src="..\img\icon\icon_profil.svg" alt="photo_profil" class="profil">
                      </a>
                  </td>
              </div>

          </div>

      </div>

    </nav>

  <!-- Navagation Bar Selesai -->

  <!-- Isi Website --> 
  <div class="background" style="background: #eff4f6; padding-top: 100px; margin-top: -75px; min-height: 130vh;">

    <div class="container mt-4 style="padding-bottom:20px;>

        <div class="row">

            <!---- Sidebar ---->

            <div class="col-md-3">
                <div class="card">
                <div class="card-body text-center">
                    <img src="https://via.placeholder.com/100" class="rounded-circle mb-2" alt="Avatar">
                    <h5 class="card-title"><?php echo $_SESSION['nama_pengguna']; ?></h5>
                </div>
                </div>

                <ul class="list-group mt-3">
                    <li class="list-group-item"><i class="fas fa-user"></i>Profil Saya</li> 
                    <li class="list-group-item"><i class="fas fa-map-marker-alt"></i>Alamat</li>
                    <li class="list-group-item"><i class="fas fa-key"></i>Ubah Password</li>
                    <li class="list-group-item"><i class="fas fa-cog"></i>Pengaturan</li>
                </ul>      
                    
            </div> 
            
            <!---- Sidebar selesai ------>

            <div class="col-md-9">
                <ul class="nav nav-tabs">
                <li class="nav-item">
                    <a class="nav-link active" href="../halaman_list/list_sewa.php">List Sewa</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../halaman_list/waktu_penyewaan.php">Waktu Penyewaan Busana</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../halaman_list/riwayat_penyewaan.php">Riwayat Penyewaan</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="../halaman_list/halaman_denda.php">Denda</a>
              </li>
                </ul>

                <!---- Item Produk ---->

                <div class="mt-3">
                    <div class="bg-white p-4 rounded shadow-sm">
                      
                        <!---- Produk 1 ---->

                        <div class="mb-4">
                            <h4 class="fw-bold">Achul.cos</h4>
                            <div class="d-flex align-items-center mb-4">

                                <!-- Kotak Gambar Produk -->

                                <div class="product-info d-flex">
                                    <div class="image text-center p-4 flex-fill">
                                        <img alt="Gambar Sewaan" class="logo img-fluid custom-img" src="../img/foto_kostum/eren.jpg">
                                    </div>
                                </div>
                                
                                <!-- Kotak Gambar Produk Selesai -->

                                <!-- Detail Produk -->

                                <div class="ms-3">
                                    <div class="product-info">
                                     Wedding Dress. Model pendek size M
                                    </div>
                                    <div class="product-price">
                                     IDR 400.000
                                    </div>                                
                                </div>

                                <!-- Detail Produk Selesai -->
                            </div>
                        </div>

                        <!---- Produk 2 ---->

                        <div class="mb-4">
                            <h4 class="fw-bold">Bunga.Store</h4>
                            <div class="d-flex align-items-center mb-4">

                                <!-- Kotak Gambar Produk -->

                                <div class="product-info d-flex">
                                    <div class="image text-center p-4 flex-fill">
                                        <img alt="Gambar Sewaan" class="logo img-fluid custom-img" src="../img/foto_kostum/slytherin.jpg">
                                    </div>
                                </div>
                                
                                <!-- Kotak Gambar Produk Selesai -->

                                <!-- Detail Produk -->

                                <div class="ms-3">
                                    <div class="product-info">
                                     slytherin size M
                                    </div>
                                    <div class="product-price">
                                     IDR 400.000
                                    </div>
                                </div>

                                <!-- Detail Produk Selesai -->
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

  <!-- Isi Website Selesai -->

  </div>

  <!-- Script Section -->

    <!-- Bootstrap JS dari file lokal -->
    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- PHP Akhir -->

    <?php 
      }

      else{
        header("Location: ../halaman_utama/halaman_utama.html");
        exit();
      }
    ?>

    <!-- PHP Selesai -->

  <!-- Script Section Selesai -->

  <!-- Credit -->

    <!--

        Project Based Learning Polibatam 2024

        Jurusan Teknik Informatika, Prodi Teknik Informatika

        Kelas IF B-Pagi, Kelompok 1 - Sekupang

    -->

  <!-- Credit Selesai -->
          
</body>