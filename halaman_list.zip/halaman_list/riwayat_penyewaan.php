<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>WA! JU!</title>
  
  <!-- Custom Font "Poppins" -->

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <!-- Menggunakan Bootstrap CSS dari file lokal -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

  <!-- Menggunakan Bootstrap CSS dari file lokal -->
  <link href="..\bootstrap\css\bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  
  <!-- PHP -->

    <?php 

    session_start();

    if (isset($_SESSION['id']) && 
    isset($_SESSION['nama_pengguna']) &&
    isset($_SESSION['foto_pengguna'])) {

    ?>

  <!-- PHP Selesai -->

<body>

  <!-- Internal CSS -->

    <style>

      * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: "Poppins", sans-serif;
      }

      /* CSS : Navagation Bar */

      .navbar {
        background-image: url(../img/icon/navbar.png);
        background-size: cover;
        border-bottom-left-radius: 20em 28em;
        border-bottom-right-radius: 20em 28em;
        height: 80px;
        box-shadow: 0 0 100px rgba(0, 0, 0, 0.325);
      }

      .navbar-brand {
        display: flex;
        justify-content: center;
        padding: 0px 0px 0% 0px !important;
        margin: 0px 5px 0px 0px !important;
        transition: 0.5s;
      }

      .navbar-brand:hover {
        filter:invert(100%) !important;
        opacity: 0.7;
      }

      .tombol_pencarian {
        display: block;
        width: 50px;
        height: auto;
        margin: 0 0 0 0; /* Menggabungkan margin */
        border: 1px solid rgba(14, 89, 129, 0.178);
        border-radius: 20px;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.05); 
        background: rgb(166, 214, 239) url(../img/icon/icon_cari.svg) no-repeat center / 25% !important; /* Menggabungkan properti background */
        transition: 0.1s;
      }

      .tombol_pencarian:hover{
        border: none !important;
        filter:invert(20%) !important;
      }

      .tombol_pencarian:active{
        background-size: 50% !important;
      }

      .bar_pencarian {
        color: rgba(91, 91, 91, 0.57);            
        border: 1px solid rgba(14, 89, 129, 0.178);
        border-radius: 20px;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.05); 
        text-indent: 12px;
        letter-spacing: 1px;
        transition: 0.3s;
      }

      .bar_pencarian input:focus,
      .bar_pencarian input:hover {
        color: #00282b;
        border: 1.5px solid #00282b;
      }

      .base_keranjang, .keranjang {
        margin: auto;
        width: 30px ;
        height: 30px ;
        display: block;
        transition: 0.3s;
        transition: 0.3s;
        justify-content: center; /* Mengatur konten secara horizontal ke tengah */
        align-items: center; /* Mengatur konten secara vertikal ke tengah */
      }

      .keranjang:hover {
        transform: scale(1.2);
      }

      .keranjang:active {
        animation: beat 0.3s alternate;
        transform-origin: center;
      } 

      @keyframes beat{
        to { transform: scale(1.4); }
      }

      .base_username {
        margin: auto;
        width: auto;
        display: inline-flex; /* Menggunakan inline-flex untuk menyesuaikan lebar dengan konten */
        justify-content: center; /* Mengatur konten secara horizontal ke tengah */
        align-items: center; /* Mengatur konten secara vertikal ke tengah */
        border: 1.5px solid #f2f2f2;
        border-radius: 25px;
        color: #ffffff;
        font-family: "Poppins", sans-serif;
        letter-spacing: 1px;
        padding: 5px 12px; /* Padding untuk memberikan ruang di sekitar teks */
        font-weight: 600;
        text-decoration: none;
        transition: 0.3s; /* Hanya perlu ditulis sekali */
      }

      .tulisan {
        overflow: hidden; /* Sembunyikan teks yang melampaui batas */
        white-space: nowrap !important; /* Mencegah teks membungkus ke baris baru */
        text-overflow: ellipsis !important; /* Tambahkan ellipsis (...) */
        max-width: calc(8vw) !important; 
        width: auto;
        text-align: center !important;  
      }

      .base_username:hover {
        background-color: #f2f2f2;
        color: rgb(39, 74, 94);
      }
      
      .base_profil, .profil {
        margin: auto;
        width: auto ;
        height: 30px ;
        display: flex;
        z-index: 110;
        transition: 0.3s;
        padding-right: 30;
        transition: 0.3s;
        right: 0;   
      }
      
      .profil:hover {
        transform: scale(1.2);
      }

      .profil:active {
        animation: beat 0.3s alternate;
        transform-origin: center;
      } 

      .container-fluid {
        max-width: 95% !important;
      }

      @media (max-width: 1245px) {
        .kolom_profil {
          display: none !important;
        }

        .kolom_logo,
        .kolom_pencarian {
            margin-left: 30px;
        }
      }

      @media (max-width: 992px) {
        .kolom_logo {
            margin: 0 0 0 50px;
        }
        .kolom_pencarian {
            margin: auto;
            max-width: 60vw;
        }
        .kolom_keranjang {
            display: none !important;
        }
        .kolom_nama {
            display: none !important;
        }
        .kolom_profil {
            display: flex !important;
        }
        .kolom_konten {
            width: auto !important;
            margin: 0 0 0 30px;
        }
      }

      @media (max-width: 741px) {
        .kolom_konten {
            display: none !important;
        }
        .kolom_logo {
            width: 20vw !important;
        }
        .kolom_pencarian {
            width: 60vw !important;
        }
      }

      @media (max-width: 600  px) {
        .kolom_pencarian {
            display: none;
        }
        .kolom_logo {
            margin: 0 0 0 0 !important;
            width: 100% !important;
            align-items: center;
            justify-content: center;
            display: block !important;
        }
        .navbar-brand {
            align-items: center !important;
            justify-content: center !important;
        }
      }

      /* CSS : Navagation Bar Selesai */

      /* CSS : Sidebar */

      .list-group-item {
        .card {
          border: 1px solid #ddd;
          box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
          border-radius: 8px;
          cursor: pointer; /* Ubah kursor jadi pointer */
          transition: all 0.2s ease; /* Animasi transisi */
        }
      } 

      .list-group-item:hover {
        background-color: #e9ecef; /* Latar berubah saat di-hover */
      }

      .list-group-item:active {
        background-color: #007bff; /* Warna latar saat dipencet */
        color: #fff; /* Warna teks saat dipencet */
        box-shadow: 0 0 10px #007bff; /* Efek cahaya menyala */
        transform: scale(0.95); /* Efek mengecil sedikit */
      }

      .position-relative {
        width: 100px; 
        height: 100px; 
        overflow: hidden; 
        border-radius: 8px; 
        border: 1px 
        solid #ddd;
      }
          
      /* CSS : Sidebar Selesai */

      /* CSS : Gambar Item */

      .custom-img {
      max-width: 200px; /* Atur lebar maksimum sesuai kebutuhan */
      height: auto; /* Memastikan proporsi gambar tetap terjaga */
      }

      /* CSS : Gambar Item Selesai */
      
      /* CSS : Isi Website Selesai */ 

    </style>

  <!-- Internal CSS Selesai -->

  <!-- Navagation Bar -->

    <nav class="navbar navbar-expand-lg">

      <div class="container-fluid">

          <div class="col-2 kolom_logo">
              <a class="navbar-brand" href="../halaman_beranda/halaman_beranda.php">
                  <img src="../img/icon/logo2.png" alt="logo" width="auto" height="auto">
              </a>
          </div>

          <div class="col-7 kolom_pencarian">
              <!-- Bar Pencarian -->
              <form class="d-flex" style="padding-left: 20px;" method="get" action="../halaman_pencarian/halaman_pencarian.php">
                  <input class="bar_pencarian form-control me-2" type="search" placeholder="Hari ini mau keren yang mana?" aria-label="Search" required maxlength="60" oninvalid="this.setCustomValidity('Isi dong, mau nyari apa kalau kosong.')" oninput="setCustomValidity('')">
                  <button class="tombol_pencarian btn btn-outline-success" type="submit"></button>
              </form>
          </div>

          <div class="col-3 row d-flex justify-content-center kolom_konten">

              <div class="col-auto d-flex kolom_keranjang">
                  <!-- Logo Keranjang -->

                  <td>
                      <form action="../halaman_keranjang/halaman_keranjang.php" method="post" name="tombol_keranjang">
                        <button style="border: none; background: transparent;" class="base_keranjang" type="submit">
                          <img src="..\img\icon\icon_keranjang.svg" alt="keranjang" class="keranjang">
                        </button>
                      </form>
                  </td>

              </div>

              <div class="col-md-6 kolom_nama d-flex">
                  <!-- Nama Pengguna -->

                  <td>
                      <a href="../halaman_list/list_sewa.php" class="base_username" id="username">
                          <div class="tulisan">
                              <?php echo $_SESSION['nama_pengguna']; ?>
                          </div>
                      </a>
                  </td>

              </div>

              <div class="col-auto d-flex kolom_profil">
                  <!-- Foto profil -->

                  <td>
                  <a href="../halaman_list/list_sewa.php" class="base_profil">
                    <img src="<?php if($_SESSION['foto_pengguna'] == NULL) {echo "..\img\icon\profile.jpg";} else{echo $_SESSION['foto_pengguna'];}?>" style="transform: scale(1.3); aspect-ratio: 1/1; object-fit: cover;" alt="photo_profil" class="profil rounded-circle border border-success border-opacity-25 shadow">
                  </a>
                  <style>
                    .base_profil:hover, .profil:hover {
                      transform: scale(1.3);
                      }
                  </style>
                  </td>
              </div>

          </div>

      </div>

    </nav>

  <!-- Navagation Bar Selesai -->

  <!-- Isi Website -->

    <div class="isi" style="padding-bottom: 160px;">

      <div class="container mt-4" style="padding-bottom: 20px;">

        <div class="row">

          <!-- Sidebar -->

            <div class="col-md-3 mt-5">

              <!-- Card untuk profil pengguna -->
                <div class="card">
                  <div class="card-body text-center p-1">
                    <img alt="Foto Profil" class="rounded-circle my-3 shadow-lg" height="100" id="sidebar-profile-image" src="<?php if($_SESSION['foto_pengguna'] == NULL) {echo "..\img\icon\profile.jpg";} else{echo $_SESSION['foto_pengguna'];}?>" width="100" style="aspect-ratio: 1/1; object-fit: cover;"/>
                    <p class="username fs-5 fw-bolder"><?= $_SESSION['nama_pengguna'] ?></p>
                  </div>
                </div>

              <!-- Daftar menu di sidebar -->

                <div class="card mt-3">
                  <div class="card-body">
                    <div class="container row d-flex mt-2"> <!-- Profil Saya -->
                      <div class="col-2 d-flex align-items-start mx-auto mt-1">
                        <i class="fas fa-user hover-overlay fs-6"></i>
                      </div>
                      <div class="col-8 list-group d-flex p-0 m-auto">
                          <a href="../halaman_pengaturan_user/halaman_pengaturan_user.php" class="text-decoration-none text-dark fw-bold fs-6 hover-overlay mb-1">Profil Saya</a>
                          <a href="../halaman_pengaturan_user/halaman_pengaturan_user.php" class="text-decoration-none text-dark fw-normal fs-6 hover-overlay mb-1">Pengaturan Akun</a>
                          <a href="../halaman_pengaturan_user/halaman_pengaturan_user.php" class="text-decoration-none text-dark fw-normal fs-6 hover-overlay mb-1">Ganti Password</a>
                      </div>
                    </div>

                    <div class="container row d-flex mt-2"> <!-- Informasi Sewaan -->
                      <div class="col-2 d-flex align-items-start mx-auto">
                        <img class="hover-overlay" src="..\img\icon\info.png" alt="Info" style="width: 20px; height: 20px; object-fit: cover;">
                      </div>
                      <div class="col-8 list-group m-auto">
                          <a href="../halaman_list/list_sewa.php" class="text-decoration-none text-dark fw-bold fs-6 hover-overlay mb-1">Informasi Sewaan</a>
                          <a href="../halaman_list/list_sewa.php" class="text-decoration-none text-dark fw-normal fs-6 hover-overlay mb-1">List Sewa</a>
                          <a href="../halaman_list/waktu_penyewaan.php" class="text-decoration-none text-dark fw-normal fs-6 hover-overlay mb-1">Waktu Penyewaan</a>
                          <a href="../halaman_list/riwayat_penyewaan.php" class="text-decoration-none text-dark fw-normal fs-6 hover-overlay mb-1">Riwayat Penyewaan</a>
                          <a href="../halaman_list/halaman_denda.php" class="text-decoration-none text-dark fw-normal fs-6 hover-overlay mb-1">Denda</a>
                      </div>
                    </div>

                    <div class="container row d-flex mt-2"> <!-- Profil Saya -->
                      <div class="col-2 d-flex align-items-start mx-auto">
                        <i class="fas fa-sign-out-alt hover-overlay fs-6 mb-1 mt-1 text-danger"></i>
                      </div>
                      <div class="col-8 list-group d-flex p-0 m-auto">
                          <a href="../mysql_database/logout.php" class="text-decoration-none text-danger fw-bold fs-6 hover-overlay mb-1">Keluar</a>
                      </div>
                    </div>
                  </div>
                </div>
                
              <!-- Daftar menu di sidebar Selesai -->

            </div> 

            <style>
              .hover-overlay{
                transition: 0.3s;
              }
              .hover-overlay:hover {
                transform: scale(1.1);
              }
            </style>

          <!---- Sidebar selesai ------>

            <div class="col-md-9">
              <ul class="nav nav-tabs">
                <li class="nav-item">
                    <a class="nav-link" href="../halaman_list/list_sewa.php">List Sewa</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../halaman_list/waktu_penyewaan.php">Waktu Penyewaan Busana</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="../halaman_list/riwayat_penyewaan.php">Riwayat Penyewaan</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="../halaman_list/halaman_denda.php">Denda</a>
                </li>
              </ul>
              <!---- Item Produk ---->
              
              <div class="mt-3">

                <div class="bg-white p-4 rounded shadow-sm">
                  
                  <!---- Produk 1 ---->
                  <div class="mb-4">

                      <h4 class="fw-bold">Diagon Alley</h4>

                      <div class="d-flex align-items-center mb-4">

                          <!-- Kotak Gambar Produk -->

                          <div class="product-info d-flex">
                              <div class="image text-center p-4 flex-fill">
                                  <img alt="Gambar Sewaan" class="img-fluid custom-img" src="../img/foto_kostum/snow.jpg">
                              </div>
                          </div>

                          <!-- Kotak Gambar Produk Selesai -->

                          <!-- Detail Produk -->
                        
                          <div class="details flex-fill">
                              <h5><p class="fw-bold" style="color: rgb(200, 61, 87)">Informasi Produk:</p></h5>
                              <p >Dress Snow White</p>
                              <h5><p class="fw-bold" style="color: rgb(200, 61, 87)">Waktu Pemesanan:</p></h5>
                              <div class="order-history">
                                  <ul style="list-style: none; padding: 0; margin: 0;">
                                      <li style="display: flex; align-items: center; margin-bottom: 8px;">
                                          <i class="fas fa-times-circle" style="color: red; margin-right: 12px;"></i> Pesanan Masih Dalam Sewaan
                                      </li>
                                      <li style="display: flex; align-items: center; margin-bottom: 8px;">
                                          <i class="fas fa-check-circle" style="color: green; margin-right: 12px;"></i> Pesanan Telah Selesai
                                      </li>
                                  </ul>
                              </div>
                              <div class="container mt-5 ">
                                  <button class="btn btn-danger">Lihat Konfirmasi Pengembalian</button>
                              </div>
                          </div>

                          <!-- Detail Produk Selesai -->

                      </div>
                      
                  </div>

                  <!---- Produk 2 ---->
                  <div class="mb-4">

                      <h4 class="fw-bold">Diagon Alley</h4>

                      <div class="d-flex align-items-center mb-4">

                          <!-- Kotak Gambar Produk -->

                          <div class="product-info d-flex">
                              <div class="image text-center p-4 flex-fill">
                                  <img alt="Gambar Sewaan" class="logo img-fluid custom-img" src="../img/foto_kostum/elsa.jpg">
                              </div>
                          </div>

                          <!-- Kotak Gambar Produk Selesai -->

                          <!-- Detail Produk -->
    
                          <div class="details flex-fill">
                              <h5><p class="fw-bold" style="color:rgb(200, 61, 87)">Informasi Produk:</p></h5>
                              <p>Dress Elsa Frozen Size M</p>
                              <h5><p class="fw-bold" style="color:rgb(200, 61, 87)">Waktu Pemesanan:</p></h5>
                              <div class="order-history">
                                  <ul style="list-style: none; padding: 0; margin: 0;">
                                      <li style="display: flex; align-items: center; margin-bottom: 8px;">
                                          <i class="fas fa-times-circle" style="color: red; margin-right: 12px;"></i> Pesanan Masih Dalam Sewaan
                                      </li>
                                      <li style="display: flex; align-items: center; margin-bottom: 8px;">
                                          <i class="fas fa-check-circle" style="color: green; margin-right: 12px;"></i> Pesanan Telah Selesai
                                      </li>
                                  </ul>
                              </div>
                              <div class="container mt-5">
                                  <button class="btn btn-danger">Lihat Konfirmasi Pengembalian</button>
                              </div>
                          </div>

                          <!-- Detail Produk Selesai -->

                      </div>

                  </div>

              </div>

              <!-- Item Produk Selesai -->

            </div>

        </div>

          </div>
      </div>

    </div>

  <!-- Isi Website Selesai -->

  <!-- Footer -->

    <link rel="stylesheet" href="..\footer\footer.css">

    <?php

          // Koneksi ke database
          $con = mysqli_connect("localhost", "root", "", "waju");

          // Cek koneksi
          if (!$con) {
              die("Koneksi gagal: " . mysqli_connect_error());
          }

          $query = "SELECT * FROM footer"; // Menggunakan nama_baju
          $result = mysqli_query($con, $query);

          $footer = mysqli_fetch_assoc($result);
          
          echo $footer['footer'];

    ?>

  <!-- Footer Selesai -->

  <!-- Script Section -->

    <!-- Bootstrap JS dari file lokal -->
    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- PHP Akhir -->

    <?php 
      }

      else{
        header("Location: ../halaman_utama/halaman_utama.html");
        exit();
      }
    ?>

    <!-- PHP Selesai -->

  <!-- Script Section Selesai -->

  <!-- Credit -->

    <!--

        Project Based Learning Polibatam 2024

        Jurusan Teknik Informatika, Prodi Teknik Informatika

        Kelas IF B-Pagi, Kelompok 1 - Sekupang

    -->

  <!-- Credit Selesai -->
          
</body>