<!DOCTYPE html>

<html lang="en">

    <head>

        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Halaman Masuk</title>
        <link rel="stylesheet" href="halaman_masuk_admin.css">

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

        <!-- Icon & Bootstrap -->

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

        <!-- Logo Tab -->

        <link rel="icon" type="image/x-icon" href="../img/icon/logo_atas.svg">

        <style>

        *	{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: "Poppins", sans-serif;
            line-height: 1.6;
            padding-top: 70px;
            caret-color: transparent;
            background-image: url(../img/foto/bg_baru.svg);
            background-size: cover;
            background-repeat: no-repeat;
        }


        br {
            -webkit-user-select: none;
            /* Chrome, Opera */
            -webkit-touch-callout: none;
            /* Safari */
            -moz-user-select: none;
            /* Firefox */
            -ms-user-select: none;
            /* Internet Explorer/Edge */
            user-select: none;
            /* Standard property */
        }

        .navbar {
            background-image: url(../img/icon/navbar.png);
            background-size: cover;
            width: 104%;
            height: 100px;
            display: block;
            justify-content: space-between;
            align-items: center;
            position: fixed;
            border-bottom-left-radius: 20em 28em;
            border-bottom-right-radius: 20em 28em;
            margin-left: -2%;
            margin-right: 0;
            padding: 1rem 0;
            top: 0;
            left: 0;
            box-shadow: 0 0 100px rgba(0, 0, 0, 0.325);
            z-index: 100;
        }

        .navbar .container {
            display: flex;
            justify-content: space-between; 
            align-items: center;
            max-width: 100%;
        }

        .navbar .container a {
            margin-left: 50px ;
        }

        .logo {
            width: 250px;
            margin: none;
            object-fit: cover;
            display: block;
            transition: 0.3s;
            padding-right: 10px;
        }

        .slogan {
            text-decoration: none;
            margin: auto;
            width: 3000px;
            padding-left: 20px;
            letter-spacing: 3px;
            color: white;
        }

        .navbar .container .logo:hover {
            filter:invert(100%) !important;
            opacity: 0.7;
        }

        .navbar .masuk-daftar {
            margin-top: 0;
            margin-right: 5%;
        }

        .masuk {
                background-color: #f2f2f2; 
                color: #a6a6a6;
                padding: 10px 20px;
                text-decoration: none;
                border-radius: 30px;
                font-size: 1.1rem;
                /*margin-right: 5%;*/
                /*margin-top: -2%;*/
                transition: 0.3s;
        }

        .masuk:hover {
            filter:invert(100%) !important;
            opacity: 0.7;
        }

        .daftar {
            background-color: none;
            border: 2px #f2f2f2 solid; 
            color: #f2f2f2;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 30px;
            font-size: 1.1rem;
            /*margin-right: 20%;*/
            /*margin-top: -4%;*/
            transition: 0.3s;
        }

        .daftar:hover {
        filter:invert(100%) !important;
        opacity: 0.7;
        }

        @media (max-width: 792px) {
            .slogan {
                display: none;
            }
        }

        </style>

    </head>

    <body>

    <!-- Navigation Bar --> <!------------------------------------------------------------------------------->

    <nav class="navbar">
            <div class="container">

            <!-- Logo -->

               <a href="..\halaman_utama\halaman_utama.html"> 
                 <img src="../img/icon/logo_tokowaju.svg" alt="logo" class="logo">
                </a>

            <!------------------------------------------------>

            <!-- Slogan -->

                <p class="slogan">
                    Gabung Toko WA!JU! Sekarang Juga!
                </p>

                <style>

                    @media (max-width: 792px) {
                            .slogan {
                                display: none !important;
                            }
                        }

                </style>

            <!------------------------------------------------>

            <!-- Tombol Daftar & Masuk -->

                <div class="masuk-daftar"> 
                    <table>
                        <tr>
                            <td style="padding-left: 10%;"><a href="..\halaman_daftar_admin\halaman_daftar_admin.php" class="daftar" style="font-weight: bold;">DAFTAR</a></td>
                            <td><a href="..\halaman_masuk_admin\halaman_masuk_admin.php" class="masuk" style="font-weight: bold;">MASUK</a></td>
                        </tr>
                     </table>   

                </div>
            </div>

             <!------------------------------------------------>
             
        </nav>

    <!-- Navigation Bar Selesai --> <!------------------------------------------------------------------------------->

        <!-- Isi Website -->

        <div class="isi">

            <div class="login-box">
                <div class="login-header">
                    <header>Masuk Toko</header>
                    <br>
                </div>

                <form action="../mysql_database/login_admin.php" method="post">

                    <?php if (isset($_GET['error'])) {
                        echo <<<GFG
                        <div class="alert">
                            <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span>
                            <p style="font-size: 14px;">Nama Toko atau Kata Sandi Salah</p>
                        </div>

                        <style>
                        /* The alert message box */
                        .alert {
                        padding: 20px;
                        background-color: #f44336; /* Red */
                        color: white;
                        margin-bottom: 15px;
                        }

                        /* The close button */
                        .closebtn {
                        margin-left: 15px;
                        color: white;
                        font-weight: bold;
                        float: right;
                        font-size: 22px;
                        line-height: 20px;
                        cursor: pointer;
                        transition: 0.3s;
                        }

                        /* When moving the mouse over the close button */
                        .closebtn:hover {
                        color: black;
                        }
                        </style>

                        <style>
                        .alert {
                        opacity: 1;
                        transition: opacity 0.6s; /* 600ms to fade out */
                        }
                        </style>

                        <script>
                        // Get all elements with class="closebtn"
                        var close = document.getElementsByClassName("closebtn");
                        var i;

                        // Loop through all close buttons
                        for (i = 0; i < close.length; i++) {
                        // When someone clicks on a close button
                        close[i].onclick = function(){

                            // Get the parent of <span class="closebtn"> (<div class="alert">)
                            var div = this.parentElement;

                            // Set the opacity of div to 0 (transparent)
                            div.style.opacity = "0";

                            // Hide the div after 600ms (the same amount of milliseconds it takes to fade out)
                            setTimeout(function(){ div.style.display = "none"; }, 600);
                        }
                        }
                        </script>
                        GFG;
                    } ?>

                    <div class="input-box">
                        <input type="text" name="nama_toko" id="nama_toko" class="input-field" placeholder="Nama Toko" autocomplete="off" required>
                    </div>

                    <div type="input-box"> 
                        <input type="password" name="kata_sandi" id="kata_sandi" class="input-field" placeholder="Kata Sandi" required>
                    </div>

                    <div class="Input-Submit">
                        <button type="submit" class="submit-btn">
                            Masuk
                        </button>
                    </div>
                    
                </form>


                <div class="forgot">
                    <section>
                    <span style="padding-top: 20px;"><a href="../halaman_masuk/halaman_masuk.php" style="text-decoration: none;">Mau Nyewa Baju Aja?</a></span>
                    </section>
                </div>
                <div class="Input-submit">
                    <p> 
                        belum punya toko?
                        <span style="padding-left: 135px;"><a href="..\halaman_daftar_admin\halaman_daftar_admin.php" style="text-decoration: none;"> Buat Toko</a></span>
                    </p>
                </div>

            </div>

        </div>

        <!-- Isi Website Selesai -->

        <!-- Script -->

        <script>

            document.addEventListener('DOMContentLoaded', function() {
            var usernameInput = document.getElementById('nama_toko');

            usernameInput.addEventListener('input', function(e) {
                var start = this.selectionStart;
                var end = this.selectionEnd;

                // Convert text to lowercase
                this.value = this.value.toLowerCase();

                // Restore the selection range
                this.setSelectionRange(start, end);
            });
            });

            </script>

        <!-- Script Selesai -->

</body>

</html>

