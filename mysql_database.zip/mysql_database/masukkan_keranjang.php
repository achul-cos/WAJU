<?php

include "connect_database.php";


if (isset($_POST['tanggal_sewa_keranjang']) && 
    isset($_POST['nama_baju_keranjang']) &&
    isset($_POST['kategori_baju_keranjang']) &&
    isset($_POST['harga_baju_keranjang']) &&
    isset($_POST['pemilik_baju_keranjang']) &&
    isset($_POST['alamat_toko_keranjang']) &&
    isset($_POST['foto_baju_keranjang']) &&
    isset($_POST['ukuran_baju_keranjang']) &&
    isset($_POST['id_baju_databaju']) &&
    isset($_POST['pilih_ukuran_s']) &&
    isset($_POST['pilih_ukuran_m']) &&
    isset($_POST['pilih_ukuran_l']) &&
    isset($_POST['nama_pengguna']) &&
    isset($_POST['id_toko']) &&
    isset($_POST['tombol_baju'])
    ) 
    {

        function validate($data){
        // Hanya membersihkan karakter yang tidak diinginkan
        return htmlspecialchars(trim($data));
        }

        $tanggal_sewa_keranjang = validate($_POST['tanggal_sewa_keranjang']);
        $nama_baju_keranjang = validate($_POST['nama_baju_keranjang']);
        $kategori_baju_keranjang = validate($_POST['kategori_baju_keranjang']);
        $harga_baju_keranjang = validate($_POST['harga_baju_keranjang']);
        $pemilik_baju_keranjang = validate($_POST['pemilik_baju_keranjang']);
        $alamat_toko_keranjang = validate($_POST['alamat_toko_keranjang']);
        $foto_baju_keranjang = validate($_POST['foto_baju_keranjang']);
        $ukuran_baju_keranjang = validate($_POST['ukuran_baju_keranjang']);
        $id_baju_databaju = validate($_POST['id_baju_databaju']);
        $pilih_ukuran_s = validate($_POST['pilih_ukuran_s']);
        $pilih_ukuran_m = validate($_POST['pilih_ukuran_m']);
        $pilih_ukuran_l = validate($_POST['pilih_ukuran_l']);
        $nama_pengguna = validate($_POST['nama_pengguna']);
        $id_toko = validate($_POST['id_toko']);
        $bulan_sewa = date('F');
        $tahun_sewa = date('Y');

        $sql = "INSERT INTO `$nama_pengguna`
        (nama_baju, 
        harga_baju, 
        foto_baju, 
        pemilik_baju, 
        kategori_baju,	
        ukuran_baju, 
        ukuran_s, 
        ukuran_m, 
        ukuran_l, 
        tanggal_sewa, 
        bulan_sewa, 
        tahun_sewa,  
        alamat_pengambilan, 
        nama_penyewa,  
        id_databaju,
        id_toko) VALUES
        ('$nama_baju_keranjang', 
        '$harga_baju_keranjang', 
        '$foto_baju_keranjang', 
        '$pemilik_baju_keranjang', 
        '$kategori_baju_keranjang',	
        '$ukuran_baju_keranjang', 
        '$pilih_ukuran_s', 
        '$pilih_ukuran_m', 
        '$pilih_ukuran_l', 
        '$tanggal_sewa_keranjang', 
        '$bulan_sewa', 
        '$tahun_sewa',  
        '$alamat_toko_keranjang', 
        '$nama_pengguna',  
        '$id_baju_databaju',
        '$id_toko')";

        $result = mysqli_query($conn, $sql);

        if (!$result) {
            die("Query gagal: " . mysqli_error($conn));
        } else {
            // Redirect or show success message
            header("Location: ../halaman_katalog/halaman_katalog.php?tombol_baju=" . urlencode($_POST['tombol_baju'])); // Ganti dengan halaman sukses yang sesuai
            exit();
        }

    } else {
        header("Location: Error=Tidak Bisa Menambahkan Keranjang");
        exit();
    }
?>