<?php 
session_start(); 
include "connect_database.php";

if (isset($_POST['nama_pengguna']) && isset($_POST['email'])
    && isset($_POST['kata_sandi'])) {

	function validate($data){
       $data = trim($data);
	   $data = stripslashes($data);
	   $data = htmlspecialchars($data);
	   return $data;
	}

	$nama_pengguna = validate($_POST['nama_pengguna']);
	$email = validate($_POST['email']);
	$kata_sandi = validate($_POST['kata_sandi']);

	$user_data = 'nama_pengguna='. $nama_pengguna. '&email='. $email;

	if (empty($nama_pengguna)) {
		header("Location:  ../halaman_registrasi/registrasi.php?error=data_tidak_lengkap&$user_data");
	    exit();
	}else if(empty($email)){
        header("Location:  ../halaman_registrasi/registrasi.php?error=data_tidak_lengkap&$user_data");
	    exit();
	}
	else if(empty($kata_sandi)){
        header("Location:  ../halaman_registrasi/registrasi.php?error=data_tidak_lengkap&$user_data");
	    exit();
	}

	else{

		// hashing the password
        $kata_sandi = md5($kata_sandi);

		
	    $sql = "SELECT * FROM dataakun WHERE nama_pengguna='$nama_pengguna'";
		$result = mysqli_query($conn, $sql);
		
		if (mysqli_num_rows($result) > 0) {
			header("Location:  ../halaman_registrasi/registrasi.php?error=nama_pengguna_telah_ada&$user_data");
	        exit();
		}else {
			$sql_keranjang = "CREATE TABLE `$nama_pengguna` (
				`id` INT(100) NOT NULL AUTO_INCREMENT,
				`nama_baju` VARCHAR(255) DEFAULT NULL,
				`harga_baju` INT(255) DEFAULT NULL,
				`foto_baju` VARCHAR(300) DEFAULT NULL,
				`pemilik_baju` VARCHAR(300) DEFAULT NULL,
				`kategori_baju` VARCHAR(300) DEFAULT NULL,
				`ukuran_baju` VARCHAR(300) DEFAULT NULL,
				`ukuran_s` BOOLEAN DEFAULT NULL,
				`ukuran_m` BOOLEAN DEFAULT NULL,
				`ukuran_l` BOOLEAN DEFAULT NULL,
				`tanggal_sewa` VARCHAR(300) DEFAULT NULL,
				`bulan_sewa` VARCHAR(300) DEFAULT NULL,
				`tahun_sewa` VARCHAR(300) DEFAULT NULL,
				`tanggal_pengembalian` VARCHAR(300) DEFAULT NULL,
				`bulan_pengembalian` VARCHAR(300) DEFAULT NULL,
				`tahun_pengembalian` VARCHAR(300) DEFAULT NULL,
				`alamat_pengambilan` VARCHAR(300) DEFAULT NULL,
				`nama_penyewa` VARCHAR(300) DEFAULT NULL,
				`alamat_penyewa` VARCHAR(300) DEFAULT NULL,
				`nik_penyewa` VARCHAR(300) DEFAULT NULL,
				`kontak_penyewa` VARCHAR(300) DEFAULT NULL,
				`status_baju` VARCHAR(300) DEFAULT NULL,
				`blokir_akun` BOOLEAN DEFAULT NULL,
				`id_databaju` INT(100) DEFAULT NULL,
				`id_toko` INT(100) DEFAULT NULL,
				PRIMARY KEY (`id`)
			) ENGINE = InnoDB;";			
			$keranjang = mysqli_query($conn, $sql_keranjang);
			
           $sql2 = "INSERT INTO dataakun(nama_pengguna, kata_sandi, email) VALUES('$nama_pengguna', '$kata_sandi', '$email')";
           $result2 = mysqli_query($conn, $sql2);
           if ($result2) {
           	 header("Location:  ../halaman_registrasi/registrasi.php?success=akun_berhasil_dibuat");
	         exit();
           }else {
	           	header("Location:  ../halaman_registrasi/registrasi.php?error=unknown_error_occurred&$user_data");
		        exit();
           }
		}
	}
	
}else{
	header("Location: ../halaman_registrasi/registrasi.php");
	exit();
}