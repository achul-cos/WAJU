<?php 
session_start(); 
include "connect_database.php";

if (isset($_GET['pencarian'])) {

    function validate($data){
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

    $pencarian = validate($_GET['pencarian']);



}else{
	header("Location: ../halaman_beranda/halaman_beranda.php");
	exit();
}