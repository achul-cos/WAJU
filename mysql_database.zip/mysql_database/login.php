<?php 
session_start(); 
include "connect_database.php";

if (isset($_POST['nama_pengguna']) && isset($_POST['kata_sandi'])) {

	function validate($data){
       $data = trim($data);
	   $data = stripslashes($data);
	   $data = htmlspecialchars($data);
	   return $data;
	}

	$nama_pengguna = validate($_POST['nama_pengguna']);
	$kata_sandi = validate($_POST['kata_sandi']);

	if (empty($nama_pengguna)) {
		header("Location: halaman_masuk.php?error=User Name is required");
	    exit();
	}else if(empty($kata_sandi)){
        header("Location: halaman_masuk.php?error=Password is required");
	    exit();
	}else{

		// hashing the password
		$kata_sandi = md5($kata_sandi);

		$kata_sandi = $kata_sandi;
        
		$sql = "SELECT * FROM dataakun WHERE nama_pengguna='$nama_pengguna' AND kata_sandi='$kata_sandi'";

		$result = mysqli_query($conn, $sql);

		if (mysqli_num_rows($result) === 1) {
			$row = mysqli_fetch_assoc($result);
            if ($row['nama_pengguna'] === $nama_pengguna && $row['kata_sandi'] === $kata_sandi) {
            	$_SESSION['nama_pengguna'] = $row['nama_pengguna'];
            	$_SESSION['email'] = $row['email'];
            	$_SESSION['id'] = $row['id'];
				$_SESSION['foto_pengguna'] = $row['foto_pengguna'];
            	header("Location: ../halaman_beranda/halaman_beranda.php");
		        exit();
            }else{
				header("Location: ../halaman_masuk/halaman_masuk.php?error=pass_atau_nama_salah");
		        exit();
			}
		}else{
			header("Location: ../halaman_masuk/halaman_masuk.php?error=pass_atau_nama_salah");
	        exit();
		}
	}
	
}else{
	header("Location: halaman_login.php");
	exit();
}