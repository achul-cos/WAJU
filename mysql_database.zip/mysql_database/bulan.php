<?php 

echo  date('F,Y');

?>