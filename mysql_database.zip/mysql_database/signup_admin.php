<?php 
session_start(); 
include "connect_database.php";

if (isset($_POST['nama_toko']) && isset($_POST['email_toko'])
    && isset($_POST['kata_sandi'])) {

	function validate($data){
       $data = trim($data);
	   $data = stripslashes($data);
	   $data = htmlspecialchars($data);
	   return $data;
	}

	$nama_toko = validate($_POST['nama_toko']);
	$email_toko = validate($_POST['email_toko']);
	$kata_sandi = validate($_POST['kata_sandi']);
	$tanggal_daftar = date('d');
	$bulan_daftar = date('F');
	$tahun_daftar = date('Y');

	$user_data = 'nama_toko='. $nama_toko. '&email='. $email_toko;

	if (empty($nama_toko)) {
		header("Location:  ../halaman_daftar_admin/halaman_daftar_admin.php?error=data_tidak_lengkap&$user_data");
	    exit();
	}else if(empty($email_toko)){
        header("Location:  ../halaman_daftar_admin/halaman_daftar_admin.php?error=data_tidak_lengkap&$user_data");
	    exit();
	}
	else if(empty($kata_sandi)){
        header("Location:  ../halaman_daftar_admin/halaman_daftar_admin.php?error=data_tidak_lengkap&$user_data");
	    exit();
	}

	else{

		// hashing the password
        $kata_sandi = md5($kata_sandi);

		$sql_database_admin = "CREATE TABLE `toko_$nama_toko` (
			`id_baju` INT NOT NULL AUTO_INCREMENT,
			`nama_baju` VARCHAR(300) DEFAULT NULL,
			`kategori_baju` VARCHAR(300) DEFAULT NULL,
			`harga_baju` INT DEFAULT NULL,
			`rating_baju` INT DEFAULT NULL,
			`foto_baju` VARCHAR(300) DEFAULT NULL,
			`deskripsi_baju` TEXT,
			`status_tersedia` TINYINT(1) DEFAULT '1',
			`nama_pemilik` VARCHAR(300) DEFAULT NULL,
			`kontak_pemilik` VARCHAR(300) DEFAULT NULL,
			`alamat_pemilik` VARCHAR(300) DEFAULT NULL,
			`id_pemilik` INT DEFAULT NULL,
			`ukuran_s` INT DEFAULT NULL,
			`ukuran_m` INT DEFAULT NULL,
			`ukuran_l` INT DEFAULT NULL,
			`jumlah_baju` INT GENERATED ALWAYS AS (((`ukuran_s` + `ukuran_m`) + `ukuran_l`)) STORED,
			`tersewa_baju_s` INT DEFAULT NULL,
			`tersewa_baju_m` INT DEFAULT NULL,
			`tersewa_baju_l` INT DEFAULT NULL,
			`jumlah_tersewa` INT GENERATED ALWAYS AS (((`tersewa_baju_s` + `tersewa_baju_m`) + `tersewa_baju_l`)) STORED,
			`tanggal_1_s` INT DEFAULT NULL,
			`tanggal_1_m` INT DEFAULT NULL,
			`tanggal_1_l` INT DEFAULT NULL,
			`tanggal_1` INT GENERATED ALWAYS AS (((`tanggal_1_s` + `tanggal_1_m`) + `tanggal_1_l`)) STORED,
			`tanggal_2_s` INT DEFAULT NULL,
			`tanggal_2_m` INT DEFAULT NULL,
			`tanggal_2_l` INT DEFAULT NULL,
			`tanggal_2` INT GENERATED ALWAYS AS (((`tanggal_2_s` + `tanggal_2_m`) + `tanggal_2_l`)) STORED,
			`tanggal_3_s` INT DEFAULT NULL,
			`tanggal_3_m` INT DEFAULT NULL,
			`tanggal_3_l` INT DEFAULT NULL,
			`tanggal_3` INT GENERATED ALWAYS AS (((`tanggal_3_s` + `tanggal_3_m`) + `tanggal_3_l`)) STORED,
			`tanggal_4_s` INT DEFAULT NULL,
			`tanggal_4_m` INT DEFAULT NULL,
			`tanggal_4_l` INT DEFAULT NULL,
			`tanggal_4` INT GENERATED ALWAYS AS (((`tanggal_4_s` + `tanggal_4_m`) + `tanggal_4_l`)) STORED,
			`tanggal_5_s` INT DEFAULT NULL,
			`tanggal_5_m` INT DEFAULT NULL,
			`tanggal_5_l` INT DEFAULT NULL,
			`tanggal_5` INT GENERATED ALWAYS AS (((`tanggal_5_s` + `tanggal_5_m`) + `tanggal_5_l`)) STORED,
			`tanggal_6_s` INT DEFAULT NULL,
			`tanggal_6_m` INT DEFAULT NULL,
			`tanggal_6_l` INT DEFAULT NULL,
			`tanggal_6` INT GENERATED ALWAYS AS (((`tanggal_6_s` + `tanggal_6_m`) + `tanggal_6_l`)) STORED,
			`tanggal_7_s` INT DEFAULT NULL,
			`tanggal_7_m` INT DEFAULT NULL,
			`tanggal_7_l` INT DEFAULT NULL,
			`tanggal_7` INT GENERATED ALWAYS AS (((`tanggal_7_s` + `tanggal_7_m`) + `tanggal_7_l`)) STORED,
			`tanggal_8_s` INT DEFAULT NULL,
			`tanggal_8_m` INT DEFAULT NULL,
			`tanggal_8_l` INT DEFAULT NULL,
			`tanggal_8` INT GENERATED ALWAYS AS (((`tanggal_8_s` + `tanggal_8_m`) + `tanggal_8_l`)) STORED,
			`tanggal_9_s` INT DEFAULT NULL,
			`tanggal_9_m` INT DEFAULT NULL,
			`tanggal_9_l` INT DEFAULT NULL,
			`tanggal_9` INT GENERATED ALWAYS AS (((`tanggal_9_s` + `tanggal_9_m`) + `tanggal_9_l`)) STORED,
			`tanggal_10_s` INT DEFAULT NULL,
			`tanggal_10_m` INT DEFAULT NULL,
			`tanggal_10_l` INT DEFAULT NULL,
			`tanggal_10` INT GENERATED ALWAYS AS (((`tanggal_10_s` + `tanggal_10_m`) + `tanggal_10_l`)) STORED,
			`tanggal_11_s` INT DEFAULT NULL,
			`tanggal_11_m` INT DEFAULT NULL,
			`tanggal_11_l` INT DEFAULT NULL,
			`tanggal_11` INT GENERATED ALWAYS AS (((`tanggal_11_s` + `tanggal_11_m`) + `tanggal_11_l`)) STORED,
			`tanggal_12_s` INT DEFAULT NULL,
			`tanggal_12_m` INT DEFAULT NULL,
			`tanggal_12_l` INT DEFAULT NULL,
			`tanggal_12` INT GENERATED ALWAYS AS (((`tanggal_12_s` + `tanggal_12_m`) + `tanggal_12_l`)) STORED,
			`tanggal_13_s` INT DEFAULT NULL,
			`tanggal_13_m` INT DEFAULT NULL,
			`tanggal_13_l` INT DEFAULT NULL,
			`tanggal_13` INT GENERATED ALWAYS AS (((`tanggal_13_s` + `tanggal_13_m`) + `tanggal_13_l`)) STORED,
			`tanggal_14_s` INT DEFAULT NULL,
			`tanggal_14_m` INT DEFAULT NULL,
			`tanggal_14_l` INT DEFAULT NULL,
			`tanggal_14` INT GENERATED ALWAYS AS (((`tanggal_14_s` + `tanggal_14_m`) + `tanggal_14_l`)) STORED,
			`tanggal_15_s` INT DEFAULT NULL,
			`tanggal_15_m` INT DEFAULT NULL,
			`tanggal_15_l` INT DEFAULT NULL,
			`tanggal_15` INT GENERATED ALWAYS AS (((`tanggal_15_s` + `tanggal_15_m`) + `tanggal_15_l`)) STORED,
			`tanggal_16_s` INT DEFAULT NULL,
			`tanggal_16_m` INT DEFAULT NULL,
			`tanggal_16_l` INT DEFAULT NULL,
			`tanggal_16` INT GENERATED ALWAYS AS (((`tanggal_16_s` + `tanggal_16_m`) + `tanggal_16_l`)) STORED,
			`tanggal_17_s` INT DEFAULT NULL,
			`tanggal_17_m` INT DEFAULT NULL,
			`tanggal_17_l` INT DEFAULT NULL,
			`tanggal_17` INT GENERATED ALWAYS AS (((`tanggal_17_s` + `tanggal_17_m`) + `tanggal_17_l`)) STORED,
			`tanggal_18_s` INT DEFAULT NULL,
			`tanggal_18_m` INT DEFAULT NULL,
			`tanggal_18_l` INT DEFAULT NULL,
			`tanggal_18` INT GENERATED ALWAYS AS (((`tanggal_18_s` + `tanggal_18_m`) + `tanggal_18_l`)) STORED,
			`tanggal_19_s` INT DEFAULT NULL,
			`tanggal_19_m` INT DEFAULT NULL,
			`tanggal_19_l` INT DEFAULT NULL,
			`tanggal_19` INT GENERATED ALWAYS AS (((`tanggal_19_s` + `tanggal_19_m`) + `tanggal_19_l`)) STORED,
			`tanggal_20_s` INT DEFAULT NULL,
			`tanggal_20_m` INT DEFAULT NULL,
			`tanggal_20_l` INT DEFAULT NULL,
			`tanggal_20` INT GENERATED ALWAYS AS (((`tanggal_20_s` + `tanggal_20_m`) + `tanggal_20_l`)) STORED,
			`tanggal_21_s` INT DEFAULT NULL,
			`tanggal_21_m` INT DEFAULT NULL,
			`tanggal_21_l` INT DEFAULT NULL,
			`tanggal_21` INT GENERATED ALWAYS AS (((`tanggal_21_s` + `tanggal_21_m`) + `tanggal_21_l`)) STORED,
			`tanggal_22_s` INT DEFAULT NULL,
			`tanggal_22_m` INT DEFAULT NULL,
			`tanggal_22_l` INT DEFAULT NULL,
			`tanggal_22` INT GENERATED ALWAYS AS (((`tanggal_22_s` + `tanggal_22_m`) + `tanggal_22_l`)) STORED,
			`tanggal_23_s` INT DEFAULT NULL,
			`tanggal_23_m` INT DEFAULT NULL,
			`tanggal_23_l` INT DEFAULT NULL,
			`tanggal_23` INT GENERATED ALWAYS AS (((`tanggal_23_s` + `tanggal_23_m`) + `tanggal_23_l`)) STORED,
			`tanggal_24_s` INT DEFAULT NULL,
			`tanggal_24_m` INT DEFAULT NULL,
			`tanggal_24_l` INT DEFAULT NULL,
			`tanggal_24` INT GENERATED ALWAYS AS (((`tanggal_24_s` + `tanggal_24_m`) + `tanggal_24_l`)) STORED,
			`tanggal_25_s` INT DEFAULT NULL,
			`tanggal_25_m` INT DEFAULT NULL,
			`tanggal_25_l` INT DEFAULT NULL,
			`tanggal_25` INT GENERATED ALWAYS AS (((`tanggal_25_s` + `tanggal_25_m`) + `tanggal_25_l`)) STORED,
			`tanggal_26_s` INT DEFAULT NULL,
			`tanggal_26_m` INT DEFAULT NULL,
			`tanggal_26_l` INT DEFAULT NULL,
			`tanggal_26` INT GENERATED ALWAYS AS (((`tanggal_26_s` + `tanggal_26_m`) + `tanggal_26_l`)) STORED,
			`tanggal_27_s` INT DEFAULT NULL,
			`tanggal_27_m` INT DEFAULT NULL,
			`tanggal_27_l` INT DEFAULT NULL,
			`tanggal_27` INT GENERATED ALWAYS AS (((`tanggal_27_s` + `tanggal_27_m`) + `tanggal_27_l`)) STORED,
			`tanggal_28_s` INT DEFAULT NULL,
			`tanggal_28_m` INT DEFAULT NULL,
			`tanggal_28_l` INT DEFAULT NULL,
			`tanggal_28` INT GENERATED ALWAYS AS (((`tanggal_28_s` + `tanggal_28_m`) + `tanggal_28_l`)) STORED,
			`tanggal_29_s` INT DEFAULT NULL,
			`tanggal_29_m` INT DEFAULT NULL,
			`tanggal_29_l` INT DEFAULT NULL,
			`tanggal_29` INT GENERATED ALWAYS AS (((`tanggal_29_s` + `tanggal_29_m`) + `tanggal_29_l`)) STORED,
			`tanggal_30_s` INT DEFAULT NULL,
			`tanggal_30_m` INT DEFAULT NULL,
			`tanggal_30_l` INT DEFAULT NULL,
			`tanggal_30` INT GENERATED ALWAYS AS (((`tanggal_30_s` + `tanggal_30_m`) + `tanggal_30_l`)) STORED,
			`tanggal_31_s` INT DEFAULT NULL,
			`tanggal_31_m` INT DEFAULT NULL,
			`tanggal_31_l` INT DEFAULT NULL,
			`tanggal_31` INT GENERATED ALWAYS AS (((`tanggal_31_s` + `tanggal_31_m`) + `tanggal_31_l`)) STORED,
			PRIMARY KEY (`id_baju`)) ENGINE=InnoDB;";
		
		$database_admin = mysqli_query($conn, $sql_database_admin);

	    $sql = "SELECT * FROM datatoko WHERE nama_toko='$nama_toko'";
		$result = mysqli_query($conn, $sql);

		if (mysqli_num_rows($result) > 0) {
			header("Location:  ../halaman_daftar_admin/halaman_daftar_admin.php?error=nama_toko_telah_ada&$user_data");
	        exit();
		}else {
           $sql2 = "INSERT INTO datatoko(nama_toko, kata_sandi, email_toko, tanggal_daftar, bulan_daftar, tahun_daftar) VALUES('$nama_toko', '$kata_sandi', '$email_toko', '$tanggal_daftar', '$bulan_daftar', '$tahun_daftar')";
           $result2 = mysqli_query($conn, $sql2);
           if ($result2) {
           	 header("Location:  ../halaman_daftar_admin/halaman_daftar_admin.php?success=akun_berhasil_dibuat");
	         exit();
           }else {
	           	header("Location:  ../halaman_daftar_admin/halaman_daftar_admin.php?error=unknown_error_occurred&$user_data");
		        exit();
           }
		}
	}
	
}else{
	header("Location: ../halaman_daftar_admin/halaman_daftar_admin.php");
	exit();
}