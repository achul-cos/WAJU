<?php
include "connect_database.php"; // Pastikan file ini berisi koneksi ke database

if (isset($_POST['id_pengguna']) &&
    isset($_POST['nama_pengguna_lama']) &&
    isset($_POST['nama_pengguna']) &&
    isset($_POST['nik_pengguna']) &&
    isset($_POST['email_pengguna']) &&
    isset($_POST['nomor_telepon']) &&
    isset($_POST['alamat_pengguna'])) { // Pastikan semua field yang diperlukan ada

    function validate($data) {
        // Membersihkan karakter yang tidak diinginkan
        return htmlspecialchars(trim($data));
    }

    // Validasi dan ambil data dari POST
    $id_pengguna = validate($_POST['id_pengguna']);
    $nama_pengguna_lama = validate($_POST['nama_pengguna_lama']);
    $nama_pengguna = validate($_POST['nama_pengguna']);
    $nik_pengguna = validate($_POST['nik_pengguna']);
    $email_pengguna = validate($_POST['email_pengguna']);
    $nomor_telepon = validate($_POST['nomor_telepon']);
    $alamat_pengguna = validate($_POST['alamat_pengguna']);
    $status_update = 1;

    // Inisialisasi variabel untuk path foto
    $foto_pengguna_path = null;

    // Proses upload file gambar jika ada
    if (isset($_FILES['foto_pengguna']) && $_FILES['foto_pengguna']['error'] == UPLOAD_ERR_OK) {
        $targetDir = "../img/data_pengguna/";
        $fileName = basename($_FILES['foto_pengguna']['name']);
        $targetFilePath = $targetDir . $fileName;
        $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);

        // Daftar format yang diizinkan
        $allowedTypes = array('jpg', 'jpeg', 'png', 'gif');

        // Cek apakah format file diizinkan
        if (in_array($fileType, $allowedTypes)) {
            // Cek apakah upload berhasil
            if (move_uploaded_file($_FILES['foto_pengguna']['tmp_name'], $targetFilePath)) {
                // Jika upload berhasil, simpan path ke database
                $foto_pengguna_path = $targetFilePath; // Path file yang disimpan
            } else {
                echo "Terjadi kesalahan saat mengupload file.";
            }
        } else {
            echo "Hanya file JPG, JPEG, PNG, dan GIF yang diperbolehkan.";
        }
    }
    if ($nama_pengguna_lama != $nama_pengguna) {
        $kueri_ubah_tabel = "RENAME TABLE `$nama_pengguna_lama` TO `$nama_pengguna`";
        $hasil_kueri_tabel = mysqli_query($conn, $kueri_ubah_tabel);
    }

    // Query untuk memperbarui data pengguna
    // Jika foto_pengguna_path tidak null, masukkan ke dalam query
    $sql = "UPDATE dataakun SET 
    nama_pengguna = '$nama_pengguna',
    nik_pengguna = '$nik_pengguna', 
    email = '$email_pengguna', 
    nomor_telepon = '$nomor_telepon', 
    alamat_pengguna = '$alamat_pengguna',
    status_update = '$status_update'"; 

    // Tambahkan foto_pengguna hanya jika ada
    if ($foto_pengguna_path) {
    $sql .= ", foto_pengguna = '$foto_pengguna_path'";
    }

    // Tambahkan kondisi WHERE
    $sql .= " WHERE id = '$id_pengguna'";

    // Eksekusi query
    if (mysqli_query($conn, $sql)) {
        $_SESSION['nama_pengguna'] = $data_pengguna['nama_pengguna'];
        $_SESSION['id'] = $data_pengguna['id'];
        header("Location: ../halaman_pengaturan_user/halaman_pengaturan_user.php");
        exit(); 
    } else {
        header("Location: ../halaman_pengaturan_user/halaman_pengaturan_user.php?error=unknown_error_occurred");
        exit();
    }
} else {
    echo "Semua field harus diisi.";
}

// Tutup koneksi
mysqli_close($conn);
?>