<?php
include "connect_database.php"; // Pastikan file ini berisi koneksi ke database

if (isset($_POST['id_toko']) &&
    isset($_POST['nama_toko_lama']) &&
    isset($_POST['nama_toko']) &&
    isset($_POST['deskripsi_toko']) &&
    isset($_POST['email_toko']) &&
    isset($_POST['kontak_toko']) &&
    isset($_POST['alamat_toko']) &&
    isset($_POST['jam_buka']) &&
    isset($_POST['jam_tutup'])) { // Pastikan semua field yang diperlukan ada

    function validate($data) {
        // Membersihkan karakter yang tidak diinginkan
        return htmlspecialchars(trim($data));
    }

    // Validasi dan ambil data dari POST
    $id_toko = validate($_POST['id_toko']);
    $nama_toko_lama = validate($_POST['nama_toko_lama']);
    $nama_toko = validate($_POST['nama_toko']);
    $deskripsi_toko = validate($_POST['deskripsi_toko']);
    $email_toko = validate($_POST['email_toko']);
    $kontak_toko = validate($_POST['kontak_toko']);
    $alamat_toko = validate($_POST['alamat_toko']);
    $jam_buka = validate($_POST['jam_buka']);
    $jam_tutup = validate($_POST['jam_tutup']);
    $status_update = 1;

    // Inisialisasi variabel untuk path foto
    $foto_toko_path = null;

    // Proses upload file gambar jika ada
    if (isset($_FILES['foto_toko']) && $_FILES['foto_toko']['error'] == UPLOAD_ERR_OK) {
        $targetDir = "../img/data_toko/pp_toko/";
        $fileName = basename($_FILES['foto_toko']['name']);
        $targetFilePath = $targetDir . $fileName;
        $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);

        // Daftar format yang diizinkan
        $allowedTypes = array('jpg', 'jpeg', 'png', 'JPG', 'JPEG', 'PNG');

        // Cek apakah format file diizinkan
        if (in_array($fileType, $allowedTypes)) {
            // Cek apakah upload berhasil
            if (move_uploaded_file($_FILES['foto_toko']['tmp_name'], $targetFilePath)) {
                // Jika upload berhasil, simpan path ke database
                $foto_toko_path = $targetFilePath; // Path file yang disimpan
            } else {
                echo "Terjadi kesalahan saat mengupload file.";
            }
        } else {
            echo "Hanya file JPG, JPEG, PNG yang diperbolehkan.";
        }
    }

    //konversi jam buka dan tutup ke waktu

    $jam_buka_display = "";
    $jam_tutup_display = "";

    if ($jam_buka) {
        if ($jam_buka > 24) {
            $jam_buka = 24;
        }
        elseif ($jam_buka < 0) {
            $jam_buka = 0;
        }
        else { $jam_buka = $jam_buka; }
        $jam_buka_display = "$jam_buka:00 WIB";
    }
    if ($jam_tutup) {
        if ($jam_tutup > 24) {
            $jam_tutup = 24;
        }
        elseif ($jam_tutup < 0) {
            $jam_tutup = 0;
        }
        else { $jam_buka = $jam_buka; }
        $jam_tutup_display = "$jam_tutup:00 WIB";
    }

    if ($nama_toko_lama != $nama_toko) {
        $kueri_ubah_tabel = "RENAME TABLE `toko_$nama_toko_lama` TO `toko_$nama_toko`";
        $hasil_kueri_tabel = mysqli_query($conn, $kueri_ubah_tabel);
    }

    // Query untuk memperbarui data pengguna
    // Jika foto_pengguna_path tidak null, masukkan ke dalam query
    $sql = "UPDATE datatoko SET 
    nama_toko = '$nama_toko',
    deskripsi_toko = '$deskripsi_toko', 
    email_toko = '$email_toko', 
    kontak_toko = '$kontak_toko', 
    alamat_toko = '$alamat_toko',
    jam_buka = '$jam_buka',
    jam_tutup = '$jam_tutup',
    jam_buka_display = '$jam_buka_display',
    jam_tutup_display = '$jam_tutup_display',
    status_update = '$status_update'"; 

    // Tambahkan foto_pengguna hanya jika ada
    if ($foto_toko_path) {
    $sql .= ", foto_toko = '$foto_toko_path'";
    }

    // Tambahkan kondisi WHERE
    $sql .= " WHERE id = '$id_toko'";

    $hasil = mysqli_query($conn, $sql);

    if (!$hasil) {
        die("Query gagal: " . mysqli_error($conn));
    } else {
        header("Location:  ../halaman_admin/pengaturan.php");
        exit();
    }

} else {
    echo "Semua field harus diisi.";

    echo $_POST['id_toko'];
    echo $_POST['nama_toko'];
    echo $_POST['deskripsi_toko'];
    echo $_POST['email_toko'];
    echo $_POST['kontak_toko'];
    echo $_POST['alamat_toko'];
    echo $_POST['jam_buka'];
    echo $_POST['jam_tutup'];

}

// Tutup koneksi
mysqli_close($conn);
?>