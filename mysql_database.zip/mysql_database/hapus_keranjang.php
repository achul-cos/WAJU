<?php
session_start();

// Koneksi ke database
$con = mysqli_connect("localhost", "root", "", "waju");

if (!$con) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// Cek apakah tombol hapus ditekan
if (isset($_POST['hapus'])) {
    $id = mysqli_real_escape_string($con, $_POST['id']);
    $nama_pengguna = mysqli_real_escape_string($con, $_POST['nama_pengguna']);

    // Query untuk menghapus item dari keranjang
    $query = "DELETE FROM `$nama_pengguna` WHERE id = '$id'"; 

    // Debugging: Tampilkan query
    echo $query; // Hapus atau komentari ini setelah debugging
    echo $nama_pengguna;

    $result = mysqli_query($con, $query);

    if ($result) {
        // Redirect kembali ke halaman keranjang setelah menghapus
        header("Location: ../halaman_keranjang/halaman_keranjang.php");
        exit();
    } else {
        // Jika gagal, redirect dengan pesan error
        die("Query gagal: " . mysqli_error($con)); // Menampilkan kesalahan jika query gagal
    }
} else {
    // Jika tidak ada permintaan hapus, redirect ke halaman keranjang
    header("Location: ../halaman_keranjang/halaman_keranjang.php");
    exit();
}
?>