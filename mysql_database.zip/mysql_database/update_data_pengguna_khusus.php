<?php
include "connect_database.php"; // Pastikan file ini berisi koneksi ke database

if (isset($_POST['id_pengguna']) &&
    isset($_POST['nama_pengguna']) &&
    isset($_POST['nik_pengguna']) &&
    isset($_POST['email_pengguna']) &&
    isset($_POST['nomor_telepon']) &&
    isset($_POST['alamat_pengguna'])) { // Pastikan semua field yang diperlukan ada

    function validate($data) {
        // Membersihkan karakter yang tidak diinginkan
        return htmlspecialchars(trim($data));
    }

    // Validasi dan ambil data dari POST
    $id_pengguna = validate($_POST['id_pengguna']);
    $nama_pengguna = validate($_POST['nama_pengguna']);
    $nik_pengguna = validate($_POST['nik_pengguna']);
    $email_pengguna = validate($_POST['email_pengguna']);
    $nomor_telepon = validate($_POST['nomor_telepon']);
    $alamat_pengguna = validate($_POST['alamat_pengguna']);
    $status_update = 1;

    $sql = "UPDATE dataakun SET 
    nama_pengguna = '$nama_pengguna',
    nik_pengguna = '$nik_pengguna', 
    email = '$email_pengguna', 
    nomor_telepon = '$nomor_telepon', 
    alamat_pengguna = '$alamat_pengguna',
    status_update = '$status_update'"; 

    // Tambahkan kondisi WHERE
    $sql .= " WHERE id = '$id_pengguna'";

    // Eksekusi query
    if (mysqli_query($conn, $sql)) {
        $_SESSION['nama_pengguna'] = $data_pengguna['nama_pengguna'];
        $_SESSION['id'] = $data_pengguna['id'];
        header("Location: ../halaman_pembayaran/halaman_pembayaran.php");
        exit(); 
    } else {
        header("Location: ../halaman_pembayaran/halaman_pembayaran.php");
        exit();
    }
} else {
    echo "Semua field harus diisi.";
}

// Tutup koneksi
mysqli_close($conn);
?>