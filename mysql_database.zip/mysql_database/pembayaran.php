<?php 

include "connect_database.php"; // Pastikan file ini berisi koneksi ke database

if (isset($_POST['options']) &&
    isset($_POST['id_dataakun']) &&
    isset($_POST['nama_penyewa']) &&
    isset($_POST['nik_penyewa']) &&
    isset($_POST['kontak_penyewa']) &&
    isset($_POST['alamat_penyewa']) &&
    isset($_POST['id_pemesanan']) &&
    isset($_POST['tanggal_pemesanan']) &&
    isset($_POST['tanggal_sewa']) &&
    isset($_POST['bulan_sewa']) &&
    isset($_POST['tahun_sewa']) &&
    isset($_POST['tanggal_pengembalian_1_hari']) &&
    isset($_POST['tanggal_pengembalian_2_hari']) &&
    isset($_POST['tanggal_pengembalian_3_hari']) &&
    isset($_POST['nama_pemilik']) &&
    isset($_POST['alamat_pemilik']) &&
    isset($_POST['kontak_pemilik']) &&
    isset($_POST['nama_baju']) &&
    isset($_POST['harga_baju']) &&
    isset($_POST['foto_baju']) &&
    isset($_POST['ukuran_baju']) &&
    isset($_POST['id_datatoko']) &&
    isset($_POST['id_databaju'])) {

    function validate($data) {
        // Membersihkan karakter yang tidak diinginkan
        return htmlspecialchars(trim($data));
    }

    // Validasi dan ambil data dari POST
    $id_dataakun = validate($_POST['id_dataakun']);
    $nama_penyewa = validate($_POST['nama_penyewa']);
    $nik_penyewa = validate($_POST['nik_penyewa']);
    $kontak_penyewa = validate($_POST['kontak_penyewa']);
    $alamat_penyewa = validate($_POST['alamat_penyewa']);
    $id_pemesanan = validate($_POST['id_pemesanan']);
    $tanggal_pemesanan = validate($_POST['tanggal_pemesanan']);
    $tanggal_sewa = validate($_POST['tanggal_sewa']);
    $bulan_sewa = validate($_POST['bulan_sewa']);
    $tahun_sewa = validate($_POST['tahun_sewa']);
    $tanggal_pengembalian_1_hari = validate($_POST['tanggal_pengembalian_1_hari']);
    $tanggal_pengembalian_2_hari = validate($_POST['tanggal_pengembalian_2_hari']);
    $tanggal_pengembalian_3_hari = validate($_POST['tanggal_pengembalian_3_hari']);
    $nama_pemilik = validate($_POST['nama_pemilik']);
    $alamat_pemilik = validate($_POST['alamat_pemilik']);
    $kontak_pemilik = validate($_POST['kontak_pemilik']);
    $nama_baju = validate ($_POST['nama_baju']);
    $harga_baju = validate($_POST['harga_baju']);
    $foto_baju = validate($_POST['foto_baju']);
    $ukuran_baju = validate($_POST['ukuran_baju']);
    $id_datatoko = validate($_POST['id_datatoko']);
    $id_databaju = validate($_POST['id_databaju']);

    require_once __DIR__ . "/dompdf/autoload.inc.php"; // Pastikan ini adalah baris pertama dalam file PHP

    use Dompdf\Dompdf;
    use Dompdf\Options; 

    $options = new Options();
    $options->setChroot(__DIR__);
    $options->setIsRemoteEnabled(true); // Enable remote file access

    $dompdf = new Dompdf($options);

    $html = file_get_contents("invoice.html");

    if ($html === false) {
        die("Error: Unable to load HTML file.");
    }

    $dompdf->loadHtml($html); // Perbaiki 'loadhtml' menjadi 'loadHtml' dan tambahkan titik koma

    $dompdf->render();

    $dompdf->addInfo("Title", "An Example PDF"); // "add_info" in earlier versions of Dompdf

    $dompdf->stream("nota_{$nama_penyewa}_{$id_pemesanan}.pdf", ["Attachment" => 0]);

} else {
    die("Error: Missing required POST data.");
}
?>