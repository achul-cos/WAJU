<?php 
session_start(); 
include "connect_database.php";

if (isset($_POST['nama_toko']) && isset($_POST['kata_sandi'])) {

	function validate($data){
       $data = trim($data);
	   $data = stripslashes($data);
	   $data = htmlspecialchars($data);
	   return $data;
	}

	$nama_toko = validate($_POST['nama_toko']);
	$kata_sandi = validate($_POST['kata_sandi']);

	if (empty($nama_toko)) {
		header("Location: halaman_masuk.php?error=User Name is required");
	    exit();
	}else if(empty($kata_sandi)){
        header("Location: halaman_masuk.php?error=Password is required");
	    exit();
	}else{

		// hashing the password
		$kata_sandi = md5($kata_sandi);

		$kata_sandi = $kata_sandi;
        
		$sql = "SELECT * FROM datatoko WHERE nama_toko='$nama_toko' AND kata_sandi='$kata_sandi'";

		$result = mysqli_query($conn, $sql);

		if (mysqli_num_rows($result) === 1) {
			$row = mysqli_fetch_assoc($result);
            if ($row['nama_toko'] === $nama_toko && $row['kata_sandi'] === $kata_sandi) {
            	$_SESSION['nama_toko'] = $row['nama_toko'];
            	$_SESSION['email_toko'] = $row['email_toko'];
            	$_SESSION['id'] = $row['id'];
				$_SESSION['foto_toko'] = $row['foto_toko'];
				$_SESSION['kontak_toko'] = $row['kontak_toko'];
				$_SESSION['alamat_toko'] = $row['alamat_toko'];
				$_SESSION['deskripsi_toko'] = $row['deskripsi_toko'];
				$_SESSION['jam_buka'] = $row['jam_buka'];
				$_SESSION['jam_tutup'] = $row['jam_tutup'];
            	header("Location: ../halaman_admin/dashboard.php");
		        exit();
            }else{
				header("Location: ../halaman_masuk_admin/halaman_masuk_admin.php?error=pass_atau_nama_salah");
		        exit();
			}
		}else{
			header("Location: ../halaman_masuk_admin/halaman_masuk_admin.php?error=pass_atau_nama_salah");
	        exit();
		}
	}
	
}else{
	header("Location: halaman_masuk_admin.php");
	exit();
}